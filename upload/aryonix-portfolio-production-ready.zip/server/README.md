# Server — Express + MongoDB API

```
server/
  src/
    app.js              Express app assembly (middleware, routes, error handler)
    server.js            entry point — loads env, connects DB, starts listener
    config/db.js         mongoose connection
    models/               User, Project, Skill, ContactMessage, Experience
    controllers/          Project, Skill, Contact
    routes/                Project, Skill, Contact — validation chains live here
    middleware/            errorHandler, validate, rateLimiters
```

## Setup

```bash
cd server
npm install
cp .env.example .env   # then fill in MONGODB_URI at minimum
npm run dev
```

Server runs on `http://localhost:5000` by default. `GET /health` confirms it's up.

## Environment variables

| Variable | Required | Notes |
|---|---|---|
| `MONGODB_URI` | yes | connection string for your MongoDB instance |
| `JWT_SECRET` | Phase 4 | not used yet — needed once admin auth is built |
| `CLIENT_URL` | yes | used for CORS; defaults to `http://localhost:5173` |
| `PORT` | no | defaults to `5000` |
| `NODE_ENV` | no | `development` / `production` |

## Endpoints (Phase 3)

| Method | Path | Auth | Notes |
|---|---|---|---|
| GET | `/health` | — | uptime check |
| GET | `/api/projects` | — | list |
| GET | `/api/projects/:id` | — | single project |
| POST | `/api/projects` | ⚠️ open | validated; will be admin-only in Phase 4 |
| PUT | `/api/projects/:id` | ⚠️ open | same |
| DELETE | `/api/projects/:id` | ⚠️ open | same |
| GET | `/api/skills` | — | list |
| POST | `/api/skills` | ⚠️ open | validated; will be admin-only in Phase 4 |
| PUT | `/api/skills/:id` | ⚠️ open | same |
| DELETE | `/api/skills/:id` | ⚠️ open | same |
| POST | `/api/contact` | — | rate-limited (5 / 15 min per IP), validated |
| GET | `/api/contact` | ⚠️ open | **must** be admin-only from Phase 4 on |
| DELETE | `/api/contact/:id` | ⚠️ open | same |

Routes marked ⚠️ are intentionally unprotected right now because auth doesn't
exist yet — Phase 4 wires `requireAuth` onto every one of them. Each route file
has a `// TODO Phase 4` comment marking exactly where.
