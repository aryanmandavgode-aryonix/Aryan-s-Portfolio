import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import cookieParser from "cookie-parser";

import authRoutes from "./routes/authRoutes.js";
import projectRoutes from "./routes/projectRoutes.js";
import skillRoutes from "./routes/skillRoutes.js";
import contactRoutes from "./routes/contactRoutes.js";
import { notFound, errorHandler } from "./middleware/errorHandler.js";

export function createApp() {
  const app = express();

  // Required when deployed behind a reverse proxy (Render, Railway, Heroku,
  // Nginx, etc.) so express-rate-limit and req.ip see the real client IP
  // instead of the proxy's — without this, rate limiting would effectively
  // apply to all users as a single shared IP.
  if (process.env.NODE_ENV === "production") {
    app.set("trust proxy", 1);
  }

  // CLIENT_URL supports a comma-separated list so a production deploy can
  // allow e.g. both the apex domain and a www subdomain without code changes.
  const allowedOrigins = (process.env.CLIENT_URL || "http://localhost:5173")
    .split(",")
    .map((o) => o.trim())
    .filter(Boolean);

  app.use(helmet());
  app.use(
    cors({
      origin(origin, callback) {
        // Allow requests with no Origin header (curl, server-to-server,
        // health checks) as well as any explicitly configured origin.
        if (!origin || allowedOrigins.includes(origin)) {
          callback(null, true);
        } else {
          const err = new Error("Not allowed by CORS.");
          err.statusCode = 403;
          callback(err);
        }
      },
      credentials: true,
    })
  );
  app.use(express.json({ limit: "10kb" }));
  app.use(cookieParser());
  if (process.env.NODE_ENV === "production") {
    app.use(morgan("combined")); // Apache-style, suited to production log aggregation
  } else if (process.env.NODE_ENV !== "test") {
    app.use(morgan("dev")); // colored, concise — meant for a local terminal
  }

  app.get("/health", (req, res) => {
    res.json({ success: true, message: "API is running." });
  });

  app.use("/api/auth", authRoutes);
  app.use("/api/projects", projectRoutes);
  app.use("/api/skills", skillRoutes);
  app.use("/api/contact", contactRoutes);

  app.use(notFound);
  app.use(errorHandler);

  return app;
}
