import ContactMessage from "../models/ContactMessage.js";
import { asyncHandler } from "../middleware/errorHandler.js";

export const submitContactMessage = asyncHandler(async (req, res) => {
  const { name, email, company, projectType, message } = req.body;
  const saved = await ContactMessage.create({ name, email, company, projectType, message });
  res.status(201).json({
    success: true,
    message: "Message sent — thanks for reaching out. I'll get back to you soon.",
    data: { id: saved._id },
  });
});

// NOTE: not protected yet — Phase 4 adds admin auth. Wire `requireAuth`
// middleware onto this route once it exists so contact messages aren't public.
export const getContactMessages = asyncHandler(async (req, res) => {
  const messages = await ContactMessage.find().sort({ createdAt: -1 });
  res.json({ success: true, data: messages });
});

export const deleteContactMessage = asyncHandler(async (req, res) => {
  const deleted = await ContactMessage.findByIdAndDelete(req.params.id);
  if (!deleted) {
    res.status(404);
    throw new Error("Message not found.");
  }
  res.json({ success: true, data: { id: req.params.id } });
});
