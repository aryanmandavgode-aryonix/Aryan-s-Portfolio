import User from "../models/User.js";
import bcrypt from "bcryptjs";
import { asyncHandler } from "../middleware/errorHandler.js";
import { signToken, setAuthCookie, clearAuthCookie } from "../utils/token.js";

// A precomputed dummy hash so a non-existent email still pays the same
// bcrypt.compare cost as a real one — otherwise response time leaks whether
// an email is registered (timing-based user enumeration).
const DUMMY_HASH = "$2a$12$CwTycUXWue0Thq9StjUM0uJ8Fp6oOHQKqQ3f1e6h5aRDLkVfR7Zxa";

export const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  // select("+password") because the schema excludes it by default
  const user = await User.findOne({ email }).select("+password");
  const validPassword = user
    ? await user.comparePassword(password)
    : await bcrypt.compare(password, DUMMY_HASH);

  if (!user || !validPassword) {
    res.status(401);
    throw new Error("Invalid email or password.");
  }

  const token = signToken(user._id);
  setAuthCookie(res, token);

  res.json({
    success: true,
    data: { id: user._id, name: user.name, email: user.email, role: user.role },
  });
});

export const logout = asyncHandler(async (req, res) => {
  clearAuthCookie(res);
  res.json({ success: true, message: "Logged out." });
});

export const getMe = asyncHandler(async (req, res) => {
  // req.user is set by requireAuth and already excludes the password field
  res.json({
    success: true,
    data: { id: req.user._id, name: req.user.name, email: req.user.email, role: req.user.role },
  });
});
