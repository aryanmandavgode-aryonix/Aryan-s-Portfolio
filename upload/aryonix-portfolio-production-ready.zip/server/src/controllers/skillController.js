import Skill from "../models/Skill.js";
import { asyncHandler } from "../middleware/errorHandler.js";

export const getSkills = asyncHandler(async (req, res) => {
  const skills = await Skill.find().sort({ category: 1, order: 1 });
  res.json({ success: true, data: skills });
});

export const createSkill = asyncHandler(async (req, res) => {
  const skill = await Skill.create(req.body);
  res.status(201).json({ success: true, data: skill });
});

export const updateSkill = asyncHandler(async (req, res) => {
  const skill = await Skill.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  });
  if (!skill) {
    res.status(404);
    throw new Error("Skill not found.");
  }
  res.json({ success: true, data: skill });
});

export const deleteSkill = asyncHandler(async (req, res) => {
  const skill = await Skill.findByIdAndDelete(req.params.id);
  if (!skill) {
    res.status(404);
    throw new Error("Skill not found.");
  }
  res.json({ success: true, data: { id: req.params.id } });
});
