import mongoose from "mongoose";

/**
 * Connects to MongoDB. Does not crash the process on failure — logs and lets
 * the caller decide (server.js keeps the API up so /health still reports status
 * even if the DB is unreachable).
 */
export async function connectDB() {
  const uri = process.env.MONGODB_URI;

  if (!uri) {
    console.error("MONGODB_URI is not set. Add it to your .env file.");
    return false;
  }

  try {
    await mongoose.connect(uri, { serverSelectionTimeoutMS: 4000 });
    console.log("MongoDB connected");
    return true;
  } catch (err) {
    console.error("MongoDB connection error:", err.message);
    return false;
  }
}

mongoose.connection.on("disconnected", () => {
  console.warn("MongoDB disconnected");
});
