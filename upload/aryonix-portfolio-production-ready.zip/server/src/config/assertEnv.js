const REQUIRED = ["MONGODB_URI", "JWT_SECRET"];

/**
 * Validates required env vars exist before the server starts accepting
 * traffic. Without this, a missing JWT_SECRET would only surface on someone's
 * first login attempt (as a confusing 500), and a missing MONGODB_URI would
 * silently fail every DB-backed request. Fail loudly at boot instead.
 */
export function assertRequiredEnv() {
  const missing = REQUIRED.filter((key) => !process.env[key]);

  if (missing.length > 0) {
    console.error(
      `Missing required environment variable(s): ${missing.join(", ")}.\n` +
        "Copy .env.example to .env and fill these in before starting the server."
    );
    process.exit(1);
  }

  if (process.env.JWT_SECRET.length < 32) {
    console.error(
      "JWT_SECRET is too short — use at least 32 random characters " +
        "(e.g. `node -e \"console.log(require('crypto').randomBytes(32).toString('hex'))\"`)."
    );
    process.exit(1);
  }
}
