/**
 * Applied to schemas whose documents are sent straight to the frontend.
 * Adds a plain `id` string field to JSON output (matching the frontend's
 * TypeScript types) and drops the internal `_id`/`__v` fields.
 */
export function withCleanJSON(schema) {
  schema.set("toJSON", {
    virtuals: true,
    versionKey: false,
    transform: (_doc, ret) => {
      delete ret._id;
      return ret;
    },
  });
}
