import "dotenv/config";
import mongoose from "mongoose";
import User from "../models/User.js";

/**
 * Creates (or updates the password of) the single admin account from env vars.
 * There is deliberately no public /api/auth/register route — the only way to
 * create an admin is to run this script with access to the server's own .env.
 *
 * Usage: npm run seed:admin
 */
async function seedAdmin() {
  const { MONGODB_URI, ADMIN_NAME, ADMIN_EMAIL, ADMIN_PASSWORD } = process.env;

  if (!MONGODB_URI) {
    console.error("MONGODB_URI is not set.");
    process.exit(1);
  }
  if (!ADMIN_EMAIL || !ADMIN_PASSWORD) {
    console.error("Set ADMIN_NAME, ADMIN_EMAIL and ADMIN_PASSWORD in .env before seeding.");
    process.exit(1);
  }
  if (ADMIN_PASSWORD.length < 8) {
    console.error("ADMIN_PASSWORD must be at least 8 characters.");
    process.exit(1);
  }

  await mongoose.connect(MONGODB_URI);

  const existing = await User.findOne({ email: ADMIN_EMAIL.toLowerCase() });

  if (existing) {
    existing.password = ADMIN_PASSWORD; // pre-save hook re-hashes
    existing.name = ADMIN_NAME || existing.name;
    await existing.save();
    console.log(`Updated existing admin: ${existing.email}`);
  } else {
    const created = await User.create({
      name: ADMIN_NAME || "Admin",
      email: ADMIN_EMAIL,
      password: ADMIN_PASSWORD,
      role: "admin",
    });
    console.log(`Created admin: ${created.email}`);
  }

  await mongoose.disconnect();
  process.exit(0);
}

seedAdmin().catch((err) => {
  console.error("Seed failed:", err.message);
  process.exit(1);
});
