import { Router } from "express";
import { body } from "express-validator";
import { validate } from "../middleware/validate.js";
import { contactLimiter } from "../middleware/rateLimiters.js";
import { requireAuth } from "../middleware/auth.js";
import { PROJECT_TYPE_OPTIONS } from "../models/ContactMessage.js";
import {
  submitContactMessage,
  getContactMessages,
  deleteContactMessage,
} from "../controllers/contactController.js";

const router = Router();

const contactRules = [
  body("name").trim().notEmpty().withMessage("Name is required.").isLength({ max: 120 }),
  body("email").trim().isEmail().withMessage("A valid email is required.").normalizeEmail(),
  body("company").optional({ values: "falsy" }).trim().isLength({ max: 120 }),
  body("projectType")
    .trim()
    .isIn(PROJECT_TYPE_OPTIONS)
    .withMessage(`Project type must be one of: ${PROJECT_TYPE_OPTIONS.join(", ")}.`),
  body("message")
    .trim()
    .notEmpty()
    .withMessage("Message is required.")
    .isLength({ min: 10, max: 4000 })
    .withMessage("Message must be between 10 and 4000 characters."),
];

router.post("/", contactLimiter, contactRules, validate, submitContactMessage);
router.get("/", requireAuth, getContactMessages);
router.delete("/:id", requireAuth, deleteContactMessage);

export default router;
