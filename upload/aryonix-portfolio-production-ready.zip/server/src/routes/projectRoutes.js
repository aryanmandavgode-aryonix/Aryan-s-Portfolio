import { Router } from "express";
import { body } from "express-validator";
import { validate } from "../middleware/validate.js";
import { requireAuth } from "../middleware/auth.js";
import {
  getProjects,
  getProjectById,
  createProject,
  updateProject,
  deleteProject,
} from "../controllers/projectController.js";

const router = Router();

const projectRules = [
  body("name").trim().notEmpty().withMessage("Name is required.").isLength({ max: 120 }),
  body("description")
    .trim()
    .notEmpty()
    .withMessage("Description is required.")
    .isLength({ max: 500 }),
  body("technologies").optional().isArray().withMessage("Technologies must be a list."),
  body("githubUrl").optional({ values: "falsy" }).isURL().withMessage("Invalid GitHub URL."),
  body("liveUrl").optional({ values: "falsy" }).isURL().withMessage("Invalid live URL."),
];

router.get("/", getProjects);
router.get("/:id", getProjectById);
router.post("/", requireAuth, projectRules, validate, createProject);
router.put("/:id", requireAuth, projectRules, validate, updateProject);
router.delete("/:id", requireAuth, deleteProject);

export default router;
