import { Router } from "express";
import { body } from "express-validator";
import { validate } from "../middleware/validate.js";
import { authLimiter } from "../middleware/rateLimiters.js";
import { requireAuth } from "../middleware/auth.js";
import { login, logout, getMe } from "../controllers/authController.js";

const router = Router();

const loginRules = [
  body("email").trim().isEmail().withMessage("A valid email is required.").normalizeEmail(),
  body("password").notEmpty().withMessage("Password is required."),
];

router.post("/login", authLimiter, loginRules, validate, login);
router.post("/logout", logout);
router.get("/me", requireAuth, getMe);

export default router;
