import { Router } from "express";
import { body } from "express-validator";
import { validate } from "../middleware/validate.js";
import { requireAuth } from "../middleware/auth.js";
import {
  getSkills,
  createSkill,
  updateSkill,
  deleteSkill,
} from "../controllers/skillController.js";

const router = Router();

const skillRules = [
  body("name").trim().notEmpty().withMessage("Name is required.").isLength({ max: 60 }),
  body("category")
    .trim()
    .isIn(["Frontend", "Backend", "Database", "Tools"])
    .withMessage("Category must be one of Frontend, Backend, Database, Tools."),
];

router.get("/", getSkills);
router.post("/", requireAuth, skillRules, validate, createSkill);
router.put("/:id", requireAuth, skillRules, validate, updateSkill);
router.delete("/:id", requireAuth, deleteSkill);

export default router;
