import "dotenv/config";
import { createApp } from "./app.js";
import { connectDB } from "./config/db.js";
import { assertRequiredEnv } from "./config/assertEnv.js";

assertRequiredEnv();

const PORT = process.env.PORT || 5000;

const app = createApp();

app.listen(PORT, () => {
  console.log(`API listening on http://localhost:${PORT}`);
});

// Connect to MongoDB in parallel rather than blocking startup — the API
// (and /health) stays reachable even if the DB is briefly unavailable.
connectDB();
