import mongoose from "mongoose";
import { withCleanJSON } from "../utils/withCleanJSON.js";

const experienceSchema = new mongoose.Schema(
  {
    organization: { type: String, required: true, trim: true, maxlength: 150 },
    role: { type: String, required: true, trim: true, maxlength: 150 },
    period: { type: String, required: true, trim: true, maxlength: 60 },
    points: { type: [String], default: [] },
    order: { type: Number, default: 0 },
  },
  { timestamps: true }
);

withCleanJSON(experienceSchema);

export default mongoose.model("Experience", experienceSchema);
