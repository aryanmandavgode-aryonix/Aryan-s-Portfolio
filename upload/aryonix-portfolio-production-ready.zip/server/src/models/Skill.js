import mongoose from "mongoose";
import { withCleanJSON } from "../utils/withCleanJSON.js";

const skillSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 60 },
    category: {
      type: String,
      required: true,
      enum: ["Frontend", "Backend", "Database", "Tools"],
    },
    order: { type: Number, default: 0 },
  },
  { timestamps: true }
);

withCleanJSON(skillSchema);

// Matches the public site's and admin dashboard's default sort.
skillSchema.index({ category: 1, order: 1 });

export default mongoose.model("Skill", skillSchema);
