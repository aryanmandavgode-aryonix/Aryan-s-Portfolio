import mongoose from "mongoose";

const PROJECT_TYPES = [
  "Website",
  "MERN Application",
  "E-Commerce",
  "Dashboard",
  "Booking System",
  "Custom Software",
  "Other",
];

const contactMessageSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 120 },
    email: { type: String, required: true, trim: true, lowercase: true, maxlength: 200 },
    company: { type: String, trim: true, maxlength: 120 },
    projectType: { type: String, enum: PROJECT_TYPES, required: true },
    message: { type: String, required: true, trim: true, maxlength: 4000 },
    read: { type: Boolean, default: false },
  },
  { timestamps: true }
);

export const PROJECT_TYPE_OPTIONS = PROJECT_TYPES;

// Matches the admin dashboard's default sort (newest first).
contactMessageSchema.index({ createdAt: -1 });

export default mongoose.model("ContactMessage", contactMessageSchema);
