import mongoose from "mongoose";
import { withCleanJSON } from "../utils/withCleanJSON.js";

const projectSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 120 },
    description: { type: String, required: true, trim: true, maxlength: 500 },
    technologies: {
      type: [String],
      default: [],
      validate: {
        validator: (arr) => arr.length <= 20,
        message: "Too many technologies listed.",
      },
    },
    image: { type: String, trim: true },
    githubUrl: { type: String, trim: true },
    liveUrl: { type: String, trim: true },
    overview: { type: String, trim: true, maxlength: 1000 },
    problem: { type: String, trim: true, maxlength: 1000 },
    solution: { type: String, trim: true, maxlength: 1000 },
    features: { type: [String], default: [] },
    isPlaceholder: { type: Boolean, default: false },
    order: { type: Number, default: 0 },
  },
  { timestamps: true }
);

withCleanJSON(projectSchema);

// Matches the public site's and admin dashboard's default sort.
projectSchema.index({ order: 1, createdAt: -1 });

export default mongoose.model("Project", projectSchema);
