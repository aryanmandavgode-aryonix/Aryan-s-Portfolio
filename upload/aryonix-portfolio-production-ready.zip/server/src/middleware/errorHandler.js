/** Wrap an async route handler so rejected promises reach the error handler. */
export function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

export function notFound(req, res, next) {
  res.status(404);
  next(new Error(`Route not found — ${req.method} ${req.originalUrl}`));
}

// eslint-disable-next-line no-unused-vars
export function errorHandler(err, req, res, next) {
  // Prefer an explicit status the error already carries (e.g. body-parser's
  // PayloadTooLargeError sets err.status = 413) over whatever res.statusCode
  // happens to be, which defaults to 200 and previously caused these to
  // fall through to a misleading 500.
  let statusCode =
    err.statusCode || err.status || (res.statusCode !== 200 ? res.statusCode : 500);
  let message = err.message || "Something went wrong.";

  // Mongoose bad ObjectId
  if (err.name === "CastError") {
    statusCode = 400;
    message = "Invalid ID format.";
  }

  // Mongoose duplicate key
  if (err.code === 11000) {
    statusCode = 409;
    const field = Object.keys(err.keyValue || {})[0];
    message = field ? `${field} already exists.` : "Duplicate value.";
  }

  // Mongoose validation errors
  if (err.name === "ValidationError") {
    statusCode = 400;
    message = Object.values(err.errors)
      .map((e) => e.message)
      .join(" ");
  }

  // body-parser payload-too-large
  if (err.type === "entity.too.large") {
    statusCode = 413;
    message = "Request body is too large.";
  }

  // In production, never leak internal error text for unexpected (5xx)
  // failures — only the deliberate, operational errors thrown above (with
  // their own clear messages and specific status codes) are safe to show.
  // 4xx messages (validation, auth, not-found) are intentionally
  // user-facing and unaffected by this.
  if (process.env.NODE_ENV === "production" && statusCode >= 500) {
    message = "Something went wrong on our end. Please try again shortly.";
  }

  res.status(statusCode).json({
    success: false,
    message,
    ...(process.env.NODE_ENV !== "production" && { stack: err.stack }),
  });
}
