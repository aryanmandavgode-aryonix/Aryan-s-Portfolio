import jwt from "jsonwebtoken";
import User from "../models/User.js";
import { asyncHandler } from "./errorHandler.js";
import { COOKIE_NAME } from "../utils/token.js";

export const requireAuth = asyncHandler(async (req, res, next) => {
  const token = req.cookies?.[COOKIE_NAME];

  if (!token) {
    res.status(401);
    throw new Error("Not authorized — please log in.");
  }

  let decoded;
  try {
    decoded = jwt.verify(token, process.env.JWT_SECRET);
  } catch {
    res.status(401);
    throw new Error("Not authorized — session invalid or expired.");
  }

  const user = await User.findById(decoded.id);
  if (!user) {
    res.status(401);
    throw new Error("Not authorized — user no longer exists.");
  }

  req.user = user;
  next();
});
