# ARYONIX — Aryan Mandavgode Portfolio

A production-ready personal portfolio and agency site for **Aryan Mandavgode** —
Computer Engineering student, full-stack developer, and founder of **ARYONIX**.
Built as two independently deployable apps that communicate over a REST API.

---

## 1. Project Overview

The site has two audiences and two matching parts:

- **Public site** — hero, about, skills, projects, experience, an ARYONIX brand
  section, and a contact form. Built to help Aryan land internships, attract
  freelance clients, and showcase ARYONIX.
- **Admin dashboard** (`/admin`) — a JWT-authenticated area where Aryan can
  manage projects, skills, and incoming contact messages without touching code.

## 2. Features

**Public site**
- Cinematic hero with the real profile photo, responsive across breakpoints
- Scroll-spy navbar with animated active-section indicator, mobile menu
- About, filterable Skills grid, Projects (grid + detail modal), Experience
  timeline, ARYONIX brand section
- Contact form validated end-to-end and wired to the API
- Restrained page-fade transitions, scroll-reveal animations
  (`prefers-reduced-motion` respected)
- Fully responsive: mobile, tablet, laptop, desktop, large screens

**Admin dashboard**
- Login page, protected routes (client- and server-side)
- Full CRUD for projects and skills
- View and delete contact messages
- Skeleton loading states, empty states, error states throughout

**Backend**
- REST API with input validation, centralized error handling, rate limiting
- JWT auth delivered via HTTP-only cookies (never exposed to client JS)
- bcrypt password hashing
- Environment-aware CORS, security headers (Helmet), production-safe error
  messages

## 3. Tech Stack

| Layer | Tech |
|---|---|
| Frontend | React 18, TypeScript, Vite, Tailwind CSS, Framer Motion, React Router, lucide-react |
| Backend | Node.js, Express, Mongoose |
| Database | MongoDB |
| Auth | JWT (HTTP-only cookies), bcryptjs |
| Validation | express-validator |
| Security | Helmet, express-rate-limit, environment-restricted CORS |

## 4. Folder Structure

```
aryonix-portfolio/
├── client/                          React + TypeScript + Vite
│   ├── public/
│   │   ├── images/                  profile photo (jpg + webp), favicon
│   │   ├── robots.txt
│   │   └── sitemap.xml
│   ├── src/
│   │   ├── components/
│   │   │   ├── admin/                ProtectedRoute, AdminLayout, form modal, shared states
│   │   │   ├── layout/                Navbar, Footer, BuildBar, PageTransition
│   │   │   ├── sections/              Hero, About, Skills, Projects, Experience, Aryonix, Contact
│   │   │   └── ui/                    Reveal, SectionHeading
│   │   ├── context/                   AuthContext (session state via HTTP-only cookie)
│   │   ├── data/                      static content for skills/projects/experience
│   │   ├── lib/                       api.ts (fetch wrapper), utils.ts
│   │   ├── pages/
│   │   │   ├── Home.tsx               public site
│   │   │   └── admin/                  AdminLogin, AdminDashboard, ProjectsManager, SkillsManager, MessagesManager
│   │   ├── types/                      shared TypeScript types
│   │   ├── App.tsx                     router (admin routes lazy-loaded)
│   │   └── main.tsx
│   ├── .env.example
│   └── package.json
│
└── server/                          Node.js + Express + MongoDB
    ├── src/
    │   ├── config/                    db.js (Mongoose connection), assertEnv.js (startup validation)
    │   ├── controllers/                auth, project, skill, contact
    │   ├── middleware/                 auth (JWT verify), errorHandler, validate, rateLimiters
    │   ├── models/                     User, Project, Skill, ContactMessage, Experience
    │   ├── routes/                     auth, project, skill, contact
    │   ├── utils/                      token (JWT + cookie helpers), seedAdmin.js, withCleanJSON.js
    │   ├── app.js                      Express app assembly
    │   └── server.js                   entry point
    ├── .env.example
    └── package.json
```

## 5. Local Installation

Requires Node.js 18+ and a MongoDB instance (local or Atlas).

```bash
git clone <your-repo-url>
cd aryonix-portfolio

# Backend
cd server
npm install
cp .env.example .env      # fill in the values — see section 6
npm run seed:admin        # creates the one admin account, run once
npm run dev                # http://localhost:5000

# Frontend (in a separate terminal)
cd client
npm install
cp .env.example .env
npm run dev                # http://localhost:5173
```

Visit `http://localhost:5173` for the public site, and
`http://localhost:5173/admin/login` to sign in with the `ADMIN_EMAIL` /
`ADMIN_PASSWORD` you set in `server/.env`.

## 6. Environment Variables

Never commit real `.env` files — only `.env.example` belongs in the repo.

**`server/.env`**

| Variable | Required | Description |
|---|---|---|
| `MONGODB_URI` | Yes | MongoDB connection string. Server refuses to start without it. |
| `JWT_SECRET` | Yes | Minimum 32 random characters. Server refuses to start if missing or too short. Generate with `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"` |
| `JWT_EXPIRES_IN` | No | Defaults to `7d` |
| `CLIENT_URL` | Yes | The deployed frontend's origin. Comma-separated for multiple origins (e.g. apex + www). No trailing slash. |
| `PORT` | No | Defaults to `5000`; most hosts set this automatically |
| `NODE_ENV` | Yes for prod | `development` / `production` / `test`. Production enables secure cookies, `trust proxy`, combined access logs, and generic (non-leaking) error messages. |
| `ADMIN_NAME` | For seeding | Used only by `npm run seed:admin` |
| `ADMIN_EMAIL` | For seeding | Used only by `npm run seed:admin` |
| `ADMIN_PASSWORD` | For seeding | Used only by `npm run seed:admin`, minimum 8 characters |

**`client/.env`**

| Variable | Required | Description |
|---|---|---|
| `VITE_API_URL` | Yes | The backend's API base URL, e.g. `http://localhost:5000/api` locally or `https://your-api.onrender.com/api` in production. Must be prefixed `VITE_` — Vite only exposes env vars with this prefix to client code. |

## 7. MongoDB Setup

**Local:**
```bash
# macOS (Homebrew)
brew install mongodb-community
brew services start mongodb-community
# MONGODB_URI=mongodb://localhost:27017/aryonix-portfolio
```

**MongoDB Atlas (recommended for production):**
1. Create a free cluster at mongodb.com/cloud/atlas
2. Database Access -> add a user with a strong, generated password
3. Network Access -> allow your deployment host's IP (or 0.0.0.0/0 if your
   host uses dynamic egress IPs — check its docs first)
4. Get the connection string and set it as `MONGODB_URI`, e.g.:
   `mongodb+srv://<user>:<password>@<cluster>.mongodb.net/aryonix-portfolio`

Indexes are already defined in the Mongoose schemas
(`Project`, `Skill`, `ContactMessage`) and created automatically on first
connection — no manual index setup needed.

## 8. Admin Setup

There is **no public registration endpoint** by design — the only way to
create an admin account is the seed script, which requires access to the
server's own `.env`:

```bash
cd server
npm run seed:admin
```

Running it again with the same `ADMIN_EMAIL` updates that account's password
instead of creating a duplicate.

## 9. Frontend Deployment

**Recommended: Vercel** (Netlify works identically for a Vite SPA)

1. Import the repo, set the root directory to `client`
2. Build command: `npm run build` — Output directory: `dist`
3. Add the environment variable `VITE_API_URL` pointing at your deployed backend
4. Since this is a client-side-routed SPA, add a rewrite so deep links
   (e.g. `/admin/login`) don't 404 on refresh:
   - Vercel: add `client/vercel.json`:
     ```json
     { "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }] }
     ```
   - Netlify: add `client/public/_redirects`:
     ```
     /*  /index.html  200
     ```
5. Deploy. Update `client/public/sitemap.xml` and the JSON-LD `url` field in
   `client/index.html` with your real domain.

## 10. Backend Deployment

**Recommended: Render** (Railway is an equally good alternative — avoid
serverless platforms unless you adapt the app for cold starts, since this
server keeps a persistent MongoDB connection)

1. New Web Service -> point at your repo, root directory `server`
2. Build command: `npm install` — Start command: `npm start`
3. Set all required environment variables (see section 6) —
   `NODE_ENV=production` is essential, not optional: it enables secure
   cookies, `trust proxy`, and safe error messages
4. Deploy, then run `npm run seed:admin` once via the host's shell/console
5. Confirm `GET https://your-api-host/health` returns
   `{"success":true,"message":"API is running."}`

## 11. Production Configuration Notes

- **Cross-origin cookies**: frontend and backend will be on different domains
  in production. The auth cookie uses `SameSite=None; Secure` when
  `NODE_ENV=production`, which requires both to be served over HTTPS —
  Vercel/Netlify and Render/Railway provide this by default.
- **CORS**: `CLIENT_URL` must exactly match your deployed frontend's origin
  (protocol + domain, no trailing slash). Comma-separate multiple origins if
  needed.
- **Error messages**: in production, unexpected server errors (5xx) return a
  generic message to the client — full details still go to your host's
  server logs for debugging.

---

## A. Final Project Structure

See section 4 above.

## B. All Environment Variables Required

See section 6 above.

## C. Exact Local Commands

```bash
# Backend
cd server && npm install && cp .env.example .env
npm run seed:admin
npm run dev

# Frontend
cd client && npm install && cp .env.example .env
npm run dev
```

## D. Exact Deployment Steps

1. Push the repo to GitHub (`.env` and `node_modules` are gitignored on both apps)
2. Deploy `/server` to Render/Railway with the env vars from section 6, `NODE_ENV=production`
3. Run `npm run seed:admin` once against the deployed backend
4. Deploy `/client` to Vercel/Netlify with `VITE_API_URL` pointing at the
   deployed backend, plus the SPA rewrite rule from section 9
5. Set the backend's `CLIENT_URL` to the deployed frontend's exact origin and
   redeploy the backend if it was set before the frontend URL was known
6. Verify: load the public site, submit the contact form, log into
   `/admin/login`, and confirm project/skill CRUD works end-to-end

## E. Frontend Deployment Recommendation

**Vercel.** Zero-config for Vite, generous free tier, automatic HTTPS,
instant preview deployments per PR. Netlify is an equally good alternative.

## F. Backend Deployment Recommendation

**Render.** Simple environment-variable management, free tier available,
persistent Node process (this app is not built for serverless — it keeps a
long-lived MongoDB connection). Railway is an equally good alternative.

## G. MongoDB Deployment/Setup Steps

See section 7 above. **MongoDB Atlas** (free M0 tier) is recommended over
self-hosting for production — managed backups, no server maintenance.

## H. Final Security Checklist

- [x] Passwords hashed with bcrypt (cost factor 12), never returned by any API response
- [x] JWT stored only in an `HttpOnly` cookie — inaccessible to client-side JS
- [x] `Secure` + `SameSite=None` cookies enforced automatically when `NODE_ENV=production`
- [x] No public registration endpoint — admin created only via `seed:admin`
- [x] Login timing-safe against email enumeration (dummy bcrypt comparison for unknown emails)
- [x] All project/skill mutations and contact-message read/delete require a valid session (`requireAuth`)
- [x] CORS restricted to explicitly configured origin(s); disallowed origins receive `403`
- [x] Rate limiting on `/api/contact` (5/15min) and `/api/auth/login` (10/15min), with `trust proxy` set correctly for accurate client IPs in production
- [x] Input validated on every write endpoint (express-validator); malformed requests return `422`
- [x] Request body size capped at 10kb; oversized requests correctly return `413`
- [x] Helmet security headers on every response (HSTS, X-Frame-Options, X-Content-Type-Options, CSP)
- [x] Server refuses to start if `MONGODB_URI` or `JWT_SECRET` (min. 32 chars) are missing
- [x] Unexpected server errors return a generic message in production — no internal details or stack traces leaked
- [x] No secrets committed to the repo; `.env` files gitignored on both apps
- [x] No secrets present in the compiled frontend bundle (verified)

## I. Final Testing Checklist

- [x] `tsc -b` — zero TypeScript errors
- [x] `npm run build` (client) — succeeds, no warnings
- [x] `eslint --max-warnings 0` — zero lint errors/warnings
- [x] Backend syntax-checked across every file (`node --check`)
- [x] Server boots and serves `/health` correctly
- [x] Server refuses to boot with missing/invalid `JWT_SECRET` or `MONGODB_URI`
- [x] All protected routes return `401` without a valid session
- [x] Contact form validation rejects malformed input (`422`) and rate-limits after 5 requests (`429`)
- [x] Login rejects invalid credentials and malformed input; CORS blocks disallowed origins (`403`)
- [x] No `console.log`/`debugger` statements in shipped code
- [x] No broken image/favicon references (all static assets verified to return `200`)
- [x] Color contrast meets WCAG AA on all text
- [ ] Full login -> admin CRUD flow against a live MongoDB instance — not
      verified in this environment (no MongoDB server available in the build
      sandbox); verify this once deployed, before considering it fully sign-off ready
