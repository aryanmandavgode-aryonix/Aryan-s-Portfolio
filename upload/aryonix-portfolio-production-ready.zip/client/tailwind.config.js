/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        void: "#08090C",
        surface: "#101218",
        "surface-raised": "#15171F",
        ink: "#F4F5F7",
        "ink-muted": "#8B90A0",
        "accent-blue": "#5B7CFA",
        "accent-violet": "#8B5CF6",
        line: "#1E212B",
      },
      fontFamily: {
        display: ["'Space Grotesk'", "sans-serif"],
        body: ["'Inter'", "sans-serif"],
        mono: ["'JetBrains Mono'", "monospace"],
      },
      backgroundImage: {
        "accent-glow":
          "radial-gradient(60% 60% at 50% 40%, rgba(91,124,250,0.18) 0%, rgba(139,92,246,0.08) 45%, rgba(8,9,12,0) 100%)",
      },
      boxShadow: {
        card: "0 1px 0 0 rgba(255,255,255,0.04) inset, 0 20px 60px -20px rgba(0,0,0,0.6)",
      },
    },
  },
  plugins: [],
};
