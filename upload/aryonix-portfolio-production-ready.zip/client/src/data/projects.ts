import type { Project } from "@/types";

export const PROJECTS: Project[] = [
  {
    id: "aryonix",
    name: "ARYONIX",
    description:
      "A modern digital platform and development initiative focused on creating premium websites and digital experiences.",
    technologies: ["Next.js", "TypeScript", "Tailwind CSS", "Prisma", "MongoDB"],
    overview: "The agency platform behind ARYONIX's client work — brand, process, and case studies in one place.",
    problem: "Placeholder — replace with the real problem this project solves.",
    solution: "Placeholder — replace with the real approach taken.",
    features: ["Placeholder feature one", "Placeholder feature two"],
    githubUrl: "https://github.com/aryanmandavgode-aryonix",
  },
  {
    id: "neural-city-aqi",
    name: "Neural City AQI Dashboard",
    description:
      "A dashboard-style project for visualizing city air quality data. Placeholder — replace with real scope and screenshots.",
    technologies: ["React", "TypeScript", "Node.js", "Chart library"],
    overview: "Placeholder overview.",
    problem: "Placeholder — replace with the real problem this project solves.",
    solution: "Placeholder — replace with the real approach taken.",
    features: ["Placeholder feature one", "Placeholder feature two"],
    isPlaceholder: true,
  },
  {
    id: "ecommerce-platform",
    name: "E-Commerce Platform",
    description:
      "Full-stack MERN e-commerce placeholder — product catalog, cart, and checkout flow to be detailed.",
    technologies: ["MongoDB", "Express.js", "React", "Node.js"],
    overview: "Placeholder overview.",
    problem: "Placeholder — replace with the real problem this project solves.",
    solution: "Placeholder — replace with the real approach taken.",
    features: ["Placeholder feature one", "Placeholder feature two"],
    isPlaceholder: true,
  },
  {
    id: "business-dashboard",
    name: "Business Management Dashboard",
    description:
      "MERN dashboard placeholder for internal business operations — replace with real modules once built.",
    technologies: ["MongoDB", "Express.js", "React", "Node.js"],
    overview: "Placeholder overview.",
    problem: "Placeholder — replace with the real problem this project solves.",
    solution: "Placeholder — replace with the real approach taken.",
    features: ["Placeholder feature one", "Placeholder feature two"],
    isPlaceholder: true,
  },
];
