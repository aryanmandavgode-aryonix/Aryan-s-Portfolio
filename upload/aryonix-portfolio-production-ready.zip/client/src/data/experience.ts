import type { ExperienceItem } from "@/types";

export const EXPERIENCE: ExperienceItem[] = [
  {
    id: "aryonix",
    organization: "ARYONIX",
    role: "Founder / Full-Stack Developer",
    period: "Ongoing",
    points: [
      "Building websites and digital products end to end",
      "Working across frontend and backend development",
      "Client-oriented product development from brief to launch",
      "UI/UX implementation for premium digital experiences",
    ],
  },
  {
    id: "education",
    organization: "Ajeenkya DY Patil School of Engineering",
    role: "Computer Engineering",
    period: "In progress",
    points: [
      "Coursework spanning core computer engineering and software development",
    ],
  },
];
