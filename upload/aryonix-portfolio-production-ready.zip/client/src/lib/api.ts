import type { Project, Skill } from "@/types";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";

interface ApiErrorField {
  field: string;
  message: string;
}

interface ApiEnvelope<T> {
  success: boolean;
  message?: string;
  errors?: ApiErrorField[];
  data?: T;
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_URL}${path}`, {
    credentials: "include", // sends/receives the HTTP-only auth cookie
    headers: { "Content-Type": "application/json", ...options.headers },
    ...options,
  });

  const body: ApiEnvelope<T> = await res.json().catch(() => ({ success: false }));

  if (!res.ok) {
    throw new Error(
      body.errors?.map((e) => e.message).join(" ") || body.message || "Something went wrong."
    );
  }

  return body.data as T;
}

// ---- Public: contact form ----

export interface ContactFormPayload {
  name: string;
  email: string;
  company?: string;
  projectType: string;
  message: string;
}

export function submitContactForm(payload: ContactFormPayload) {
  return request<{ id: string }>("/contact", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

// ---- Auth ----

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: string;
}

export function login(email: string, password: string) {
  return request<AuthUser>("/auth/login", {
    method: "POST",
    body: JSON.stringify({ email, password }),
  });
}

export function logout() {
  return request<null>("/auth/logout", { method: "POST" });
}

export function getMe() {
  return request<AuthUser>("/auth/me");
}

// ---- Admin: projects ----

export function adminListProjects() {
  return request<Project[]>("/projects");
}

export function adminCreateProject(payload: Partial<Project>) {
  return request<Project>("/projects", { method: "POST", body: JSON.stringify(payload) });
}

export function adminUpdateProject(id: string, payload: Partial<Project>) {
  return request<Project>(`/projects/${id}`, { method: "PUT", body: JSON.stringify(payload) });
}

export function adminDeleteProject(id: string) {
  return request<{ id: string }>(`/projects/${id}`, { method: "DELETE" });
}

// ---- Admin: skills ----

export function adminListSkills() {
  return request<Skill[]>("/skills");
}

export function adminCreateSkill(payload: Skill) {
  return request<Skill & { _id: string }>("/skills", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export function adminUpdateSkill(id: string, payload: Skill) {
  return request<Skill & { _id: string }>(`/skills/${id}`, {
    method: "PUT",
    body: JSON.stringify(payload),
  });
}

export function adminDeleteSkill(id: string) {
  return request<{ id: string }>(`/skills/${id}`, { method: "DELETE" });
}

// ---- Admin: contact messages ----

export interface ContactMessageRecord {
  _id: string;
  name: string;
  email: string;
  company?: string;
  projectType: string;
  message: string;
  createdAt: string;
}

export function adminListMessages() {
  return request<ContactMessageRecord[]>("/contact");
}

export function adminDeleteMessage(id: string) {
  return request<{ id: string }>(`/contact/${id}`, { method: "DELETE" });
}
