import { Suspense, lazy } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import { Loader2 } from "lucide-react";
import Home from "@/pages/Home";
import ProtectedRoute from "@/components/admin/ProtectedRoute";
import PageTransition from "@/components/layout/PageTransition";

// Admin is a separate chunk — public visitors (recruiters, clients) never
// pay for its bundle weight since they never navigate to /admin.
const AdminLogin = lazy(() => import("@/pages/admin/AdminLogin"));
const AdminDashboard = lazy(() => import("@/pages/admin/AdminDashboard"));

function AdminFallback() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-void">
      <Loader2 className="animate-spin text-ink-muted" size={24} />
    </div>
  );
}

export default function App() {
  const location = useLocation();

  return (
    <>
      <a href="#main-content" className="skip-link">
        Skip to content
      </a>

      <AnimatePresence mode="wait">
        <Routes location={location} key={location.pathname}>
          <Route
            path="/"
            element={
              <PageTransition>
                <Home />
              </PageTransition>
            }
          />
          <Route
            path="/admin/login"
            element={
              <Suspense fallback={<AdminFallback />}>
                <PageTransition>
                  <AdminLogin />
                </PageTransition>
              </Suspense>
            }
          />
          <Route
            path="/admin/dashboard/*"
            element={
              <Suspense fallback={<AdminFallback />}>
                <ProtectedRoute>
                  <PageTransition>
                    <AdminDashboard />
                  </PageTransition>
                </ProtectedRoute>
              </Suspense>
            }
          />
        </Routes>
      </AnimatePresence>
    </>
  );
}
