import { useEffect, useState } from "react";
import { Trash2, Loader2, Mail } from "lucide-react";
import * as api from "@/lib/api";
import type { ContactMessageRecord } from "@/lib/api";
import { SkeletonRows, EmptyState, ErrorBanner } from "@/components/admin/AdminStates";

export default function MessagesManager() {
  const [messages, setMessages] = useState<ContactMessageRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [deletingId, setDeletingId] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    try {
      const data = await api.adminListMessages();
      setMessages(data);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load messages.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function handleDelete(id: string) {
    if (!confirm("Delete this message?")) return;
    setDeletingId(id);
    try {
      await api.adminDeleteMessage(id);
      setMessages((prev) => prev.filter((m) => m._id !== id));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to delete message.");
    } finally {
      setDeletingId(null);
    }
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold">Messages</h1>

      {error && <ErrorBanner message={error} />}

      {loading ? (
        <SkeletonRows count={3} />
      ) : messages.length === 0 ? (
        <EmptyState
          icon={Mail}
          title="No messages yet."
          hint="Submissions from the contact form will show up here."
        />
      ) : (
        <div className="mt-6 space-y-3">
          {messages.map((msg) => (
            <div
              key={msg._id}
              className="glass-panel rounded-xl p-5 transition-colors hover:border-line/80"
            >
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="text-sm font-medium">{msg.name}</p>
                  <p className="text-xs text-ink-muted">{msg.email}</p>
                  {msg.company && <p className="text-xs text-ink-muted">{msg.company}</p>}
                </div>
                <div className="flex items-center gap-2">
                  <span className="rounded-full border border-line px-2.5 py-1 text-[11px] text-ink-muted">
                    {msg.projectType}
                  </span>
                  <button
                    onClick={() => handleDelete(msg._id)}
                    disabled={deletingId === msg._id}
                    className="rounded-full border border-line p-2 text-ink-muted transition-colors hover:border-red-400/40 hover:text-red-400 disabled:opacity-50"
                    aria-label={`Delete message from ${msg.name}`}
                  >
                    {deletingId === msg._id ? (
                      <Loader2 size={14} className="animate-spin" />
                    ) : (
                      <Trash2 size={14} />
                    )}
                  </button>
                </div>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-ink-muted">{msg.message}</p>
              <p className="mt-3 text-[11px] text-ink-muted">
                {new Date(msg.createdAt).toLocaleString()}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
