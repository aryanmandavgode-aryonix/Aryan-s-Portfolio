import { useEffect, useState } from "react";
import { Plus, Pencil, Trash2, Loader2, FolderKanban } from "lucide-react";
import * as api from "@/lib/api";
import type { Project } from "@/types";
import ProjectFormModal from "@/components/admin/ProjectFormModal";
import { SkeletonRows, EmptyState, ErrorBanner } from "@/components/admin/AdminStates";

export default function ProjectsManager() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Project | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    try {
      const data = await api.adminListProjects();
      setProjects(data);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load projects.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  function openCreate() {
    setEditing(null);
    setModalOpen(true);
  }

  function openEdit(project: Project) {
    setEditing(project);
    setModalOpen(true);
  }

  async function handleSave(payload: Partial<Project>) {
    if (editing) {
      await api.adminUpdateProject(editing.id, payload);
    } else {
      await api.adminCreateProject(payload);
    }
    await load();
  }

  async function handleDelete(id: string) {
    if (!confirm("Delete this project? This can't be undone.")) return;
    setDeletingId(id);
    try {
      await api.adminDeleteProject(id);
      setProjects((prev) => prev.filter((p) => p.id !== id));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to delete project.");
    } finally {
      setDeletingId(null);
    }
  }

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-semibold">Projects</h1>
        <button
          onClick={openCreate}
          className="inline-flex items-center gap-2 rounded-full bg-ink px-4 py-2.5 text-sm font-medium text-void transition-opacity hover:opacity-90"
        >
          <Plus size={16} /> Add Project
        </button>
      </div>

      {error && <ErrorBanner message={error} />}

      {loading ? (
        <SkeletonRows count={4} />
      ) : projects.length === 0 ? (
        <EmptyState
          icon={FolderKanban}
          title="No projects yet."
          hint="Add your first one to see it here and on the public site."
        />
      ) : (
        <div className="mt-6 space-y-3">
          {projects.map((project) => (
            <div
              key={project.id}
              className="glass-panel flex items-center justify-between gap-4 rounded-xl p-4 transition-colors hover:border-line/80"
            >
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">{project.name}</p>
                <p className="truncate text-xs text-ink-muted">{project.description}</p>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <button
                  onClick={() => openEdit(project)}
                  className="rounded-full border border-line p-2 text-ink-muted transition-colors hover:border-accent-blue/40 hover:text-ink"
                  aria-label={`Edit ${project.name}`}
                >
                  <Pencil size={14} />
                </button>
                <button
                  onClick={() => handleDelete(project.id)}
                  disabled={deletingId === project.id}
                  className="rounded-full border border-line p-2 text-ink-muted transition-colors hover:border-red-400/40 hover:text-red-400 disabled:opacity-50"
                  aria-label={`Delete ${project.name}`}
                >
                  {deletingId === project.id ? (
                    <Loader2 size={14} className="animate-spin" />
                  ) : (
                    <Trash2 size={14} />
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <ProjectFormModal
        key={editing?.id ?? "new"}
        project={editing}
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        onSave={handleSave}
      />
    </div>
  );
}
