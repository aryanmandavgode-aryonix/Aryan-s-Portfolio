import { useEffect, useState, type FormEvent } from "react";
import { Plus, Trash2, Loader2, Code2 } from "lucide-react";
import * as api from "@/lib/api";
import type { Skill, SkillCategory } from "@/types";
import { SkeletonRows, EmptyState, ErrorBanner } from "@/components/admin/AdminStates";

const CATEGORIES: SkillCategory[] = ["Frontend", "Backend", "Database", "Tools"];

interface SkillRecord extends Skill {
  _id: string;
}

export default function SkillsManager() {
  const [skills, setSkills] = useState<SkillRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const [name, setName] = useState("");
  const [category, setCategory] = useState<SkillCategory>("Frontend");
  const [adding, setAdding] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const data = (await api.adminListSkills()) as SkillRecord[];
      setSkills(data);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load skills.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function handleAdd(e: FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    setAdding(true);
    try {
      await api.adminCreateSkill({ name: name.trim(), category });
      setName("");
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to add skill.");
    } finally {
      setAdding(false);
    }
  }

  async function handleDelete(id: string) {
    if (!confirm("Delete this skill?")) return;
    setDeletingId(id);
    try {
      await api.adminDeleteSkill(id);
      setSkills((prev) => prev.filter((s) => s._id !== id));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to delete skill.");
    } finally {
      setDeletingId(null);
    }
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold">Skills</h1>

      <form
        onSubmit={handleAdd}
        className="glass-panel mt-6 flex flex-col gap-3 rounded-xl p-4 sm:flex-row sm:items-end"
      >
        <label className="block flex-1">
          <span className="mb-1.5 block text-xs font-medium text-ink-muted">Skill name</span>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="form-input"
            placeholder="e.g. GraphQL"
          />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-xs font-medium text-ink-muted">Category</span>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value as SkillCategory)}
            className="form-input"
          >
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </label>
        <button
          type="submit"
          disabled={adding || !name.trim()}
          className="inline-flex items-center justify-center gap-2 rounded-full bg-ink px-4 py-3 text-sm font-medium text-void transition-opacity hover:opacity-90 disabled:opacity-50"
        >
          {adding ? <Loader2 size={16} className="animate-spin" /> : <Plus size={16} />}
          Add
        </button>
      </form>

      {error && <ErrorBanner message={error} />}

      {loading ? (
        <SkeletonRows count={6} />
      ) : skills.length === 0 ? (
        <EmptyState icon={Code2} title="No skills yet." hint="Add one above to get started." />
      ) : (
        <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {skills.map((skill) => (
            <div
              key={skill._id}
              className="glass-panel flex items-center justify-between rounded-xl p-4 transition-colors hover:border-line/80"
            >
              <div>
                <p className="text-sm font-medium">{skill.name}</p>
                <p className="eyebrow mt-1 !text-[10px]">{skill.category}</p>
              </div>
              <button
                onClick={() => handleDelete(skill._id)}
                disabled={deletingId === skill._id}
                className="rounded-full border border-line p-2 text-ink-muted transition-colors hover:border-red-400/40 hover:text-red-400 disabled:opacity-50"
                aria-label={`Delete ${skill.name}`}
              >
                {deletingId === skill._id ? (
                  <Loader2 size={14} className="animate-spin" />
                ) : (
                  <Trash2 size={14} />
                )}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
