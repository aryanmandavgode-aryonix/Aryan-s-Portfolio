import { useState, type FormEvent } from "react";
import { useNavigate, Navigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Lock, Loader2, AlertCircle } from "lucide-react";
import { useAuth } from "@/context/useAuth";

export default function AdminLogin() {
  const { user, loading, login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  if (!loading && user) {
    return <Navigate to="/admin/dashboard" replace />;
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError("");
    try {
      await login(email, password);
      navigate("/admin/dashboard", { replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center bg-void px-6">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 bg-accent-glow" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        className="glass-panel relative w-full max-w-sm rounded-2xl p-8"
      >
        <div className="mx-auto flex h-11 w-11 items-center justify-center rounded-full border border-line">
          <Lock size={18} className="text-accent-blue" strokeWidth={1.75} />
        </div>

        <h1 className="mt-6 text-center font-display text-xl font-semibold">Admin Login</h1>
        <p className="mt-1.5 text-center text-sm text-ink-muted">ARYONIX portfolio dashboard</p>

        <form onSubmit={handleSubmit} className="mt-8 space-y-4">
          <label className="block">
            <span className="mb-2 block text-xs font-medium text-ink-muted">Email</span>
            <input
              required
              type="email"
              autoComplete="username"
              autoFocus
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="form-input"
              placeholder="admin@example.com"
            />
          </label>

          <label className="block">
            <span className="mb-2 block text-xs font-medium text-ink-muted">Password</span>
            <input
              required
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="form-input"
              placeholder="••••••••"
            />
          </label>

          <button
            type="submit"
            disabled={submitting}
            className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-ink px-6 py-3.5 text-sm font-medium text-void transition-opacity disabled:opacity-60"
          >
            {submitting && <Loader2 size={16} className="animate-spin" />}
            {submitting ? "Signing in..." : "Sign In"}
          </button>

          {error && (
            <p role="alert" className="flex items-center gap-2 text-sm text-red-400">
              <AlertCircle size={16} />
              {error}
            </p>
          )}
        </form>
      </motion.div>
    </div>
  );
}
