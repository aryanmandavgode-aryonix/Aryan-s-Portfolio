import { Routes, Route, Navigate } from "react-router-dom";
import AdminLayout from "@/components/admin/AdminLayout";
import ProjectsManager from "@/pages/admin/ProjectsManager";
import SkillsManager from "@/pages/admin/SkillsManager";
import MessagesManager from "@/pages/admin/MessagesManager";

export default function AdminDashboard() {
  return (
    <AdminLayout>
      <Routes>
        <Route index element={<Navigate to="projects" replace />} />
        <Route path="projects" element={<ProjectsManager />} />
        <Route path="skills" element={<SkillsManager />} />
        <Route path="messages" element={<MessagesManager />} />
      </Routes>
    </AdminLayout>
  );
}
