export type SkillCategory = "Frontend" | "Backend" | "Database" | "Tools";

export interface Skill {
  name: string;
  category: SkillCategory;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  technologies: string[];
  image?: string;
  githubUrl?: string;
  liveUrl?: string;
  /** Marks entries that are placeholders to be swapped for real project details later. */
  isPlaceholder?: boolean;
  overview?: string;
  problem?: string;
  solution?: string;
  features?: string[];
}

export interface ExperienceItem {
  id: string;
  organization: string;
  role: string;
  period: string;
  points: string[];
}

export interface AboutStat {
  label: string;
  value: string;
}
