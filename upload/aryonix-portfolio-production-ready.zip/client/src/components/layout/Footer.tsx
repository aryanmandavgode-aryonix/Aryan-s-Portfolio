import { Github, Linkedin, Instagram } from "lucide-react";

const FOOTER_LINKS = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Projects", href: "#projects" },
  { label: "Contact", href: "#contact" },
];

const SOCIALS = [
  { label: "GitHub", href: "https://github.com/aryanmandavgode-aryonix", icon: Github },
  { label: "LinkedIn", href: "https://www.linkedin.com/in/aryan-mandavgode", icon: Linkedin },
  { label: "Instagram", href: "https://www.instagram.com/aryonix.in", icon: Instagram },
];

export default function Footer() {
  return (
    <footer className="border-t border-line">
      <div className="mx-auto max-w-6xl px-6 py-12 lg:px-8">
        <div className="flex flex-col items-start justify-between gap-8 sm:flex-row sm:items-center">
          <div>
            <p className="font-display text-lg font-semibold">ARYONIX</p>
            <p className="eyebrow mt-1 !normal-case !tracking-normal">
              Design. Develop. Deploy.
            </p>
          </div>

          <ul className="flex flex-wrap gap-6">
            {FOOTER_LINKS.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="text-sm text-ink-muted transition-colors hover:text-ink"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>

          <div className="flex gap-4">
            {SOCIALS.map((social) => {
              const Icon = social.icon;
              return (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={social.label}
                  className="rounded-full border border-line p-2.5 text-ink-muted transition-colors hover:border-accent-blue/50 hover:text-ink"
                >
                  <Icon size={16} />
                </a>
              );
            })}
          </div>
        </div>

        <p className="mt-10 text-xs text-ink-muted">
          © {new Date().getFullYear()} Aryan Mandavgode. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
