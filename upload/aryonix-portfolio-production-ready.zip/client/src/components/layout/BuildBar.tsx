import { motion } from "framer-motion";

const STAGES = ["Design", "Develop", "Deploy"] as const;

/**
 * Fixed hairline bar at the very top of the viewport. Three segments light up
 * in sequence on load, echoing the ARYONIX tagline as a literal build/compile
 * progress indicator rather than a decorative loading bar.
 */
export default function BuildBar() {
  return (
    <div
      className="fixed top-0 left-0 right-0 z-[60] flex h-[3px] w-full"
      role="presentation"
      aria-hidden="true"
    >
      {STAGES.map((stage, i) => (
        <motion.div
          key={stage}
          className="h-full flex-1 origin-left bg-gradient-to-r from-accent-blue to-accent-violet"
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{
            duration: 0.6,
            delay: 0.3 + i * 0.25,
            ease: [0.22, 1, 0.36, 1],
          }}
        />
      ))}
    </div>
  );
}
