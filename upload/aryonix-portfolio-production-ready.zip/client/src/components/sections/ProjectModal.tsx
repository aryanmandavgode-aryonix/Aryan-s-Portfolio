import { AnimatePresence, motion } from "framer-motion";
import { X, Github, ExternalLink } from "lucide-react";
import { useEffect, useRef } from "react";
import type { Project } from "@/types";

interface ProjectModalProps {
  project: Project | null;
  onClose: () => void;
}

export default function ProjectModal({ project, onClose }: ProjectModalProps) {
  const closeButtonRef = useRef<HTMLButtonElement>(null);
  const previouslyFocused = useRef<HTMLElement | null>(null);

  // Close on Escape; move focus into the dialog on open and restore it on close.
  useEffect(() => {
    if (!project) return;

    previouslyFocused.current = document.activeElement as HTMLElement;
    closeButtonRef.current?.focus();

    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";

    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
      previouslyFocused.current?.focus();
    };
  }, [project, onClose]);

  return (
    <AnimatePresence>
      {project && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[70] flex items-center justify-center bg-void/80 p-4 backdrop-blur-sm"
          onClick={onClose}
          role="dialog"
          aria-modal="true"
          aria-label={`${project.name} details`}
        >
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.98 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            onClick={(e) => e.stopPropagation()}
            className="glass-panel max-h-[85vh] w-full max-w-2xl overflow-y-auto rounded-2xl p-8"
          >
            <div className="flex items-start justify-between gap-4">
              <h3 className="font-display text-2xl font-semibold">{project.name}</h3>
              <button
                ref={closeButtonRef}
                onClick={onClose}
                aria-label="Close"
                className="rounded-full p-1.5 text-ink-muted transition-colors hover:bg-surface-raised hover:text-ink"
              >
                <X size={20} />
              </button>
            </div>

            <div className="mt-6 aspect-video w-full rounded-xl bg-surface-raised">
              <div className="flex h-full items-center justify-center">
                <span className="text-xs text-ink-muted">Screenshots coming soon</span>
              </div>
            </div>

            <div className="mt-6 space-y-5 text-sm leading-relaxed text-ink-muted">
              {project.overview && (
                <div>
                  <p className="eyebrow mb-1.5 text-ink">Overview</p>
                  <p>{project.overview}</p>
                </div>
              )}
              {project.problem && (
                <div>
                  <p className="eyebrow mb-1.5 text-ink">Problem</p>
                  <p>{project.problem}</p>
                </div>
              )}
              {project.solution && (
                <div>
                  <p className="eyebrow mb-1.5 text-ink">Solution</p>
                  <p>{project.solution}</p>
                </div>
              )}
              {project.features && project.features.length > 0 && (
                <div>
                  <p className="eyebrow mb-1.5 text-ink">Features</p>
                  <ul className="list-inside list-disc space-y-1">
                    {project.features.map((f) => (
                      <li key={f}>{f}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div className="mt-6 flex flex-wrap gap-2">
              {project.technologies.map((tech) => (
                <span
                  key={tech}
                  className="rounded-full border border-line px-2.5 py-1 text-[11px] text-ink-muted"
                >
                  {tech}
                </span>
              ))}
            </div>

            <div className="mt-8 flex items-center gap-4">
              {project.githubUrl && (
                <a
                  href={project.githubUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 rounded-full border border-line px-5 py-2.5 text-sm font-medium transition-colors hover:border-accent-blue/60"
                >
                  <Github size={16} /> GitHub
                </a>
              )}
              {project.liveUrl && (
                <a
                  href={project.liveUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 rounded-full bg-ink px-5 py-2.5 text-sm font-medium text-void"
                >
                  <ExternalLink size={16} /> Live Demo
                </a>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
