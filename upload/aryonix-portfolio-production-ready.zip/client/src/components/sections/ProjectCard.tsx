import { Github, ExternalLink } from "lucide-react";
import type { Project } from "@/types";

interface ProjectCardProps {
  project: Project;
  onOpen: (project: Project) => void;
}

export default function ProjectCard({ project, onOpen }: ProjectCardProps) {
  return (
    <div className="glass-panel card-hover group flex flex-col overflow-hidden rounded-2xl">
      {/* Image placeholder — swap for real screenshots via admin later.
          A faint technical grid reads as "studio" rather than a flat AI-gradient card. */}
      <button
        onClick={() => onOpen(project)}
        aria-label={`View details for ${project.name}`}
        className="group/media relative aspect-[16/10] w-full overflow-hidden bg-surface-raised text-left"
      >
        <div
          aria-hidden="true"
          className="absolute inset-0 transition-transform duration-500 ease-out group-hover/media:scale-[1.04]"
          style={{
            backgroundImage:
              "linear-gradient(rgba(139,144,160,0.08) 1px, transparent 1px), linear-gradient(90deg, rgba(139,144,160,0.08) 1px, transparent 1px)",
            backgroundSize: "28px 28px",
          }}
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-t from-void via-void/10 to-transparent"
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="font-display text-2xl font-semibold text-ink/25">
            {project.name}
          </span>
        </div>
        {project.isPlaceholder && (
          <span className="eyebrow absolute left-4 top-4 rounded-full border border-line bg-void/80 px-3 py-1 !text-[10px]">
            Placeholder
          </span>
        )}
      </button>

      <div className="flex flex-1 flex-col p-6">
        <h3 className="font-display text-lg font-semibold">{project.name}</h3>
        <p className="mt-2 flex-1 text-sm leading-relaxed text-ink-muted">
          {project.description}
        </p>

        <div className="mt-4 flex flex-wrap gap-2">
          {project.technologies.map((tech) => (
            <span
              key={tech}
              className="rounded-full border border-line px-2.5 py-1 text-[11px] text-ink-muted"
            >
              {tech}
            </span>
          ))}
        </div>

        <div className="mt-6 flex items-center gap-3">
          <button
            onClick={() => onOpen(project)}
            className="text-sm font-medium text-accent-blue transition-colors hover:text-ink"
          >
            View details
          </button>
          {(project.githubUrl || project.liveUrl) && (
            <span className="text-line" aria-hidden="true">
              •
            </span>
          )}
          {project.githubUrl && (
            <a
              href={project.githubUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 text-sm text-ink-muted transition-colors hover:text-ink"
            >
              <Github size={14} /> Code
            </a>
          )}
          {project.liveUrl && (
            <a
              href={project.liveUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 text-sm text-ink-muted transition-colors hover:text-ink"
            >
              <ExternalLink size={14} /> Live
            </a>
          )}
        </div>
      </div>
    </div>
  );
}
