import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import SectionHeading from "@/components/ui/SectionHeading";
import Reveal from "@/components/ui/Reveal";
import { SKILLS, SKILL_CATEGORIES } from "@/data/skills";
import { cn } from "@/lib/utils";
import type { SkillCategory } from "@/types";

type Filter = SkillCategory | "All";

export default function Skills() {
  const [filter, setFilter] = useState<Filter>("All");

  const visibleSkills = useMemo(
    () => (filter === "All" ? SKILLS : SKILLS.filter((s) => s.category === filter)),
    [filter]
  );

  return (
    <section id="skills" className="relative py-24 lg:py-32">
      <div className="mx-auto max-w-6xl px-6 lg:px-8">
        <SectionHeading eyebrow="Skills" title="What I Build With." />

        {/* Filter tabs */}
        <Reveal delay={0.1} className="mt-10 flex flex-wrap gap-2">
          {(["All", ...SKILL_CATEGORIES] as Filter[]).map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={cn(
                "rounded-full border px-4 py-2 text-xs font-medium transition-colors",
                filter === cat
                  ? "border-accent-blue/60 bg-accent-blue/10 text-ink"
                  : "border-line text-ink-muted hover:border-line hover:text-ink"
              )}
            >
              {cat}
            </button>
          ))}
        </Reveal>

        {/* Skill grid */}
        <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {visibleSkills.map((skill, i) => (
            <motion.div
              key={skill.name}
              layout
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, delay: i * 0.03 }}
              className="glass-panel card-hover group rounded-xl px-4 py-4"
            >
              <p className="text-sm font-medium text-ink">{skill.name}</p>
              <p className="eyebrow mt-1.5 !text-[10px] text-ink-muted group-hover:text-accent-blue">
                {skill.category}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
