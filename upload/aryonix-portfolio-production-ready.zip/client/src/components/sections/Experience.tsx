import SectionHeading from "@/components/ui/SectionHeading";
import Reveal from "@/components/ui/Reveal";
import { EXPERIENCE } from "@/data/experience";

export default function Experience() {
  return (
    <section id="experience" className="relative py-24 lg:py-32">
      <div className="mx-auto max-w-6xl px-6 lg:px-8">
        <SectionHeading eyebrow="Experience" title="Where I've Been Building." />

        <div className="relative mt-14 max-w-2xl">
          {/* Vertical spine */}
          <div className="absolute left-[7px] top-2 bottom-2 w-px bg-line" />

          <ol className="space-y-12">
            {EXPERIENCE.map((item, i) => (
              <Reveal key={item.id} delay={i * 0.1}>
                <li className="relative pl-8">
                  <span className="absolute left-0 top-1.5 h-3.5 w-3.5 rounded-full border-2 border-accent-blue bg-void" />
                  <p className="eyebrow mb-1">{item.period}</p>
                  <h3 className="font-display text-lg font-semibold">{item.role}</h3>
                  <p className="text-sm text-ink-muted">{item.organization}</p>
                  <ul className="mt-3 space-y-1.5">
                    {item.points.map((point) => (
                      <li key={point} className="text-sm leading-relaxed text-ink-muted">
                        — {point}
                      </li>
                    ))}
                  </ul>
                </li>
              </Reveal>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
