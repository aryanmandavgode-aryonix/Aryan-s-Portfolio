import { motion } from "framer-motion";
import { ArrowRight, ArrowUpRight } from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  show: (delay = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] },
  }),
};

export default function Hero() {
  return (
    <section
      id="home"
      className="relative flex min-h-screen items-center overflow-hidden pt-28 pb-16 lg:pt-32"
    >
      {/* Ambient accent glow — the only gradient wash on the page */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 bg-accent-glow" />

      <div className="relative mx-auto grid w-full max-w-6xl grid-cols-1 items-center gap-14 px-6 lg:grid-cols-[1.1fr_0.9fr] lg:gap-10 lg:px-8">
        {/* Left — copy */}
        <div>
          <motion.p
            variants={fadeUp}
            initial="hidden"
            animate="show"
            custom={0}
            className="eyebrow mb-6"
          >
            Aryan Mandavgode
          </motion.p>

          <motion.h1
            variants={fadeUp}
            initial="hidden"
            animate="show"
            custom={0.1}
            className="text-[2.75rem] font-semibold leading-[1.05] tracking-tight sm:text-6xl lg:text-[4.25rem]"
          >
            Building Digital
            <br />
            Experiences That
            <br />
            <span className="bg-gradient-to-r from-accent-blue to-accent-violet bg-clip-text text-transparent">
              Actually Matter.
            </span>
          </motion.h1>

          <motion.p
            variants={fadeUp}
            initial="hidden"
            animate="show"
            custom={0.24}
            className="mt-6 max-w-md text-base leading-[1.7] text-ink-muted lg:text-lg"
          >
            Computer Engineering student, full-stack developer and founder of ARYONIX.
            I design and build modern digital products from idea to deployment.
          </motion.p>

          <motion.div
            variants={fadeUp}
            initial="hidden"
            animate="show"
            custom={0.34}
            className="mt-10 flex flex-wrap items-center gap-4"
          >
            <a
              href="#projects"
              className="group inline-flex items-center gap-2 rounded-full bg-ink px-6 py-3.5 text-sm font-medium text-void transition-transform hover:-translate-y-0.5"
            >
              View My Work
              <ArrowRight
                size={16}
                className="transition-transform group-hover:translate-x-0.5"
              />
            </a>
            <a
              href="#contact"
              className="group inline-flex items-center gap-2 rounded-full border border-line px-6 py-3.5 text-sm font-medium text-ink transition-colors hover:border-accent-blue/60 hover:bg-surface"
            >
              Let's Work Together
              <ArrowUpRight
                size={16}
                className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
              />
            </a>
          </motion.div>
        </div>

        {/* Right — photo */}
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.9, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
          className="relative mx-auto w-full max-w-sm lg:max-w-none"
        >
          {/* Depth glow behind the frame */}
          <div
            aria-hidden="true"
            className="absolute -inset-6 -z-10 rounded-[2.5rem] bg-gradient-to-br from-accent-blue/20 via-accent-violet/10 to-transparent blur-2xl"
          />

          {/* Asymmetric premium frame — sharp bottom-right, soft everywhere else */}
          <div className="relative aspect-[4/5] overflow-hidden rounded-tl-[2.5rem] rounded-tr-[2.5rem] rounded-bl-[2.5rem] rounded-br-lg border border-line bg-surface shadow-card">
            <picture>
              <source srcSet="/images/aryan-profile.webp" type="image/webp" />
              <img
                src="/images/aryan-profile.jpg"
                alt="Aryan Mandavgode"
                className="h-full w-full object-cover"
                width={960}
                height={1280}
                loading="eager"
                fetchPriority="high"
              />
            </picture>
            {/* Subtle bottom vignette for depth, not decoration for its own sake */}
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-0 bg-gradient-to-t from-void/45 via-transparent to-transparent"
            />
          </div>

          {/* Fine corner accent — a quiet studio/technical-drawing signature, not a glow */}
          <div
            aria-hidden="true"
            className="absolute -right-3 -top-3 hidden h-10 w-10 border-r border-t border-accent-blue/30 sm:block"
          />

          {/* Status indicator */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.9 }}
            className="glass-panel absolute -bottom-5 left-1/2 flex -translate-x-1/2 items-center gap-2.5 rounded-full px-4 py-2.5 lg:left-6 lg:translate-x-0"
          >
            <span className="relative flex h-2 w-2" aria-hidden="true">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
            </span>
            <span className="text-xs font-medium text-ink-muted">
              Available for opportunities
            </span>
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll cue — quiet, single subtle motion, hidden on short viewports */}
      <motion.a
        href="#about"
        aria-label="Scroll to About section"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6, delay: 1.1 }}
        className="absolute bottom-8 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-ink-muted transition-colors hover:text-ink sm:flex"
      >
        <span className="eyebrow !text-[10px]">Scroll</span>
        <motion.span
          animate={{ y: [0, 6, 0] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
          className="h-8 w-px bg-gradient-to-b from-ink-muted to-transparent"
        />
      </motion.a>
    </section>
  );
}
