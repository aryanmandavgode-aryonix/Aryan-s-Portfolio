import { useState } from "react";
import SectionHeading from "@/components/ui/SectionHeading";
import Reveal from "@/components/ui/Reveal";
import ProjectCard from "@/components/sections/ProjectCard";
import ProjectModal from "@/components/sections/ProjectModal";
import { PROJECTS } from "@/data/projects";
import type { Project } from "@/types";

const INITIAL_COUNT = 3;

export default function Projects() {
  const [activeProject, setActiveProject] = useState<Project | null>(null);
  const [showAll, setShowAll] = useState(false);

  const visibleProjects = showAll ? PROJECTS : PROJECTS.slice(0, INITIAL_COUNT);

  return (
    <section id="projects" className="relative py-24 lg:py-32">
      <div className="mx-auto max-w-6xl px-6 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHeading eyebrow="Projects" title="Selected Work." />
        </div>

        <div className="mt-10 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {visibleProjects.map((project, i) => (
            <Reveal key={project.id} delay={i * 0.08}>
              <ProjectCard project={project} onOpen={setActiveProject} />
            </Reveal>
          ))}
        </div>

        {PROJECTS.length > INITIAL_COUNT && (
          <Reveal delay={0.2} className="mt-10 flex justify-center">
            <button
              onClick={() => setShowAll((v) => !v)}
              className="rounded-full border border-line px-6 py-3 text-sm font-medium text-ink transition-colors hover:border-accent-blue/60 hover:bg-surface"
            >
              {showAll ? "Show Less" : "View All Projects"}
            </button>
          </Reveal>
        )}
      </div>

      <ProjectModal project={activeProject} onClose={() => setActiveProject(null)} />
    </section>
  );
}
