import { Palette, Code, Rocket, ArrowUpRight } from "lucide-react";
import SectionHeading from "@/components/ui/SectionHeading";
import Reveal from "@/components/ui/Reveal";

const PILLARS = [
  {
    label: "Design",
    icon: Palette,
    copy: "Interfaces shaped around how people actually use a product, not just how it looks in a mockup.",
  },
  {
    label: "Develop",
    icon: Code,
    copy: "Clean, maintainable code across the stack — built to be extended, not just shipped once.",
  },
  {
    label: "Deploy",
    icon: Rocket,
    copy: "Production-ready delivery, from environment setup to a live, working product.",
  },
];

export default function Aryonix() {
  return (
    <section id="aryonix" className="relative py-24 lg:py-32">
      <div className="pointer-events-none absolute inset-0 bg-accent-glow opacity-60" />

      <div className="relative mx-auto max-w-6xl px-6 lg:px-8">
        <SectionHeading eyebrow="ARYONIX" title="Building More Than Websites." align="center" />

        <Reveal delay={0.1} className="mx-auto mt-6 max-w-xl text-center">
          <p className="text-base leading-relaxed text-ink-muted lg:text-lg">
            ARYONIX is my digital development venture focused on designing, developing and
            deploying modern digital experiences for businesses and startups.
          </p>
        </Reveal>

        <div className="mt-14 grid grid-cols-1 gap-4 sm:grid-cols-3">
          {PILLARS.map((pillar, i) => {
            const Icon = pillar.icon;
            return (
              <Reveal key={pillar.label} delay={0.15 + i * 0.1}>
                <div className="glass-panel card-hover h-full rounded-2xl p-6 text-center">
                  <div className="mx-auto flex h-11 w-11 items-center justify-center rounded-full border border-line">
                    <Icon size={18} className="text-accent-blue" strokeWidth={1.75} />
                  </div>
                  <p className="mt-4 font-display text-base font-semibold">{pillar.label}</p>
                  <p className="mt-2 text-sm leading-relaxed text-ink-muted">{pillar.copy}</p>
                </div>
              </Reveal>
            );
          })}
        </div>

        <Reveal delay={0.4} className="mt-12 flex justify-center">
          <a
            href="https://www.instagram.com/aryonix.in"
            target="_blank"
            rel="noreferrer"
            className="group inline-flex items-center gap-2 rounded-full bg-ink px-6 py-3.5 text-sm font-medium text-void transition-transform hover:-translate-y-0.5"
          >
            Explore ARYONIX
            <ArrowUpRight
              size={16}
              className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
            />
          </a>
        </Reveal>
      </div>
    </section>
  );
}
