import { Code2, GraduationCap, Layers, Rocket } from "lucide-react";
import SectionHeading from "@/components/ui/SectionHeading";
import Reveal from "@/components/ui/Reveal";
import type { AboutStat } from "@/types";

const STATS: (AboutStat & { icon: typeof Code2 })[] = [
  { label: "Computer Engineering", value: "In Progress", icon: GraduationCap },
  { label: "Full-Stack Development", value: "Frontend + Backend", icon: Layers },
  { label: "Projects Built", value: "4+", icon: Code2 },
  { label: "ARYONIX", value: "Founder", icon: Rocket },
];

export default function About() {
  return (
    <section id="about" className="relative py-24 lg:py-32">
      <div className="mx-auto max-w-6xl px-6 lg:px-8">
        <SectionHeading eyebrow="About" title="More Than Just Code." />

        <div className="mt-10 grid grid-cols-1 gap-14 lg:grid-cols-[1fr_0.9fr] lg:gap-16">
          <Reveal delay={0.1}>
            <p className="max-w-xl text-base leading-relaxed text-ink-muted lg:text-lg">
              I'm a Computer Engineering student and full-stack developer interested in
              building modern, scalable and visually impressive digital products. I work
              across frontend, backend and database technologies — and through my venture,
              ARYONIX, I turn that work into digital products for real businesses and
              startups, from first concept to a deployed, production-ready site.
            </p>
          </Reveal>

          <div className="grid grid-cols-2 gap-4">
            {STATS.map((stat, i) => {
              const Icon = stat.icon;
              return (
                <Reveal key={stat.label} delay={0.15 + i * 0.08}>
                  <div className="glass-panel card-hover h-full rounded-2xl p-5">
                    <Icon size={20} className="mb-4 text-accent-blue" strokeWidth={1.75} />
                    <p className="text-sm font-medium text-ink">{stat.value}</p>
                    <p className="mt-1 text-xs text-ink-muted">{stat.label}</p>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
