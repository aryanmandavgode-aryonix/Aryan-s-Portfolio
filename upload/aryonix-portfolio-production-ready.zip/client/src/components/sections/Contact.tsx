import { useState, type FormEvent } from "react";
import { motion } from "framer-motion";
import { Mail, Github, Linkedin, Loader2, CheckCircle2, AlertCircle } from "lucide-react";
import Reveal from "@/components/ui/Reveal";
import { submitContactForm, type ContactFormPayload } from "@/lib/api";

const PROJECT_TYPES = [
  "Website",
  "MERN Application",
  "E-Commerce",
  "Dashboard",
  "Booking System",
  "Custom Software",
  "Other",
];

const EMPTY_FORM: ContactFormPayload = {
  name: "",
  email: "",
  company: "",
  projectType: "",
  message: "",
};

type Status = "idle" | "submitting" | "success" | "error";

export default function Contact() {
  const [form, setForm] = useState<ContactFormPayload>(EMPTY_FORM);
  const [status, setStatus] = useState<Status>("idle");
  const [errorMessage, setErrorMessage] = useState("");

  const update =
    (field: keyof ContactFormPayload) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
      setForm((f) => ({ ...f, [field]: e.target.value }));

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setStatus("submitting");
    setErrorMessage("");

    try {
      await submitContactForm(form);
      setStatus("success");
      setForm(EMPTY_FORM);
    } catch (err) {
      setStatus("error");
      setErrorMessage(err instanceof Error ? err.message : "Something went wrong.");
    }
  }

  return (
    <section id="contact" className="relative py-24 lg:py-32">
      <div className="mx-auto max-w-6xl px-6 lg:px-8">
        <Reveal>
          <p className="eyebrow mb-4">Contact</p>
          <h2 className="text-3xl font-semibold leading-tight sm:text-4xl lg:text-5xl">
            Have an idea?
            <br />
            Let&apos;s build it.
          </h2>
        </Reveal>

        <div className="mt-12 grid grid-cols-1 gap-12 lg:grid-cols-[1fr_1.2fr] lg:gap-16">
          {/* Direct contact details */}
          <Reveal delay={0.1}>
            <div className="space-y-6">
              <a
                href="mailto:aryonixpvtltd@gmail.com"
                className="glass-panel card-hover flex items-center gap-4 rounded-2xl p-5"
              >
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-line">
                  <Mail size={16} className="text-accent-blue" />
                </span>
                <div>
                  <p className="text-sm font-medium">Email</p>
                  <p className="text-sm text-ink-muted">aryonixpvtltd@gmail.com</p>
                </div>
              </a>

              <a
                href="https://github.com/aryanmandavgode-aryonix"
                target="_blank"
                rel="noreferrer"
                className="glass-panel card-hover flex items-center gap-4 rounded-2xl p-5"
              >
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-line">
                  <Github size={16} className="text-accent-blue" />
                </span>
                <div>
                  <p className="text-sm font-medium">GitHub</p>
                  <p className="text-sm text-ink-muted">aryanmandavgode-aryonix</p>
                </div>
              </a>

              <a
                href="https://www.linkedin.com/in/aryan-mandavgode"
                target="_blank"
                rel="noreferrer"
                className="glass-panel card-hover flex items-center gap-4 rounded-2xl p-5"
              >
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-line">
                  <Linkedin size={16} className="text-accent-blue" />
                </span>
                <div>
                  <p className="text-sm font-medium">LinkedIn</p>
                  <p className="text-sm text-ink-muted">aryan-mandavgode</p>
                </div>
              </a>
            </div>
          </Reveal>

          {/* Form */}
          <Reveal delay={0.2}>
            <form onSubmit={handleSubmit} className="glass-panel space-y-5 rounded-2xl p-6 lg:p-8">
              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                <Field label="Name">
                  <input
                    required
                    value={form.name}
                    onChange={update("name")}
                    className="form-input"
                    placeholder="Your name"
                  />
                </Field>
                <Field label="Email">
                  <input
                    required
                    type="email"
                    value={form.email}
                    onChange={update("email")}
                    className="form-input"
                    placeholder="you@example.com"
                  />
                </Field>
              </div>

              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                <Field label="Company (optional)">
                  <input
                    value={form.company}
                    onChange={update("company")}
                    className="form-input"
                    placeholder="Company or team"
                  />
                </Field>
                <Field label="Project Type">
                  <select
                    required
                    value={form.projectType}
                    onChange={update("projectType")}
                    className="form-input"
                  >
                    <option value="" disabled>
                      Select one
                    </option>
                    {PROJECT_TYPES.map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                </Field>
              </div>

              <Field label="Message">
                <textarea
                  required
                  minLength={10}
                  rows={5}
                  value={form.message}
                  onChange={update("message")}
                  className="form-input resize-none"
                  placeholder="Tell me a bit about what you're building..."
                />
              </Field>

              <motion.button
                type="submit"
                disabled={status === "submitting"}
                whileTap={{ scale: 0.98 }}
                className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-ink px-6 py-3.5 text-sm font-medium text-void transition-opacity disabled:opacity-60 sm:w-auto"
              >
                {status === "submitting" && <Loader2 size={16} className="animate-spin" />}
                {status === "submitting" ? "Sending..." : "Send Message"}
              </motion.button>

              {status === "success" && (
                <p role="status" className="flex items-center gap-2 text-sm text-emerald-400">
                  <CheckCircle2 size={16} />
                  Message sent — I'll get back to you soon.
                </p>
              )}
              {status === "error" && (
                <p role="alert" className="flex items-center gap-2 text-sm text-red-400">
                  <AlertCircle size={16} />
                  {errorMessage}
                </p>
              )}
            </form>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-2 block text-xs font-medium text-ink-muted">{label}</span>
      {children}
    </label>
  );
}
