import { cn } from "@/lib/utils";
import Reveal from "@/components/ui/Reveal";

interface SectionHeadingProps {
  eyebrow: string;
  title: string;
  align?: "left" | "center";
  className?: string;
}

export default function SectionHeading({
  eyebrow,
  title,
  align = "left",
  className,
}: SectionHeadingProps) {
  return (
    <Reveal className={cn(align === "center" && "text-center", className)}>
      <p className="eyebrow mb-4">{eyebrow}</p>
      <h2 className="text-3xl font-semibold leading-tight sm:text-4xl lg:text-5xl">
        {title}
      </h2>
    </Reveal>
  );
}
