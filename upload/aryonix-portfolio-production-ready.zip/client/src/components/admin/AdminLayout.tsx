import { type ReactNode } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { LayoutGrid, Code2, Mail, LogOut } from "lucide-react";
import { useAuth } from "@/context/useAuth";
import { cn } from "@/lib/utils";

const NAV_ITEMS = [
  { label: "Projects", to: "/admin/dashboard/projects", icon: LayoutGrid },
  { label: "Skills", to: "/admin/dashboard/skills", icon: Code2 },
  { label: "Messages", to: "/admin/dashboard/messages", icon: Mail },
];

export default function AdminLayout({ children }: { children: ReactNode }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  async function handleLogout() {
    await logout();
    navigate("/admin/login", { replace: true });
  }

  return (
    <div className="flex min-h-screen bg-void">
      {/* Sidebar */}
      <aside className="hidden w-64 shrink-0 border-r border-line lg:flex lg:flex-col">
        <div className="px-6 py-6">
          <p className="font-display text-lg font-semibold">ARYONIX</p>
          <p className="eyebrow mt-1 !normal-case !tracking-normal">Admin</p>
        </div>

        <nav className="flex-1 space-y-1 px-3">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  cn(
                    "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors",
                    isActive
                      ? "bg-surface text-ink"
                      : "text-ink-muted hover:bg-surface/60 hover:text-ink"
                  )
                }
              >
                <Icon size={16} />
                {item.label}
              </NavLink>
            );
          })}
        </nav>

        <div className="border-t border-line px-6 py-5">
          <p className="truncate text-sm text-ink">{user?.name}</p>
          <p className="truncate text-xs text-ink-muted">{user?.email}</p>
          <button
            onClick={handleLogout}
            className="mt-4 inline-flex items-center gap-2 text-sm text-ink-muted transition-colors hover:text-ink"
          >
            <LogOut size={14} /> Log out
          </button>
        </div>
      </aside>

      {/* Mobile topbar */}
      <div className="fixed inset-x-0 top-0 z-40 flex items-center justify-between border-b border-line bg-void/90 px-4 py-3 backdrop-blur lg:hidden">
        <p className="font-display text-sm font-semibold">ARYONIX Admin</p>
        <button onClick={handleLogout} className="text-ink-muted">
          <LogOut size={16} />
        </button>
      </div>

      {/* Mobile bottom nav */}
      <nav className="fixed inset-x-0 bottom-0 z-40 flex border-t border-line bg-void/95 backdrop-blur lg:hidden">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                cn(
                  "flex flex-1 flex-col items-center gap-1 py-3 text-[11px]",
                  isActive ? "text-accent-blue" : "text-ink-muted"
                )
              }
            >
              <Icon size={18} />
              {item.label}
            </NavLink>
          );
        })}
      </nav>

      {/* Content */}
      <main id="main-content" className="flex-1 overflow-x-hidden px-6 pb-24 pt-20 lg:px-10 lg:pb-10 lg:pt-10">
        {children}
      </main>
    </div>
  );
}
