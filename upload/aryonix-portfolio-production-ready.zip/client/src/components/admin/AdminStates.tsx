import type { LucideIcon } from "lucide-react";

export function SkeletonRows({ count = 4 }: { count?: number }) {
  return (
    <div className="mt-6 space-y-3" aria-hidden="true">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="skeleton h-16 rounded-xl" />
      ))}
    </div>
  );
}

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  hint?: string;
}

export function EmptyState({ icon: Icon, title, hint }: EmptyStateProps) {
  return (
    <div className="glass-panel mt-6 flex flex-col items-center gap-3 rounded-xl p-10 text-center">
      <Icon size={20} className="text-ink-muted" />
      <p className="text-sm text-ink-muted">{title}</p>
      {hint && <p className="text-xs text-ink-muted">{hint}</p>}
    </div>
  );
}

export function ErrorBanner({ message }: { message: string }) {
  return (
    <p
      role="alert"
      className="mt-4 rounded-xl border border-red-400/20 bg-red-400/5 px-4 py-3 text-sm text-red-400"
    >
      {message}
    </p>
  );
}
