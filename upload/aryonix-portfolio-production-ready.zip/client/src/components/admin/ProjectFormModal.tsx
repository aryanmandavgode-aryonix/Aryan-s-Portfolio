import { useEffect, useRef, useState, type FormEvent } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X, Loader2 } from "lucide-react";
import type { Project } from "@/types";

interface ProjectFormModalProps {
  project: Project | null; // null = create mode
  open: boolean;
  onClose: () => void;
  onSave: (payload: Partial<Project>) => Promise<void>;
}

const EMPTY: Partial<Project> = {
  name: "",
  description: "",
  technologies: [],
  githubUrl: "",
  liveUrl: "",
  overview: "",
  problem: "",
  solution: "",
};

export default function ProjectFormModal({ project, open, onClose, onSave }: ProjectFormModalProps) {
  const [form, setForm] = useState<Partial<Project>>(project ?? EMPTY);
  const [techInput, setTechInput] = useState((project?.technologies ?? []).join(", "));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const closeButtonRef = useRef<HTMLButtonElement>(null);
  const previouslyFocused = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!open) return;
    previouslyFocused.current = document.activeElement as HTMLElement;
    closeButtonRef.current?.focus();

    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";

    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
      previouslyFocused.current?.focus();
    };
  }, [open, onClose]);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError("");
    try {
      await onSave({
        ...form,
        technologies: techInput
          .split(",")
          .map((t) => t.trim())
          .filter(Boolean),
      });
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save project.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[70] flex items-center justify-center bg-void/80 p-4 backdrop-blur-sm"
          onClick={onClose}
          role="dialog"
          aria-modal="true"
          aria-label={project ? "Edit project" : "Add project"}
        >
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.98 }}
            onClick={(e) => e.stopPropagation()}
            className="glass-panel max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-2xl p-6 lg:p-8"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-semibold">
                {project ? "Edit Project" : "Add Project"}
              </h3>
              <button
                ref={closeButtonRef}
                onClick={onClose}
                aria-label="Close"
                className="text-ink-muted hover:text-ink"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-6 space-y-4">
              <Field label="Name">
                <input
                  required
                  className="form-input"
                  value={form.name ?? ""}
                  onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                />
              </Field>

              <Field label="Description">
                <textarea
                  required
                  rows={3}
                  className="form-input resize-none"
                  value={form.description ?? ""}
                  onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                />
              </Field>

              <Field label="Technologies (comma-separated)">
                <input
                  className="form-input"
                  value={techInput}
                  onChange={(e) => setTechInput(e.target.value)}
                  placeholder="React, TypeScript, Node.js"
                />
              </Field>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <Field label="GitHub URL">
                  <input
                    className="form-input"
                    value={form.githubUrl ?? ""}
                    onChange={(e) => setForm((f) => ({ ...f, githubUrl: e.target.value }))}
                  />
                </Field>
                <Field label="Live URL">
                  <input
                    className="form-input"
                    value={form.liveUrl ?? ""}
                    onChange={(e) => setForm((f) => ({ ...f, liveUrl: e.target.value }))}
                  />
                </Field>
              </div>

              <Field label="Overview">
                <textarea
                  rows={2}
                  className="form-input resize-none"
                  value={form.overview ?? ""}
                  onChange={(e) => setForm((f) => ({ ...f, overview: e.target.value }))}
                />
              </Field>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <Field label="Problem">
                  <textarea
                    rows={2}
                    className="form-input resize-none"
                    value={form.problem ?? ""}
                    onChange={(e) => setForm((f) => ({ ...f, problem: e.target.value }))}
                  />
                </Field>
                <Field label="Solution">
                  <textarea
                    rows={2}
                    className="form-input resize-none"
                    value={form.solution ?? ""}
                    onChange={(e) => setForm((f) => ({ ...f, solution: e.target.value }))}
                  />
                </Field>
              </div>

              <button
                type="submit"
                disabled={saving}
                className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-ink px-6 py-3 text-sm font-medium text-void disabled:opacity-60"
              >
                {saving && <Loader2 size={16} className="animate-spin" />}
                {saving ? "Saving..." : "Save Project"}
              </button>

              {error && (
                <p role="alert" className="text-sm text-red-400">
                  {error}
                </p>
              )}
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium text-ink-muted">{label}</span>
      {children}
    </label>
  );
}
