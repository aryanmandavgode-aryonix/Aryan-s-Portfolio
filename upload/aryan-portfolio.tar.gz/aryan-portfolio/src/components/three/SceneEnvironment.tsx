"use client";

import { Environment, Lightformer } from "@react-three/drei";

/**
 * Builds a small reflection environment out of Lightformer primitives
 * instead of an external HDRI — keeps "premium reflections" fully
 * procedural and offline. Shared by every hero-quality 3D object on the
 * site so their materials read as lit by the same room.
 */
export function SceneEnvironment() {
  return (
    <Environment resolution={256}>
      <Lightformer form="rect" intensity={2.2} color="#e8ecff" position={[0, 4, -2]} scale={[6, 3, 1]} />
      <Lightformer form="rect" intensity={1.4} color="#3d6bff" position={[-4, 0, 2]} scale={[3, 5, 1]} rotation={[0, Math.PI / 3, 0]} />
      <Lightformer form="rect" intensity={0.6} color="#8a8f98" position={[4, -1, 3]} scale={[3, 4, 1]} rotation={[0, -Math.PI / 3, 0]} />
    </Environment>
  );
}
