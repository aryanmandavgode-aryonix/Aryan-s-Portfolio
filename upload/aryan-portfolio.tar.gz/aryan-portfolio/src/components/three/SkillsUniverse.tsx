"use client";

import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { SkillsCore } from "./SkillsCore";
import { BuildLetters } from "./BuildLetters";
import { TechOrbit } from "./TechOrbit";
import type { SkillItem } from "@/types";

interface SkillsUniverseProps {
  items: SkillItem[];
  radius: number;
  active: string | null;
  ready: boolean;
  reducedMotion: boolean;
  onHover: (name: string | null) => void;
  onFocus: (name: string | null) => void;
  onSelect: (name: string) => void;
}

export function SkillsUniverse({
  items,
  radius,
  active,
  ready,
  reducedMotion,
  onHover,
  onFocus,
  onSelect,
}: SkillsUniverseProps) {
  const group = useRef<THREE.Group>(null);

  useFrame((_, delta) => {
    if (!group.current || reducedMotion) return;
    group.current.rotation.y += delta * 0.045;
  });

  return (
    <group ref={group}>
      <SkillsCore reducedMotion={reducedMotion} />
      <BuildLetters />
      <TechOrbit
        items={items}
        radius={radius}
        active={active}
        ready={ready}
        reducedMotion={reducedMotion}
        onHover={onHover}
        onFocus={onFocus}
        onSelect={onSelect}
      />
    </group>
  );
}
