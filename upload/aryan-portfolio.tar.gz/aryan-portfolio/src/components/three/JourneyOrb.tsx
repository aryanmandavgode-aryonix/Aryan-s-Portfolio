"use client";

import { useRef, type RefObject } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

interface JourneyOrbProps {
  progress: RefObject<number>;
  reducedMotion: boolean;
}

const TOP_Y = 2.4;
const RANGE = 4.8;

/**
 * A small emissive sphere that descends the rail as `progress` (0..1,
 * synced to the same illuminated-line progress the DOM rail uses) goes
 * from 0 to 1. Deliberately simple material — no clearcoat, no
 * reflections — this is meant to read as a quiet accompaniment, not a
 * focal object.
 */
export function JourneyOrb({ progress, reducedMotion }: JourneyOrbProps) {
  const mesh = useRef<THREE.Mesh>(null);
  const smoothedY = useRef(TOP_Y);

  useFrame((state, delta) => {
    if (!mesh.current) return;
    const targetY = TOP_Y - progress.current * RANGE;
    smoothedY.current += (targetY - smoothedY.current) * Math.min(delta * 4, 1);
    mesh.current.position.y = smoothedY.current;
    mesh.current.position.x = reducedMotion ? 0 : Math.sin(state.clock.elapsedTime * 0.6) * 0.12;
    if (!reducedMotion) mesh.current.rotation.y += delta * 0.2;
  });

  return (
    <mesh ref={mesh} position={[0, TOP_Y, 0]}>
      <sphereGeometry args={[0.22, 24, 24]} />
      <meshStandardMaterial
        color="#0c1018"
        emissive="#3d6bff"
        emissiveIntensity={1.1}
        roughness={0.3}
        metalness={0.4}
      />
    </mesh>
  );
}
