"use client";

import { Suspense, type RefObject } from "react";
import { Canvas } from "@react-three/fiber";
import { AryonixUniverse } from "./AryonixUniverse";
import { SceneEnvironment } from "./SceneEnvironment";
import { ReactiveLight } from "./ReactiveLight";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { useIsMobileViewport } from "@/hooks/useIsMobileViewport";

interface AryonixSceneProps {
  scrollProgress: RefObject<number>;
  isActive: boolean;
}

/**
 * Client-only Canvas — imported with next/dynamic and ssr:false. No
 * bloom or emissive glow pushed hard here: the brief explicitly rules out
 * a neon/gaming-logo look, so lighting comes only from the shared
 * procedural environment + a trailing rim light. `isActive` gates the
 * frameloop off once the section is well outside the viewport.
 */
export function AryonixScene({ scrollProgress, isActive }: AryonixSceneProps) {
  const reducedMotion = useReducedMotion();
  const isMobile = useIsMobileViewport();

  return (
    <Canvas
      frameloop={isActive ? "always" : "never"}
      camera={{ position: [0, 0, 5.6], fov: 42 }}
      dpr={isMobile ? 1 : [1, 1.5]}
      gl={{ antialias: !isMobile, alpha: true }}
    >
      <ambientLight intensity={0.45} />
      <directionalLight position={[3, 2, 4]} intensity={0.6} />
      <ReactiveLight reducedMotion={reducedMotion} />
      <Suspense fallback={null}>
        {!isMobile && <SceneEnvironment />}
        <AryonixUniverse reducedMotion={reducedMotion} scrollProgress={scrollProgress} />
      </Suspense>
    </Canvas>
  );
}
