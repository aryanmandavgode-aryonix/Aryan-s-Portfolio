"use client";

import { Html } from "@react-three/drei";

const LETTERS = ["B", "U", "I", "L", "D"];
const RADIUS = 1.55;

/**
 * Decorative ring of letters spelling BUILD around the central core.
 * Rendered via drei's Html so the type matches the rest of the site
 * exactly, rather than a separately-loaded SDF font. Marked aria-hidden
 * since "BUILD" is already present in the section heading's text.
 */
export function BuildLetters() {
  return (
    <>
      {LETTERS.map((letter, i) => {
        const angle = (i / LETTERS.length) * Math.PI * 2;
        const x = Math.cos(angle) * RADIUS;
        const z = Math.sin(angle) * RADIUS;
        const y = Math.sin(angle * 2) * 0.12;
        return (
          <Html key={letter} position={[x, y, z]} center distanceFactor={6} occlude={false} zIndexRange={[5, 0]}>
            <span aria-hidden="true" className="select-none font-mono text-[10px] tracking-[0.3em] text-mist/60">
              {letter}
            </span>
          </Html>
        );
      })}
    </>
  );
}
