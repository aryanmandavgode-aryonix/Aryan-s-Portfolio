"use client";

import { Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { Bloom, EffectComposer } from "@react-three/postprocessing";
import { HeroObject } from "./HeroObject";
import { HeroParticles } from "./HeroParticles";
import { SceneEnvironment } from "./SceneEnvironment";
import { ReactiveLight } from "./ReactiveLight";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { useIsMobileViewport } from "@/hooks/useIsMobileViewport";

interface HeroSceneProps {
  isActive: boolean;
}

/**
 * Client-only Canvas — imported with next/dynamic and ssr:false from the
 * Hero section so three.js never touches the server render. Scene cost
 * (geometry detail, particle count, reflections, bloom) scales down on
 * narrow viewports rather than rendering the same scene everywhere.
 * `isActive` gates the frameloop off once scrolled well past the section.
 */
export function HeroScene({ isActive }: HeroSceneProps) {
  const reducedMotion = useReducedMotion();
  const isMobile = useIsMobileViewport();
  const quality = isMobile ? "low" : "high";

  return (
    <Canvas
      frameloop={isActive ? "always" : "never"}
      camera={{ position: [0, 0, 5.4], fov: 42 }}
      dpr={isMobile ? 1 : [1, 1.5]}
      gl={{ antialias: !isMobile, alpha: true }}
    >
      <ambientLight intensity={0.45} />
      <directionalLight position={[3, 2, 4]} intensity={0.6} />
      <ReactiveLight reducedMotion={reducedMotion} />
      <Suspense fallback={null}>
        {!isMobile && <SceneEnvironment />}
        <HeroObject reducedMotion={reducedMotion} quality={quality} />
        <HeroParticles reducedMotion={reducedMotion} count={isMobile ? 90 : 220} />
        {!isMobile && !reducedMotion && (
          <EffectComposer>
            <Bloom intensity={0.35} luminanceThreshold={0.4} luminanceSmoothing={0.25} mipmapBlur />
          </EffectComposer>
        )}
      </Suspense>
    </Canvas>
  );
}
