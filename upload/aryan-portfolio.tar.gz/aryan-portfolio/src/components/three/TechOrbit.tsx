"use client";

import { useMemo } from "react";
import { TechLabel } from "./TechLabel";
import type { SkillItem } from "@/types";

interface TechOrbitProps {
  items: SkillItem[];
  radius: number;
  active: string | null;
  ready: boolean;
  reducedMotion: boolean;
  onHover: (name: string | null) => void;
  onFocus: (name: string | null) => void;
  onSelect: (name: string) => void;
}

/**
 * Evenly distributes N points on a sphere using a golden-angle spiral,
 * then flattens the vertical spread so labels stay inside the canvas's
 * usual wider-than-tall aspect ratio instead of drifting off top/bottom.
 */
function fibonacciSpherePoints(count: number, radius: number): [number, number, number][] {
  const goldenAngle = Math.PI * (3 - Math.sqrt(5));
  const points: [number, number, number][] = [];
  for (let i = 0; i < count; i++) {
    const y = count === 1 ? 0 : 1 - (i / (count - 1)) * 2;
    const r = Math.sqrt(Math.max(0, 1 - y * y));
    const theta = goldenAngle * i;
    const x = Math.cos(theta) * r;
    const z = Math.sin(theta) * r;
    points.push([x * radius, y * radius * 0.55, z * radius]);
  }
  return points;
}

export function TechOrbit({ items, radius, active, ready, reducedMotion, onHover, onFocus, onSelect }: TechOrbitProps) {
  const positions = useMemo(() => fibonacciSpherePoints(items.length, radius), [items.length, radius]);

  return (
    <>
      {items.map((skill, i) => (
        <TechLabel
          key={skill.name}
          skill={skill}
          position={positions[i]}
          active={active === skill.name}
          ready={ready}
          index={i}
          reducedMotion={reducedMotion}
          onHover={onHover}
          onFocus={onFocus}
          onSelect={onSelect}
        />
      ))}
    </>
  );
}
