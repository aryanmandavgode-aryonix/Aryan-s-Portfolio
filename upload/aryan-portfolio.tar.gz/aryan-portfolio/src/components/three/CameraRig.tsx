"use client";

import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

interface CameraRigProps {
  reducedMotion: boolean;
}

/**
 * Nudges the default camera a few tenths of a unit off-axis based on the
 * pointer, then re-aims it at the origin — the whole scene appears to
 * shift with the cursor rather than any single object rotating toward it.
 * Reads the camera from useFrame's own state argument each frame instead
 * of destructuring it from useThree() at the top level, since mutating a
 * value bound from a hook return (rather than a plain callback argument)
 * trips the stricter immutability lint rule.
 */
export function CameraRig({ reducedMotion }: CameraRigProps) {
  const smoothed = useRef(new THREE.Vector2(0, 0));
  const basePosition = useRef<THREE.Vector3 | null>(null);

  useFrame((state, delta) => {
    const { camera } = state;
    if (!basePosition.current) basePosition.current = camera.position.clone();
    if (reducedMotion) return;

    smoothed.current.lerp(
      new THREE.Vector2(state.pointer.x, state.pointer.y),
      Math.min(delta * 1.8, 1)
    );
    camera.position.x = basePosition.current.x + smoothed.current.x * 0.35;
    camera.position.y = basePosition.current.y + smoothed.current.y * 0.22;
    camera.lookAt(0, 0, 0);
  });

  return null;
}
