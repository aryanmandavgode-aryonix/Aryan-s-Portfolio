"use client";

import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

interface HeroParticlesProps {
  reducedMotion: boolean;
  count: number;
}

/** Deterministic PRNG (mulberry32) so the field is stable across renders
 * without calling an impure function like Math.random during render. */
function createRng(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function generatePositions(count: number): Float32Array {
  const rng = createRng(1337);
  const arr = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    const radius = 3 + rng() * 2.4;
    const theta = rng() * Math.PI * 2;
    const phi = Math.acos(2 * rng() - 1);
    arr[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
    arr[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
    arr[i * 3 + 2] = radius * Math.cos(phi) * 0.6;
  }
  return arr;
}

export function HeroParticles({ reducedMotion, count }: HeroParticlesProps) {
  const points = useRef<THREE.Points>(null);
  const positions = useMemo(() => generatePositions(count), [count]);

  useFrame((_, delta) => {
    if (!points.current || reducedMotion) return;
    points.current.rotation.y += delta * 0.012;
  });

  return (
    <points ref={points}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial color="#8a8f98" size={0.018} sizeAttenuation transparent opacity={0.45} />
    </points>
  );
}
