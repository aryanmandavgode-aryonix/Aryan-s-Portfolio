"use client";

import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

interface ReactiveLightProps {
  reducedMotion: boolean;
}

export function ReactiveLight({ reducedMotion }: ReactiveLightProps) {
  const light = useRef<THREE.PointLight>(null);
  const smoothed = useRef(new THREE.Vector2(-3, -2));

  useFrame((state, delta) => {
    if (!light.current) return;
    const target = new THREE.Vector2(state.pointer.x * 3, state.pointer.y * 2);
    smoothed.current.lerp(target, reducedMotion ? 1 : Math.min(delta * 1.6, 1));
    light.current.position.x = smoothed.current.x;
    light.current.position.y = smoothed.current.y;
  });

  return <pointLight ref={light} position={[-3, -2, -1]} color="#3d6bff" intensity={3} />;
}
