"use client";

import { Html } from "@react-three/drei";
import { motion } from "framer-motion";
import type { SkillItem } from "@/types";

interface TechLabelProps {
  skill: SkillItem;
  position: [number, number, number];
  active: boolean;
  ready: boolean;
  index: number;
  reducedMotion: boolean;
  onHover: (name: string | null) => void;
  onFocus: (name: string | null) => void;
  onSelect: (name: string) => void;
}

/**
 * A real DOM button positioned in 3D space, not a WebGL mesh — natively
 * focusable and tappable, and it renders with the site's actual type
 * instead of a separately-loaded SDF font. Hover, focus, and click all
 * report the same skill name upward so the info panel and the accessible
 * list below stay in sync regardless of input method.
 */
export function TechLabel({
  skill,
  position,
  active,
  ready,
  index,
  reducedMotion,
  onHover,
  onFocus,
  onSelect,
}: TechLabelProps) {
  return (
    <Html position={position} center distanceFactor={7} occlude={false} zIndexRange={[20, 0]}>
      <motion.button
        type="button"
        onMouseEnter={() => onHover(skill.name)}
        onMouseLeave={() => onHover(null)}
        onFocus={() => onFocus(skill.name)}
        onBlur={() => onFocus(null)}
        onClick={() => onSelect(skill.name)}
        initial={{ opacity: 0, y: reducedMotion ? 0 : 8 }}
        animate={ready ? { opacity: 1, y: 0 } : { opacity: 0, y: reducedMotion ? 0 : 8 }}
        transition={{ duration: reducedMotion ? 0.01 : 0.6, delay: reducedMotion ? 0 : index * 0.08 }}
        whileHover={reducedMotion ? undefined : { scale: 1.12 }}
        whileFocus={reducedMotion ? undefined : { scale: 1.12 }}
        style={{
          textShadow: active ? "0 0 14px color-mix(in srgb, var(--signal) 60%, transparent)" : "none",
        }}
        className={`select-none whitespace-nowrap bg-transparent font-mono text-[11px] tracking-[0.15em] uppercase transition-colors duration-300 focus-visible:outline-none ${
          active ? "text-ink" : "text-mist hover:text-ink"
        }`}
      >
        {skill.name}
      </motion.button>
    </Html>
  );
}
