"use client";

import { Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { SkillsUniverse } from "./SkillsUniverse";
import { SceneEnvironment } from "./SceneEnvironment";
import { ReactiveLight } from "./ReactiveLight";
import { CameraRig } from "./CameraRig";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { useIsMobileViewport } from "@/hooks/useIsMobileViewport";
import type { SkillItem } from "@/types";

interface SkillsSceneProps {
  items: SkillItem[];
  active: string | null;
  ready: boolean;
  isActive: boolean;
  onHover: (name: string | null) => void;
  onFocus: (name: string | null) => void;
  onSelect: (name: string) => void;
}

/**
 * Client-only Canvas — imported with next/dynamic and ssr:false. No
 * bloom here: a third full postprocessing stack on one page isn't worth
 * the cost for a secondary scene. `isActive` (whether the section is
 * anywhere near the viewport) gates the frameloop entirely, so this
 * scene stops rendering when scrolled well past instead of animating
 * off-screen forever.
 */
export function SkillsScene({ items, active, ready, isActive, onHover, onFocus, onSelect }: SkillsSceneProps) {
  const reducedMotion = useReducedMotion();
  const isMobile = useIsMobileViewport();
  const radius = isMobile ? 2.1 : 2.6;

  return (
    <Canvas
      frameloop={isActive ? "always" : "never"}
      camera={{ position: [0, 0, 5.2], fov: 42 }}
      dpr={isMobile ? 1 : [1, 1.5]}
      gl={{ antialias: !isMobile, alpha: true }}
    >
      <ambientLight intensity={0.5} />
      <directionalLight position={[2, 3, 4]} intensity={0.6} />
      <ReactiveLight reducedMotion={reducedMotion} />
      <CameraRig reducedMotion={reducedMotion} />
      <Suspense fallback={null}>
        {!isMobile && <SceneEnvironment />}
        <SkillsUniverse
          items={items}
          radius={radius}
          active={active}
          ready={ready}
          reducedMotion={reducedMotion}
          onHover={onHover}
          onFocus={onFocus}
          onSelect={onSelect}
        />
      </Suspense>
    </Canvas>
  );
}
