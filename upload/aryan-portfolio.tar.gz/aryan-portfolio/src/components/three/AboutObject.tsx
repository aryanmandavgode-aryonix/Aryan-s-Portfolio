"use client";

import { useMemo, useRef, type RefObject } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

interface AboutObjectProps {
  reducedMotion: boolean;
  quality: "high" | "low";
  scrollProgress: RefObject<number>;
}

/**
 * A low-poly, flat-shaded chrome/glass core — deliberately distinct from
 * the Hero's smooth distorted orb, but built with the same material
 * language (metal + clearcoat + the shared studio reflections), so the
 * section reads as a continuation rather than a new site. Rotation is
 * driven primarily by scroll progress, with a small pointer offset and a
 * slow idle spin layered on top.
 */
export function AboutObject({ reducedMotion, quality, scrollProgress }: AboutObjectProps) {
  const group = useRef<THREE.Group>(null);
  const ring = useRef<THREE.Mesh>(null);
  const smoothedScroll = useRef(0);

  const coreGeometry = useMemo(() => new THREE.IcosahedronGeometry(1.15, 1), []);
  const ringSegments = quality === "high" ? 96 : 48;
  const ringGeometry = useMemo(
    () => new THREE.TorusGeometry(1.6, 0.012, 16, ringSegments),
    [ringSegments]
  );

  useFrame((state, delta) => {
    smoothedScroll.current +=
      (scrollProgress.current - smoothedScroll.current) * Math.min(delta * 3, 1);

    if (group.current) {
      const scrollSpin = smoothedScroll.current * Math.PI * 1.1;
      const pointerYaw = reducedMotion ? 0 : state.pointer.x * 0.18;
      const pointerPitch = reducedMotion ? 0 : -state.pointer.y * 0.12;
      const idleSpin = reducedMotion ? 0 : state.clock.elapsedTime * 0.05;
      group.current.rotation.y = scrollSpin + pointerYaw + idleSpin;
      group.current.rotation.x = pointerPitch;
    }
    if (ring.current && !reducedMotion) {
      ring.current.rotation.z += delta * 0.08;
    }
  });

  return (
    <group ref={group}>
      <mesh geometry={coreGeometry}>
        <meshPhysicalMaterial
          color="#0c1018"
          roughness={0.16}
          metalness={0.85}
          clearcoat={0.6}
          clearcoatRoughness={0.2}
          flatShading
          envMapIntensity={1.3}
        />
      </mesh>
      <mesh ref={ring} geometry={ringGeometry} rotation={[Math.PI / 2.6, 0, 0]}>
        <meshStandardMaterial
          color="#3d6bff"
          emissive="#3d6bff"
          emissiveIntensity={0.6}
          roughness={0.4}
          metalness={0.2}
          transparent
          opacity={0.85}
        />
      </mesh>
    </group>
  );
}
