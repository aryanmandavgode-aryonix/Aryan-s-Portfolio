"use client";

import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

interface AryonixCoreProps {
  reducedMotion: boolean;
}

/**
 * A faceted dodecahedron — distinct from the Hero's smooth orb, About's
 * icosahedron, and Skills' octahedron, but the same chrome + clearcoat
 * material recipe, so it still reads as part of the site.
 */
export function AryonixCore({ reducedMotion }: AryonixCoreProps) {
  const mesh = useRef<THREE.Mesh>(null);
  const geometry = useMemo(() => new THREE.DodecahedronGeometry(1.05, 0), []);

  useFrame((_, delta) => {
    if (!mesh.current || reducedMotion) return;
    mesh.current.rotation.y += delta * 0.05;
  });

  return (
    <mesh ref={mesh} geometry={geometry}>
      <meshPhysicalMaterial
        color="#0b0d12"
        roughness={0.15}
        metalness={0.8}
        clearcoat={0.65}
        clearcoatRoughness={0.18}
        flatShading
        envMapIntensity={1.3}
      />
    </mesh>
  );
}
