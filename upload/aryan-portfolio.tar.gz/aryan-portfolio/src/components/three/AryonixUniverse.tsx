"use client";

import { useRef, type RefObject } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { AryonixCore } from "./AryonixCore";
import { AryonixShell } from "./AryonixShell";
import { AryonixWordmark } from "./AryonixWordmark";

interface AryonixUniverseProps {
  reducedMotion: boolean;
  scrollProgress: RefObject<number>;
}

/**
 * The core + shell live in their own group and can rotate indefinitely —
 * purely decorative, fine to spin freely from pointer, scroll, and idle
 * motion combined. The wordmark deliberately does NOT share that
 * rotation: unbounded spin would eventually carry a text label around to
 * face away from the camera. It gets its own group with only a small,
 * bounded pointer-driven position nudge, so it stays legible.
 */
export function AryonixUniverse({ reducedMotion, scrollProgress }: AryonixUniverseProps) {
  const spinGroup = useRef<THREE.Group>(null);
  const wordmarkGroup = useRef<THREE.Group>(null);
  const smoothedPointer = useRef(new THREE.Vector2(0, 0));
  const smoothedScroll = useRef(0);

  useFrame((state, delta) => {
    smoothedPointer.current.lerp(
      new THREE.Vector2(state.pointer.x, state.pointer.y),
      reducedMotion ? 1 : Math.min(delta * 2, 1)
    );
    smoothedScroll.current += (scrollProgress.current - smoothedScroll.current) * Math.min(delta * 2, 1);

    if (spinGroup.current) {
      const scrollSpin = smoothedScroll.current * Math.PI * 0.6;
      const pointerYaw = reducedMotion ? 0 : smoothedPointer.current.x * 0.3;
      const idleSpin = reducedMotion ? 0 : state.clock.elapsedTime * 0.03;
      spinGroup.current.rotation.y = scrollSpin + pointerYaw + idleSpin;
      spinGroup.current.rotation.x = reducedMotion ? 0 : -smoothedPointer.current.y * 0.18;
    }

    if (wordmarkGroup.current) {
      wordmarkGroup.current.position.x = reducedMotion ? 0 : smoothedPointer.current.x * 0.12;
      wordmarkGroup.current.position.y = reducedMotion ? 0 : smoothedPointer.current.y * 0.08;
    }
  });

  return (
    <>
      <group ref={spinGroup}>
        <AryonixCore reducedMotion={reducedMotion} />
        <AryonixShell reducedMotion={reducedMotion} />
      </group>
      <group ref={wordmarkGroup} position={[0, 0, 0.4]}>
        <AryonixWordmark />
      </group>
    </>
  );
}
