"use client";

import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { Float, MeshDistortMaterial } from "@react-three/drei";
import * as THREE from "three";

interface HeroObjectProps {
  reducedMotion: boolean;
  quality: "high" | "low";
}

/**
 * The hero's signature object: a chrome, gently-distorted core with a
 * faint wireframe halo for depth. The core floats and self-distorts via
 * drei's Float/MeshDistortMaterial; the outer group instead tracks the
 * pointer, so it reads as something being inspected rather than a loop.
 */
export function HeroObject({ reducedMotion, quality }: HeroObjectProps) {
  const group = useRef<THREE.Group>(null);
  const halo = useRef<THREE.Mesh>(null);
  const smoothed = useRef(new THREE.Vector2(0, 0));

  const coreDetail = quality === "high" ? 4 : 2;
  const haloDetail = quality === "high" ? 1 : 0;
  const coreGeometry = useMemo(() => new THREE.IcosahedronGeometry(1.3, coreDetail), [coreDetail]);
  const haloGeometry = useMemo(() => new THREE.IcosahedronGeometry(1.85, haloDetail), [haloDetail]);

  useFrame((state, delta) => {
    const { pointer } = state;
    smoothed.current.lerp(
      new THREE.Vector2(pointer.x, pointer.y),
      reducedMotion ? 1 : Math.min(delta * 2.2, 1)
    );

    if (group.current) {
      group.current.rotation.y = smoothed.current.x * 0.45;
      group.current.rotation.x = -smoothed.current.y * 0.3;
    }
    if (halo.current && !reducedMotion) {
      halo.current.rotation.y -= delta * 0.025;
      halo.current.rotation.x += delta * 0.012;
    }
  });

  return (
    <group ref={group}>
      <Float
        speed={reducedMotion ? 0 : 1.4}
        rotationIntensity={reducedMotion ? 0 : 0.5}
        floatIntensity={reducedMotion ? 0 : 0.8}
      >
        <mesh geometry={coreGeometry}>
          <MeshDistortMaterial
            color="#0d1119"
            roughness={0.12}
            metalness={0.95}
            distort={reducedMotion ? 0 : 0.32}
            speed={reducedMotion ? 0 : 1.3}
            envMapIntensity={1.4}
          />
        </mesh>
      </Float>
      <mesh ref={halo} geometry={haloGeometry}>
        <meshBasicMaterial color="#3d6bff" wireframe transparent opacity={0.16} />
      </mesh>
    </group>
  );
}
