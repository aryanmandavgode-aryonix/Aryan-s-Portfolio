"use client";

import { Suspense, type RefObject } from "react";
import { Canvas } from "@react-three/fiber";
import { AboutObject } from "./AboutObject";
import { SceneEnvironment } from "./SceneEnvironment";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { useIsMobileViewport } from "@/hooks/useIsMobileViewport";

interface AboutSceneProps {
  scrollProgress: RefObject<number>;
  isActive: boolean;
}

/**
 * Client-only Canvas — imported with next/dynamic and ssr:false from the
 * About section. Deliberately lighter than HeroScene: no bloom, since two
 * full postprocessing stacks running while both sections are near the
 * viewport isn't worth the cost for a secondary object. `isActive` gates
 * the frameloop off once scrolled well past the section.
 */
export function AboutScene({ scrollProgress, isActive }: AboutSceneProps) {
  const reducedMotion = useReducedMotion();
  const isMobile = useIsMobileViewport();
  const quality = isMobile ? "low" : "high";

  return (
    <Canvas
      frameloop={isActive ? "always" : "never"}
      camera={{ position: [0, 0, 4.6], fov: 40 }}
      dpr={isMobile ? 1 : [1, 1.5]}
      gl={{ antialias: !isMobile, alpha: true }}
    >
      <ambientLight intensity={0.5} />
      <directionalLight position={[2, 3, 4]} intensity={0.7} />
      <pointLight position={[-2.5, -1.5, 2]} color="#3d6bff" intensity={2.2} />
      <Suspense fallback={null}>
        {!isMobile && <SceneEnvironment />}
        <AboutObject reducedMotion={reducedMotion} quality={quality} scrollProgress={scrollProgress} />
      </Suspense>
    </Canvas>
  );
}
