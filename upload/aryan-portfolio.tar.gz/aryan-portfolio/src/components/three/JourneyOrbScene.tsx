"use client";

import { type RefObject } from "react";
import { Canvas } from "@react-three/fiber";
import { JourneyOrb } from "./JourneyOrb";
import { useReducedMotion } from "@/hooks/useReducedMotion";

interface JourneyOrbSceneProps {
  progress: RefObject<number>;
  isActive: boolean;
}

/**
 * No environment, no postprocessing — this is the lightest of the site's
 * scenes, intentionally, since it's a subtle accompaniment rather than a
 * showcase object. `isActive` (section anywhere near the viewport) gates
 * the frameloop off entirely once scrolled well past.
 */
export function JourneyOrbScene({ progress, isActive }: JourneyOrbSceneProps) {
  const reducedMotion = useReducedMotion();

  return (
    <Canvas
      frameloop={isActive ? "always" : "never"}
      camera={{ position: [0, 0, 6], fov: 50 }}
      dpr={1}
      gl={{ antialias: false, alpha: true }}
    >
      <ambientLight intensity={0.6} />
      <directionalLight position={[2, 2, 3]} intensity={0.5} />
      <JourneyOrb progress={progress} reducedMotion={reducedMotion} />
    </Canvas>
  );
}
