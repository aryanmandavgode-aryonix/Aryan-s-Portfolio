"use client";

import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

interface SkillsCoreProps {
  reducedMotion: boolean;
}

/**
 * A faceted octahedron — visually distinct from the Hero's smooth
 * distorted orb and About's icosahedral core, but built from the same
 * metal + clearcoat recipe so the scene still reads as part of the site.
 * Spins slowly and continuously; the BUILD ring and tech orbit read off
 * this object's rotation via the parent group, not this component.
 */
export function SkillsCore({ reducedMotion }: SkillsCoreProps) {
  const mesh = useRef<THREE.Mesh>(null);
  const geometry = useMemo(() => new THREE.OctahedronGeometry(0.85, 0), []);

  useFrame((_, delta) => {
    if (!mesh.current || reducedMotion) return;
    mesh.current.rotation.y += delta * 0.12;
    mesh.current.rotation.x += delta * 0.05;
  });

  return (
    <mesh ref={mesh} geometry={geometry}>
      <meshPhysicalMaterial
        color="#0c1018"
        roughness={0.14}
        metalness={0.75}
        clearcoat={0.7}
        clearcoatRoughness={0.15}
        flatShading
        envMapIntensity={1.4}
      />
    </mesh>
  );
}
