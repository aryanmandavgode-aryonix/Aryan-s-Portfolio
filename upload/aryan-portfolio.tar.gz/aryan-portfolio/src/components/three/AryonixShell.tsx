"use client";

import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

interface AryonixShellProps {
  reducedMotion: boolean;
}

export function AryonixShell({ reducedMotion }: AryonixShellProps) {
  const mesh = useRef<THREE.Mesh>(null);
  const geometry = useMemo(() => new THREE.IcosahedronGeometry(1.9, 1), []);

  useFrame((_, delta) => {
    if (!mesh.current || reducedMotion) return;
    mesh.current.rotation.y -= delta * 0.02;
    mesh.current.rotation.x += delta * 0.01;
  });

  return (
    <mesh ref={mesh} geometry={geometry}>
      <meshBasicMaterial color="#3d6bff" wireframe transparent opacity={0.14} />
    </mesh>
  );
}
