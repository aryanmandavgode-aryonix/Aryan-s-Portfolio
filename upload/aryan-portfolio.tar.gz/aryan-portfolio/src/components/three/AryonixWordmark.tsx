"use client";

import { Html } from "@react-three/drei";

/**
 * The ARYONIX wordmark as real DOM text (via drei's Html), not a
 * separately-loaded SDF font or a different logo treatment — this is a
 * tasteful text-based stand-in, as instructed, not a new brand mark.
 */
export function AryonixWordmark() {
  return (
    <Html center distanceFactor={6.5} occlude={false} zIndexRange={[10, 0]}>
      <p className="select-none whitespace-nowrap font-display text-3xl font-medium tracking-tight text-ink sm:text-4xl">
        ARYONIX
      </p>
    </Html>
  );
}
