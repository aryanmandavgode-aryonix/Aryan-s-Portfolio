"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Container } from "@/components/ui/Container";
import { useReducedMotion } from "@/hooks/useReducedMotion";

const NAV_ITEMS = [
  { index: "01", label: "About", href: "#about" },
  { index: "02", label: "Skills", href: "#skills" },
  { index: "03", label: "Projects", href: "#projects" },
  { index: "04", label: "Journey", href: "#journey" },
  { index: "05", label: "Aryonix", href: "#aryonix" },
  { index: "06", label: "Contact", href: "#contact" },
];

const SECTION_IDS = NAV_ITEMS.map((item) => item.href.slice(1));

export function Header() {
  const reducedMotion = useReducedMotion();
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeId, setActiveId] = useState<string | null>(null);

  // Highlights whichever section currently occupies the vertical center
  // of the viewport — desktop nav only, doesn't affect scroll behavior.
  useEffect(() => {
    const sections = SECTION_IDS.map((id) => document.getElementById(id)).filter(
      (el): el is HTMLElement => el !== null
    );
    if (sections.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter((entry) => entry.isIntersecting);
        if (visible.length > 0) setActiveId(visible[0].target.id);
      },
      { rootMargin: "-45% 0px -45% 0px" }
    );

    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-line/60 bg-void/70 backdrop-blur-sm">
      <Container className="flex h-16 items-center justify-between">
        <a href="#top" className="font-mono text-xs tracking-[0.25em] text-ink uppercase">
          A. Mandavgode
        </a>

        <nav className="hidden items-center gap-6 md:flex" aria-label="Section navigation">
          {NAV_ITEMS.map((item) => {
            const isActive = activeId === item.href.slice(1);
            return (
              <a
                key={item.href}
                href={item.href}
                aria-current={isActive ? "location" : undefined}
                className={`group flex items-center gap-2 font-mono text-xs tracking-[0.2em] uppercase transition-colors ${
                  isActive ? "text-ink" : "text-mist hover:text-ink"
                }`}
              >
                <span className="text-signal">{item.index}</span>
                {item.label}
              </a>
            );
          })}
        </nav>

        <a
          href="#contact"
          className="hidden font-mono text-xs tracking-[0.2em] text-mist uppercase transition-colors hover:text-ink md:block"
        >
          Say hello →
        </a>

        <button
          type="button"
          onClick={() => setMenuOpen((open) => !open)}
          aria-expanded={menuOpen}
          aria-controls="mobile-nav-panel"
          className="font-mono text-xs tracking-[0.2em] text-mist uppercase transition-colors hover:text-ink md:hidden"
        >
          {menuOpen ? "Close" : "Menu"}
        </button>
      </Container>

      <motion.nav
        id="mobile-nav-panel"
        aria-label="Section navigation"
        initial={false}
        animate={{ height: menuOpen ? "auto" : 0 }}
        transition={{ duration: reducedMotion ? 0.01 : 0.35, ease: [0.16, 1, 0.3, 1] }}
        className="overflow-hidden border-b border-line/60 bg-void md:hidden"
      >
        <Container className="flex flex-col py-4">
          {NAV_ITEMS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={() => setMenuOpen(false)}
              className="flex items-center gap-3 py-3 font-mono text-sm tracking-[0.15em] text-mist uppercase transition-colors hover:text-ink"
            >
              <span className="text-signal">{item.index}</span>
              {item.label}
            </a>
          ))}
        </Container>
      </motion.nav>
    </header>
  );
}
