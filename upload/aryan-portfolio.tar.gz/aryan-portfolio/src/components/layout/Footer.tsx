import { Container } from "@/components/ui/Container";
import { Reveal } from "@/components/ui/Reveal";
import { profile, socials } from "@/data/profile";

export function Footer() {
  return (
    <footer className="border-t border-line py-12">
      <Container>
        <Reveal>
          <div className="flex flex-col gap-8 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="font-display text-lg text-ink">{profile.name.toUpperCase()}</p>
              <p className="mt-1 font-mono text-[11px] tracking-[0.2em] text-mist uppercase">
                Computer Engineer • Developer • Builder
              </p>
              <p className="mt-4 font-mono text-[11px] tracking-[0.15em] text-mist/70 uppercase">
                © 2026 {profile.name}
              </p>
            </div>

            <div className="flex flex-col gap-4 sm:items-end">
              <ul className="flex gap-6 font-mono text-xs tracking-[0.15em] text-mist uppercase">
                {socials.map((social) => (
                  <li key={social.label}>
                    <a
                      href={social.href}
                      target="_blank"
                      rel="noreferrer"
                      className="transition-colors hover:text-ink"
                    >
                      {social.label}
                    </a>
                  </li>
                ))}
              </ul>

              <a
                href="#top"
                className="group flex items-center gap-2 font-mono text-xs tracking-[0.15em] uppercase text-mist transition-colors hover:text-ink"
              >
                <span className="relative">
                  Back to top
                  <span
                    className="absolute -bottom-1 left-0 h-px w-full origin-left scale-x-0 bg-signal transition-transform duration-500 ease-out group-hover:scale-x-100"
                    aria-hidden="true"
                  />
                </span>
                <span
                  aria-hidden="true"
                  className="transition-transform duration-300 ease-out group-hover:-translate-y-1"
                >
                  ↑
                </span>
              </a>
            </div>
          </div>
        </Reveal>
      </Container>
    </footer>
  );
}
