"use client";

import { useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import { motion, useInView, useScroll, useSpring } from "framer-motion";
import { Container } from "@/components/ui/Container";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Reveal } from "@/components/ui/Reveal";
import { RevealLines } from "@/components/ui/RevealLines";
import { JourneyMilestone } from "./JourneyMilestone";
import { journey } from "@/data/journey";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { useIsMobileViewport } from "@/hooks/useIsMobileViewport";

const JourneyOrbScene = dynamic(
  () => import("@/components/three/JourneyOrbScene").then((m) => m.JourneyOrbScene),
  { ssr: false }
);

export function Journey() {
  const sectionRef = useRef<HTMLElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const reducedMotion = useReducedMotion();
  const isMobile = useIsMobileViewport();

  const [activeIndex, setActiveIndex] = useState(0);

  // Drives the illuminated portion of the rail as the track scrolls
  // through view.
  const { scrollYProgress } = useScroll({ target: trackRef, offset: ["start 0.8", "end 0.4"] });
  const railProgress = useSpring(scrollYProgress, { stiffness: 90, damping: 24 });

  // The orb reads the exact same progress value (via subscription, not a
  // second useScroll instance) so it stays in sync with the illuminated
  // line rather than drifting on its own timing.
  const orbProgress = useRef(0);
  useEffect(() => railProgress.on("change", (value) => { orbProgress.current = value; }), [railProgress]);

  // Gates the orb scene's render loop off entirely once the section is
  // well outside the viewport.
  const isSectionActive = useInView(sectionRef, { margin: "50% 0px" });

  return (
    <section id="journey" ref={sectionRef} className="relative border-t border-line py-28 md:py-36">
      <Container>
        <div className="max-w-2xl">
          <Reveal>
            <Eyebrow index="04">The Journey</Eyebrow>
          </Reveal>

          <div className="mt-8">
            <RevealLines
              lines={["FROM", "CURIOUS TO", "BUILDER."]}
              reducedMotion={reducedMotion}
              delay={0.1}
              className="font-display text-4xl font-medium leading-[0.95] tracking-tight text-ink sm:text-5xl md:text-6xl"
            />
          </div>

          <Reveal delay={0.45}>
            <p className="mt-8 max-w-xl text-base text-mist md:text-lg">
              A continuous journey of learning, experimenting, building and turning ideas into real
              digital experiences.
            </p>
          </Reveal>
        </div>

        <div ref={trackRef} className="relative mt-20 pl-8 md:mt-24 md:pl-12">
          <div className="absolute left-0 top-2 h-[calc(100%-1rem)] w-px bg-line" aria-hidden="true" />
          <motion.div
            className="absolute left-0 top-2 w-px origin-top bg-signal"
            style={{ scaleY: railProgress, height: "calc(100% - 1rem)" }}
            aria-hidden="true"
          />

          {!isMobile && (
            <div className="pointer-events-none absolute left-0 top-2 h-[calc(100%-1rem)] w-12 -translate-x-1/2">
              <JourneyOrbScene progress={orbProgress} isActive={isSectionActive} />
            </div>
          )}

          <ol className="space-y-20 md:space-y-24">
            {journey.map((entry, i) => (
              <JourneyMilestone
                key={entry.id}
                entry={entry}
                index={i}
                state={i === activeIndex ? "current" : i < activeIndex ? "past" : "future"}
                onActivate={setActiveIndex}
              />
            ))}
          </ol>
        </div>
      </Container>
    </section>
  );
}
