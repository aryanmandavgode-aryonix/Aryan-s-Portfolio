"use client";

import { useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import { useInView } from "framer-motion";
import { Container } from "@/components/ui/Container";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Reveal } from "@/components/ui/Reveal";
import { RevealLines } from "@/components/ui/RevealLines";
import { CornerFrame } from "@/components/ui/CornerFrame";
import { SkillInfoPanel } from "@/components/ui/SkillInfoPanel";
import { skills, skillCategories, floatingSkills } from "@/data/skills";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { useIsMobileViewport } from "@/hooks/useIsMobileViewport";

const SkillsScene = dynamic(() => import("@/components/three/SkillsScene").then((m) => m.SkillsScene), {
  ssr: false,
});

const MOBILE_FLOATING_COUNT = 5;

export function Skills() {
  const sectionRef = useRef<HTMLElement>(null);
  const visualRef = useRef<HTMLDivElement>(null);
  const reducedMotion = useReducedMotion();
  const isMobile = useIsMobileViewport();

  // Gates the Canvas's own render loop — keeps animating while the
  // section is anywhere near the viewport, stops entirely once it's far
  // away, instead of three scenes all animating off-screen forever.
  const isSectionActive = useInView(sectionRef, { margin: "50% 0px" });
  // Mounts the Canvas once, the first time the visual gets close.
  const sceneMounted = useInView(visualRef, { once: true, margin: "200px 0px" });
  // Labels stagger in slightly after the environment itself has faded in.
  const [labelsReady, setLabelsReady] = useState(false);

  const [hovered, setHovered] = useState<string | null>(null);
  const [pinned, setPinned] = useState<string | null>(null);
  const activeName = hovered ?? pinned;
  const activeSkill = skills.find((skill) => skill.name === activeName) ?? null;

  useEffect(() => {
    if (!sceneMounted) return;
    const timer = setTimeout(() => setLabelsReady(true), reducedMotion ? 0 : 500);
    return () => clearTimeout(timer);
  }, [sceneMounted, reducedMotion]);

  const orbitItems = isMobile ? floatingSkills.slice(0, MOBILE_FLOATING_COUNT) : floatingSkills;

  const handleSelect = (name: string) => setPinned((prev) => (prev === name ? null : name));

  return (
    <section id="skills" ref={sectionRef} className="relative border-t border-line py-28 md:py-36">
      <Container>
        <div className="max-w-2xl">
          <Reveal>
            <Eyebrow index="02">Technology</Eyebrow>
          </Reveal>

          <div className="mt-8">
            <RevealLines
              lines={["TOOLS I USE", "TO BUILD."]}
              reducedMotion={reducedMotion}
              delay={0.1}
              className="font-display text-4xl font-medium leading-[0.95] tracking-tight text-ink sm:text-5xl md:text-6xl"
            />
          </div>

          <Reveal delay={0.4}>
            <p className="mt-8 max-w-xl text-base text-mist md:text-lg">
              From interfaces to backend systems, I enjoy turning ideas into fast, functional and
              visually refined digital experiences.
            </p>
          </Reveal>
        </div>

        {/* the 3D technology universe, with its info panel anchored beneath it */}
        <div
          ref={visualRef}
          className="relative mt-16 aspect-[4/3] w-full overflow-hidden border-t border-line pt-8 md:mt-20 md:aspect-[16/9]"
        >
          <div className="relative h-[70%] w-full">
            <CornerFrame />
            {sceneMounted && (
              <SkillsScene
                items={orbitItems}
                active={activeName}
                ready={labelsReady}
                isActive={isSectionActive}
                onHover={setHovered}
                onFocus={setHovered}
                onSelect={handleSelect}
              />
            )}
          </div>
          <SkillInfoPanel skill={activeSkill} />
        </div>

        {/* fully accessible list — every skill, every description, no hover required */}
        <div className="mt-16 grid grid-cols-2 gap-x-8 gap-y-12 md:mt-20 md:grid-cols-3 lg:grid-cols-5">
          {skillCategories.map((category, i) => (
            <Reveal key={category} delay={0.1 + i * 0.05}>
              <div>
                <p className="font-mono text-xs tracking-[0.2em] text-signal uppercase">{category}</p>
                <ul className="mt-6 space-y-4">
                  {skills
                    .filter((skill) => skill.category === category)
                    .map((skill) => (
                      <li key={skill.name} className="border-b border-line pb-4">
                        <button
                          type="button"
                          onMouseEnter={() => setHovered(skill.name)}
                          onMouseLeave={() => setHovered(null)}
                          onFocus={() => setHovered(skill.name)}
                          onBlur={() => setHovered(null)}
                          onClick={() => handleSelect(skill.name)}
                          className={`text-left font-display text-xl transition-colors md:text-2xl ${
                            activeName === skill.name ? "text-ink" : "text-mist hover:text-ink"
                          }`}
                        >
                          {skill.name}
                        </button>
                      </li>
                    ))}
                </ul>
              </div>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
