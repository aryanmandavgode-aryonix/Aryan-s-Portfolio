"use client";

import { useRef } from "react";
import dynamic from "next/dynamic";
import { motion, useInView } from "framer-motion";
import { Container } from "@/components/ui/Container";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Reveal } from "@/components/ui/Reveal";
import { RevealLines } from "@/components/ui/RevealLines";
import { AboutStat } from "@/components/ui/AboutStat";
import { profile, aboutStats } from "@/data/profile";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { useScrollProgressRef } from "@/hooks/useScrollProgressRef";

const AboutScene = dynamic(() => import("@/components/three/AboutScene").then((m) => m.AboutScene), {
  ssr: false,
});

const EASE = [0.16, 1, 0.3, 1] as const;

export function About() {
  const sectionRef = useRef<HTMLElement>(null);
  const visualRef = useRef<HTMLDivElement>(null);
  const reducedMotion = useReducedMotion();
  const scrollProgress = useScrollProgressRef(sectionRef);
  // Mounts the Canvas once the visual panel is close to the viewport, and
  // keeps it mounted after — avoids paying for a WebGL context up front.
  const sceneReady = useInView(visualRef, { once: true, margin: "200px 0px" });
  // Gates the Canvas's own render loop off once scrolled well past About.
  const isSectionActive = useInView(sectionRef, { margin: "50% 0px" });

  return (
    <section id="about" ref={sectionRef} className="relative border-t border-line py-28 md:py-36">
      <Container>
        <div className="grid gap-16 lg:grid-cols-12 lg:items-center">
          <div className="lg:col-span-7">
            <Reveal>
              <Eyebrow index="01">About Me</Eyebrow>
            </Reveal>

            <div className="mt-8">
              <RevealLines
                lines={[...profile.headline]}
                reducedMotion={reducedMotion}
                delay={0.15}
                className="font-display text-4xl font-medium leading-[0.95] tracking-tight text-ink sm:text-5xl md:text-6xl"
              />
            </div>

            <Reveal delay={0.5}>
              <p className="mt-8 max-w-xl text-base text-mist md:text-lg">{profile.intro}</p>
            </Reveal>

            <div className="mt-16 grid grid-cols-2 gap-x-8 gap-y-10 sm:grid-cols-4">
              {aboutStats.map((stat, i) => (
                <Reveal key={stat.label} delay={0.85 + i * 0.08}>
                  <AboutStat {...stat} />
                </Reveal>
              ))}
            </div>
          </div>

          <motion.div
            ref={visualRef}
            initial={{ opacity: 0, scale: reducedMotion ? 1 : 0.94 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: "-10% 0px -10% 0px" }}
            transition={{ duration: 0.9, delay: 0.6, ease: EASE }}
            className="relative aspect-square w-full lg:col-span-5"
          >
            {sceneReady && <AboutScene scrollProgress={scrollProgress} isActive={isSectionActive} />}
          </motion.div>
        </div>
      </Container>
    </section>
  );
}
