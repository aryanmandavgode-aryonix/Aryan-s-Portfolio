"use client";

import { useEffect, useRef } from "react";
import { useInView } from "framer-motion";
import { Reveal } from "@/components/ui/Reveal";
import type { JourneyEntry } from "@/types";

interface JourneyMilestoneProps {
  entry: JourneyEntry;
  index: number;
  state: "future" | "current" | "past";
  onActivate: (index: number) => void;
}

/**
 * Two independent things happen here: a one-time staggered reveal as the
 * milestone first enters view (number -> title -> description -> focus,
 * via the shared Reveal component), and a separate, continuously-updating
 * "current position" state — color/size/shape only, not a fade — that
 * tracks scroll position back and forth as the user scrolls.
 */
export function JourneyMilestone({ entry, index, state, onActivate }: JourneyMilestoneProps) {
  const ref = useRef<HTMLLIElement>(null);
  const inCenterBand = useInView(ref, { margin: "-42% 0px -42% 0px" });

  useEffect(() => {
    if (inCenterBand) onActivate(index);
  }, [inCenterBand, index, onActivate]);

  const isCurrent = state === "current";
  const isPast = state === "past";

  return (
    <li ref={ref} className="relative">
      {/* node: shape + size change (not color alone) signal reached/current/future */}
      <span
        className={`absolute -left-[2.35rem] top-1.5 flex items-center justify-center md:-left-[3.35rem]`}
        aria-hidden="true"
      >
        <span
          className={`block rounded-full transition-all duration-500 ${
            isCurrent ? "h-3 w-3 bg-signal" : isPast ? "h-2 w-2 bg-signal/70" : "h-1.5 w-1.5 border border-line bg-void"
          }`}
          style={
            isCurrent
              ? { boxShadow: "0 0 0 7px color-mix(in srgb, var(--signal) 16%, transparent)" }
              : undefined
          }
        />
      </span>

      <Reveal>
        <p
          className={`font-mono tracking-[0.2em] transition-all duration-500 ${
            isCurrent ? "text-base text-signal" : isPast ? "text-sm text-mist" : "text-sm text-mist/70"
          }`}
        >
          {entry.index}
        </p>
      </Reveal>

      <Reveal delay={0.1}>
        <h3
          className={`mt-3 font-display text-3xl font-medium tracking-tight transition-colors duration-500 md:text-4xl ${
            isCurrent || isPast ? "text-ink" : "text-mist"
          }`}
        >
          {entry.title}
        </h3>
      </Reveal>

      <Reveal delay={0.2}>
        <p className="mt-4 max-w-xl text-sm text-mist md:text-base">{entry.description}</p>
      </Reveal>

      <Reveal delay={0.3}>
        <div className="mt-5">
          <p className="font-mono text-[10px] tracking-[0.25em] text-mist/70 uppercase">Focus</p>
          <ul className="mt-2 flex flex-wrap gap-x-5 gap-y-1.5 font-mono text-xs tracking-[0.1em] text-mist uppercase">
            {entry.focus.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </div>
      </Reveal>
    </li>
  );
}
