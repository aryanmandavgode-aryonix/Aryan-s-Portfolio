"use client";

import { useRef } from "react";
import dynamic from "next/dynamic";
import { motion, useInView, useTransform } from "framer-motion";
import { Container } from "@/components/ui/Container";
import { CornerFrame } from "@/components/ui/CornerFrame";
import { GrainOverlay } from "@/components/ui/GrainOverlay";
import { ScrollIndicator } from "@/components/ui/ScrollIndicator";
import { profile } from "@/data/profile";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { useMouseParallax } from "@/hooks/useMouseParallax";

const HeroScene = dynamic(() => import("@/components/three/HeroScene").then((m) => m.HeroScene), {
  ssr: false,
});

const EASE = [0.16, 1, 0.3, 1] as const;

// Cinematic stagger: curtain/background -> 3D object -> name -> subtitle -> CTA -> chrome.
const DELAY = {
  scene: 0.3,
  name: 0.65,
  subtitle: 0.95,
  cta: 1.15,
  scroll: 1.4,
};

export function Hero() {
  const sectionRef = useRef<HTMLElement>(null);
  const reducedMotion = useReducedMotion();
  const { x: mx, y: my } = useMouseParallax(reducedMotion);
  const nameX = useTransform(mx, [-1, 1], reducedMotion ? [0, 0] : [-10, 10]);
  const nameY = useTransform(my, [-1, 1], reducedMotion ? [0, 0] : [-6, 6]);
  const subX = useTransform(mx, [-1, 1], reducedMotion ? [0, 0] : [-5, 5]);
  // Gates the Canvas's own render loop off once scrolled well past Hero.
  const isSectionActive = useInView(sectionRef, { margin: "50% 0px" });

  return (
    <section
      id="top"
      ref={sectionRef}
      className="relative flex min-h-[100svh] items-center overflow-hidden bg-void"
    >
      {/* curtain — lifts first so the void + atmosphere read as the opening beat */}
      <motion.div
        initial={{ opacity: 1 }}
        animate={{ opacity: 0 }}
        transition={{ duration: 1, ease: EASE }}
        className="pointer-events-none absolute inset-0 z-30 bg-void"
      />

      <motion.div
        initial={{ opacity: 0, scale: reducedMotion ? 1 : 1.04 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1.4, delay: DELAY.scene, ease: EASE }}
        className="absolute inset-0"
      >
        <HeroScene isActive={isSectionActive} />
      </motion.div>

      {/* atmospheric glow behind the object, and a vignette back to void at the edges */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(60% 50% at 50% 45%, color-mix(in srgb, var(--signal) 12%, transparent), transparent 70%)",
        }}
        aria-hidden="true"
      />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-void via-transparent to-void/50" />
      <GrainOverlay />

      <CornerFrame />
      <div className="absolute right-8 top-24 hidden font-mono text-[11px] tracking-[0.2em] text-mist md:right-12 md:block">
        <p>{profile.coordinates}</p>
        <p>{profile.location.toUpperCase()}</p>
      </div>

      <Container className="relative z-10">
        <motion.p
          initial={{ opacity: 0, y: reducedMotion ? 0 : 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: DELAY.name - 0.05, ease: EASE }}
          className="mb-6 font-mono text-xs tracking-[0.3em] text-mist uppercase"
        >
          {profile.role}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: reducedMotion ? 0 : 36 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.1, delay: DELAY.name, ease: EASE }}
        >
          <motion.h1
            style={{ x: nameX, y: nameY }}
            className="font-display text-[clamp(2.75rem,13vw,9.5rem)] font-medium leading-[0.84] tracking-[-0.02em] text-ink"
          >
            ARYAN
            <br />
            MANDAVGODE
          </motion.h1>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: reducedMotion ? 0 : 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: DELAY.subtitle, ease: EASE }}
          className="mt-10 flex flex-col items-start gap-8 sm:flex-row sm:items-end sm:justify-between"
        >
          <motion.div
            style={{ x: subX }}
            className="flex flex-col gap-1.5 font-mono text-xs tracking-[0.3em] text-mist uppercase"
          >
            <span>Computer Engineer</span>
            <span>Developer</span>
            <span>Builder</span>
          </motion.div>

          <a
            href="#about"
            className="group flex items-center gap-3 font-mono text-xs tracking-[0.2em] text-ink uppercase"
          >
            <span className="relative inline-block transition-transform duration-300 ease-out group-hover:-translate-y-0.5">
              Explore my work
              <span
                className="absolute -bottom-1 left-0 h-px w-full origin-left scale-x-0 bg-signal transition-transform duration-500 ease-out group-hover:scale-x-100"
                aria-hidden="true"
              />
            </span>
            <span
              className="inline-block transition-transform duration-300 ease-out group-hover:translate-y-1"
              aria-hidden="true"
            >
              ↓
            </span>
          </a>
        </motion.div>
      </Container>

      <ScrollIndicator reducedMotion={reducedMotion} delay={DELAY.scroll} />
    </section>
  );
}
