"use client";

import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Container } from "@/components/ui/Container";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Reveal } from "@/components/ui/Reveal";
import { RevealLines } from "@/components/ui/RevealLines";
import { GrainOverlay } from "@/components/ui/GrainOverlay";
import { MagneticCTA } from "@/components/ui/MagneticCTA";
import { profile, socials } from "@/data/profile";
import { aryonix } from "@/data/aryonix";
import { useReducedMotion } from "@/hooks/useReducedMotion";

// Fixed, deterministic positions for a very faint atmospheric particle
// field — cheap CSS, not a new WebGL scene, since this closing section is
// meant to feel calm rather than add another showcase object.
const ATMOSPHERE_DOTS = [
  { top: "18%", left: "12%", size: 3 },
  { top: "62%", left: "8%", size: 2 },
  { top: "30%", left: "88%", size: 2 },
  { top: "75%", left: "80%", size: 3 },
  { top: "48%", left: "50%", size: 2 },
];

export function Contact() {
  const sectionRef = useRef<HTMLElement>(null);
  const reducedMotion = useReducedMotion();

  // Background gradually darkens as the section is scrolled into view.
  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ["start end", "start start"] });
  const darken = useTransform(scrollYProgress, [0, 1], reducedMotion ? [0.3, 0.3] : [0, 0.3]);

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="relative overflow-hidden border-t border-line py-28 md:py-40"
    >
      <motion.div className="pointer-events-none absolute inset-0 bg-black" style={{ opacity: darken }} aria-hidden="true" />
      <div className="pointer-events-none absolute inset-0" aria-hidden="true">
        {ATMOSPHERE_DOTS.map((dot, i) => (
          <span
            key={i}
            className="absolute rounded-full bg-mist opacity-[0.08] blur-sm"
            style={{ top: dot.top, left: dot.left, width: dot.size, height: dot.size }}
          />
        ))}
      </div>
      <GrainOverlay />

      <Container className="relative">
        <Reveal>
          <Eyebrow index="06">Contact</Eyebrow>
        </Reveal>

        <div className="mt-8">
          <RevealLines
            lines={["LET'S BUILD", "SOMETHING", "UNEXPECTED."]}
            reducedMotion={reducedMotion}
            delay={0.1}
            className="font-display text-4xl font-medium leading-[0.95] tracking-tight text-ink sm:text-5xl md:text-6xl"
          />
        </div>

        <Reveal delay={0.5}>
          <p className="mt-8 max-w-md text-base text-mist md:text-lg">
            Have an idea, opportunity or project in mind?
            <br />
            Let&rsquo;s talk.
          </p>
        </Reveal>

        <Reveal delay={0.65}>
          <MagneticCTA href={`mailto:${profile.email}`} className="mt-12">
            <span className="relative font-display text-2xl text-ink md:text-3xl">
              Get in touch
              <span
                className="absolute -bottom-1 left-0 h-px w-full origin-left scale-x-0 bg-signal transition-transform duration-500 ease-out group-hover:scale-x-100"
                aria-hidden="true"
              />
            </span>
            <span
              aria-hidden="true"
              className="text-2xl text-ink transition-transform duration-300 group-hover:translate-x-1 md:text-3xl"
            >
              →
            </span>
          </MagneticCTA>
        </Reveal>

        <Reveal delay={0.85}>
          <div className="mt-20 flex flex-col gap-8 border-t border-line pt-8 sm:flex-row sm:items-center sm:justify-between">
            <ul className="flex flex-wrap gap-x-10 gap-y-3 font-mono text-xs tracking-[0.15em] text-mist uppercase">
              <li>
                <a href={`mailto:${profile.email}`} className="transition-colors hover:text-ink">
                  {profile.email}
                </a>
              </li>
              {socials.map((social) => (
                <li key={social.label}>
                  <a href={social.href} target="_blank" rel="noreferrer" className="transition-colors hover:text-ink">
                    {social.label}
                  </a>
                </li>
              ))}
            </ul>

            <a
              href={aryonix.url}
              target="_blank"
              rel="noreferrer"
              className="font-mono text-xs tracking-[0.15em] text-mist uppercase transition-colors hover:text-ink"
            >
              Building with <span className="text-signal">ARYONIX</span>.
            </a>
          </div>
        </Reveal>
      </Container>
    </section>
  );
}
