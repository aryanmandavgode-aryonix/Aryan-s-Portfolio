"use client";

import { useRef } from "react";
import dynamic from "next/dynamic";
import { motion, useInView, useScroll, useTransform } from "framer-motion";
import { Container } from "@/components/ui/Container";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Reveal } from "@/components/ui/Reveal";
import { RevealLines } from "@/components/ui/RevealLines";
import { GrainOverlay } from "@/components/ui/GrainOverlay";
import { CTALink } from "@/components/ui/CTALink";
import { aryonix } from "@/data/aryonix";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { useScrollProgressRef } from "@/hooks/useScrollProgressRef";

const AryonixScene = dynamic(() => import("@/components/three/AryonixScene").then((m) => m.AryonixScene), {
  ssr: false,
});

export function Aryonix() {
  const sectionRef = useRef<HTMLElement>(null);
  const visualRef = useRef<HTMLDivElement>(null);
  const reducedMotion = useReducedMotion();

  const scrollProgress = useScrollProgressRef(visualRef);
  const isSectionActive = useInView(sectionRef, { margin: "50% 0px" });
  const sceneMounted = useInView(visualRef, { once: true, margin: "200px 0px" });

  // Drives only the atmospheric/hero portion (glow, grain, heading, 3D
  // scene, brand statement): dim on entry, full through the middle, dim
  // again on exit — "screen becomes more atmospheric" coming in, "3D
  // object moves away / typography fades" going out. The services/CTA
  // area below is deliberately NOT tied to this — it stays fully
  // readable regardless of scroll position or motion preference.
  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ["start end", "end start"] });
  const heroOpacity = useTransform(
    scrollYProgress,
    [0, 0.18, 0.75, 1],
    reducedMotion ? [1, 1, 1, 1] : [0.15, 1, 1, 0.35]
  );
  const heroShift = useTransform(scrollYProgress, [0.75, 1], reducedMotion ? [0, 0] : [0, -24]);

  return (
    <section
      id="aryonix"
      ref={sectionRef}
      className="relative overflow-hidden border-t border-line bg-void py-28 md:py-36"
    >
      <motion.div style={{ opacity: heroOpacity, y: heroShift }} className="relative">
        <div
          className="pointer-events-none absolute inset-0"
          style={{
            background:
              "radial-gradient(65% 55% at 50% 30%, color-mix(in srgb, var(--signal) 10%, transparent), transparent 70%)",
          }}
          aria-hidden="true"
        />
        <GrainOverlay />

        <Container className="relative">
          <Reveal>
            <Eyebrow index="05">Aryonix</Eyebrow>
          </Reveal>

          <div className="mt-8">
            <RevealLines
              lines={[...aryonix.heroLines]}
              reducedMotion={reducedMotion}
              delay={0.1}
              className="max-w-3xl font-display text-4xl font-medium leading-[0.95] tracking-tight text-ink sm:text-5xl md:text-6xl"
            />
          </div>

          <Reveal delay={0.45}>
            <p className="mt-8 max-w-xl text-base text-mist md:text-lg">{aryonix.intro}</p>
          </Reveal>
        </Container>

        <div ref={visualRef} className="relative mt-16 aspect-[16/10] w-full md:mt-20 md:aspect-[21/9]">
          {sceneMounted && <AryonixScene scrollProgress={scrollProgress} isActive={isSectionActive} />}
        </div>

        <Container className="relative mt-4">
          <RevealLines
            lines={["DESIGN.", "DEVELOP.", "DEPLOY."]}
            reducedMotion={reducedMotion}
            delay={0.1}
            stagger={0.15}
            as="h3"
            className="font-display text-3xl font-medium leading-[1.05] tracking-tight text-ink sm:text-4xl md:text-5xl"
          />
        </Container>
      </motion.div>

      {/* info area — always fully visible, never tied to the scroll-linked opacity above */}
      <Container className="relative mt-24 md:mt-32">
        <div className="grid gap-12 border-t border-line pt-12 md:grid-cols-12 md:gap-16">
          <div className="md:col-span-5">
            <p className="font-display text-2xl text-ink md:text-3xl">{aryonix.name}</p>
            <p className="mt-2 font-mono text-xs tracking-[0.15em] text-mist uppercase">{aryonix.positioning}</p>
          </div>

          <div className="md:col-span-4">
            <p className="font-mono text-xs tracking-[0.2em] text-signal uppercase">Services</p>
            <ul className="mt-4 space-y-2">
              {aryonix.services.map((service) => (
                <li key={service} className="text-mist md:text-lg">
                  {service}
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-3 md:flex md:items-end md:justify-end">
            <CTALink label="Explore Aryonix" href={aryonix.url} />
          </div>
        </div>
      </Container>
    </section>
  );
}
