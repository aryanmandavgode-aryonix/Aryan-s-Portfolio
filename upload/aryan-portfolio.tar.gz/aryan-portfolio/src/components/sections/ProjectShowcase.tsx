"use client";

import { useRef } from "react";
import { motion, useScroll, useTransform, type MotionValue } from "framer-motion";
import { Reveal } from "@/components/ui/Reveal";
import { CTALink } from "@/components/ui/CTALink";
import { AryonixVisual } from "@/components/ui/project-visuals/AryonixVisual";
import { AqiDashboardVisual } from "@/components/ui/project-visuals/AqiDashboardVisual";
import { ClientProjectsVisual } from "@/components/ui/project-visuals/ClientProjectsVisual";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import type { ProjectItem } from "@/types";

const VISUALS = {
  aryonix: AryonixVisual,
  "aqi-dashboard": AqiDashboardVisual,
  "client-projects": ClientProjectsVisual,
} as const;

interface ProjectShowcaseProps {
  project: ProjectItem;
  total: number;
  reverse: boolean;
  parallax: { x: MotionValue<number>; y: MotionValue<number> };
}

/**
 * Each project gets its own scroll-linked scale/opacity (via useScroll on
 * its own ref) so the visual scales subtly and the whole block dims as it
 * moves past — a cinematic transition driven by natural scroll, not a
 * pinned/scroll-jacked carousel.
 */
export function ProjectShowcase({ project, total, reverse, parallax }: ProjectShowcaseProps) {
  const reducedMotion = useReducedMotion();
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });

  const scale = useTransform(scrollYProgress, [0, 0.5, 1], reducedMotion ? [1, 1, 1] : [0.94, 1, 0.96]);
  const blockOpacity = useTransform(
    scrollYProgress,
    [0, 0.15, 0.85, 1],
    reducedMotion ? [1, 1, 1, 1] : [0.5, 1, 1, 0.6]
  );
  const parallaxX = useTransform(parallax.x, [-1, 1], reducedMotion ? [0, 0] : [-14, 14]);
  const parallaxY = useTransform(parallax.y, [-1, 1], reducedMotion ? [0, 0] : [-10, 10]);

  const Visual = VISUALS[project.visual];

  return (
    <motion.div ref={ref} style={{ opacity: blockOpacity }} className="border-t border-line py-20 md:py-28">
      <Reveal>
        <p className="font-mono text-xs tracking-[0.25em] text-mist uppercase">
          <span className="text-signal">{project.index}</span> / {String(total).padStart(2, "0")}
        </p>
      </Reveal>

      <Reveal delay={0.05}>
        <h3 className="mt-4 font-display text-4xl font-medium leading-[0.95] tracking-tight text-ink sm:text-5xl md:text-6xl">
          {project.title}
        </h3>
      </Reveal>

      <Reveal delay={0.15}>
        <motion.div
          style={{ scale, x: parallaxX, y: parallaxY }}
          className="mt-10 aspect-[16/10] w-full overflow-hidden border border-line md:mt-12"
        >
          <Visual />
        </motion.div>
      </Reveal>

      <div
        className={`mt-10 flex flex-col gap-10 md:mt-12 md:flex-row md:gap-16 ${
          reverse ? "md:flex-row-reverse" : ""
        }`}
      >
        <Reveal delay={0.1} className="md:w-3/5">
          <p className="font-mono text-xs tracking-[0.2em] text-signal uppercase">{project.category}</p>
          <p className="mt-4 max-w-xl text-base text-mist md:text-lg">{project.description}</p>
        </Reveal>

        <Reveal delay={0.2} className="md:w-2/5">
          <ul className="flex flex-wrap gap-x-6 gap-y-2 font-mono text-xs tracking-[0.1em] text-mist uppercase">
            {project.technologies.map((tech) => (
              <li key={tech}>{tech}</li>
            ))}
          </ul>
          <div className="mt-8 flex flex-wrap items-center gap-8">
            <CTALink label="View project" href={project.liveUrl} />
            <CTALink label="View code" href={project.githubUrl} />
          </div>
        </Reveal>
      </div>
    </motion.div>
  );
}
