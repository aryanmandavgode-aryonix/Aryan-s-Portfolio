"use client";

import { Container } from "@/components/ui/Container";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Reveal } from "@/components/ui/Reveal";
import { RevealLines } from "@/components/ui/RevealLines";
import { ProjectShowcase } from "./ProjectShowcase";
import { projects } from "@/data/projects";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { useMouseParallax } from "@/hooks/useMouseParallax";
import { useIsMobileViewport } from "@/hooks/useIsMobileViewport";

export function Projects() {
  const reducedMotion = useReducedMotion();
  const isMobile = useIsMobileViewport();
  // One shared pointer listener for all three showcases rather than one
  // each — cursor parallax is desktop-only per the brief, so it's fully
  // disabled (no listener at all) on mobile or under reduced motion.
  const parallax = useMouseParallax(reducedMotion || isMobile);

  return (
    <section id="projects" className="border-t border-line py-28 md:py-36">
      <Container>
        <div className="max-w-2xl">
          <Reveal>
            <Eyebrow index="03">Selected Work</Eyebrow>
          </Reveal>

          <div className="mt-8">
            <RevealLines
              lines={["THINGS", "I'VE BUILT."]}
              reducedMotion={reducedMotion}
              delay={0.1}
              className="font-display text-4xl font-medium leading-[0.95] tracking-tight text-ink sm:text-5xl md:text-6xl"
            />
          </div>

          <Reveal delay={0.4}>
            <p className="mt-8 max-w-xl text-base text-mist md:text-lg">
              A selection of digital products, experiments and experiences I&rsquo;ve designed and
              developed.
            </p>
          </Reveal>
        </div>

        <div className="mt-4">
          {projects.map((project, i) => (
            <ProjectShowcase
              key={project.id}
              project={project}
              total={projects.length}
              reverse={i % 2 === 1}
              parallax={parallax}
            />
          ))}
        </div>
      </Container>
    </section>
  );
}
