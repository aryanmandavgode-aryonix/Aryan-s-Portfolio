import { MockupChrome } from "./MockupChrome";

// Deterministic offsets — a loose stack of generic window compositions,
// not a depiction of any real business or design.
const CARDS = [
  { rotate: -6, x: "-18%", y: "-8%", w: "58%", h: "58%" },
  { rotate: 4, x: "10%", y: "0%", w: "58%", h: "58%" },
  { rotate: -2, x: "-2%", y: "14%", w: "58%", h: "58%" },
];

export function ClientProjectsVisual() {
  return (
    <div className="flex h-full w-full flex-col bg-surface" aria-hidden="true">
      <MockupChrome label="client-work" />
      <div className="relative flex-1 overflow-hidden">
        {CARDS.map((card, i) => (
          <div
            key={i}
            className="absolute left-1/2 top-1/2 border border-line bg-void"
            style={{
              width: card.w,
              height: card.h,
              transform: `translate(-50%, -50%) translate(${card.x}, ${card.y}) rotate(${card.rotate}deg)`,
              zIndex: i,
            }}
          >
            <div className="flex items-center gap-1.5 border-b border-line/70 px-3 py-2">
              <span className="h-1 w-1 rounded-full bg-line" />
              <span className="h-1 w-1 rounded-full bg-line" />
              <span className="h-1 w-1 rounded-full bg-line" />
            </div>
            <div className="space-y-2 p-3">
              <div className="h-8 w-full bg-line/40" />
              <div className="h-1.5 w-3/4 bg-line/70" />
              <div className="h-1.5 w-1/2 bg-line/50" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
