import { MockupChrome } from "./MockupChrome";

// Deterministic bar heights — purely decorative, not real readings.
const BAR_HEIGHTS = [30, 55, 40, 70, 48, 62, 36];
const RADIUS = 42;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

/**
 * A self-contained dashboard mockup: an abstract bar chart and a circular
 * gauge. The reading shown ("Moderate") is illustrative dashboard chrome,
 * not a reported metric from a real deployment.
 */
export function AqiDashboardVisual() {
  return (
    <div className="flex h-full w-full flex-col bg-surface" aria-hidden="true">
      <MockupChrome label="aqi-dashboard" />
      <div className="flex flex-1 items-center gap-8 px-6 py-6 sm:px-8">
        <div className="flex h-full flex-1 items-end gap-2 sm:gap-3">
          {BAR_HEIGHTS.map((height, i) => (
            <div
              key={i}
              className={`w-full rounded-t-sm ${i === 3 ? "bg-signal/70" : "bg-line"}`}
              style={{ height: `${height}%` }}
            />
          ))}
        </div>

        <div className="flex flex-col items-center gap-3">
          <svg viewBox="0 0 100 100" className="h-20 w-20 -rotate-90 sm:h-24 sm:w-24">
            <circle cx="50" cy="50" r={RADIUS} fill="none" stroke="var(--line)" strokeWidth="6" />
            <circle
              cx="50"
              cy="50"
              r={RADIUS}
              fill="none"
              stroke="var(--signal)"
              strokeWidth="6"
              strokeLinecap="round"
              strokeDasharray={CIRCUMFERENCE}
              strokeDashoffset={CIRCUMFERENCE * (1 - 0.62)}
            />
          </svg>
          <p className="whitespace-nowrap font-mono text-[10px] tracking-[0.2em] text-mist uppercase">
            AQI · Moderate
          </p>
        </div>
      </div>
    </div>
  );
}
