import { MockupChrome } from "./MockupChrome";

/**
 * A self-contained futuristic agency-style mockup: faux browser chrome,
 * a faint grid, a couple of abstract offset UI blocks, and the ARYONIX
 * wordmark. Purely a stand-in visual — not a screenshot of the real site.
 */
export function AryonixVisual() {
  return (
    <div className="flex h-full w-full flex-col bg-surface" aria-hidden="true">
      <MockupChrome label="aryonix.studio" />
      <div className="relative flex flex-1 items-center justify-center overflow-hidden">
        <div
          className="pointer-events-none absolute inset-0 opacity-[0.15]"
          style={{
            backgroundImage:
              "linear-gradient(var(--line) 1px, transparent 1px), linear-gradient(90deg, var(--line) 1px, transparent 1px)",
            backgroundSize: "40px 40px",
          }}
        />
        <div className="absolute left-[12%] top-[20%] h-24 w-32 -rotate-6 border border-line/70" />
        <div className="absolute bottom-[15%] right-[14%] h-16 w-16 rotate-12 rounded-full border border-signal/40" />
        <span className="absolute right-[10%] top-[12%] h-2 w-2 rounded-full bg-signal" />

        <div className="relative text-center">
          <p className="font-display text-4xl font-medium tracking-tight text-ink sm:text-5xl">ARYONIX</p>
          <p className="mt-3 font-mono text-[11px] tracking-[0.35em] text-mist uppercase">
            Design. Develop. Deploy.
          </p>
        </div>
      </div>
    </div>
  );
}
