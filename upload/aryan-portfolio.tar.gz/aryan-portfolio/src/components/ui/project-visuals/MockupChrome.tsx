interface MockupChromeProps {
  label: string;
}

export function MockupChrome({ label }: MockupChromeProps) {
  return (
    <div className="flex items-center gap-2 border-b border-line/70 px-4 py-3">
      <span className="h-1.5 w-1.5 rounded-full bg-line" />
      <span className="h-1.5 w-1.5 rounded-full bg-line" />
      <span className="h-1.5 w-1.5 rounded-full bg-line" />
      <span className="ml-3 font-mono text-[10px] tracking-[0.15em] text-mist/70 uppercase">{label}</span>
    </div>
  );
}
