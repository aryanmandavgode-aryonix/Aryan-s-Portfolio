"use client";

import { useEffect, useRef, useState } from "react";
import { useInView } from "framer-motion";
import { useReducedMotion } from "@/hooks/useReducedMotion";

interface AboutStatProps {
  value: string;
  label: string;
}

const isNumeric = (value: string) => /^\d+$/.test(value);

/**
 * Digit-only values (e.g. "19") count up once visible, same idea as the
 * old StatCounter. Non-numeric values (SE, ARYONIX, ∞) have nothing to
 * count, so they render as-is — the wrapping <Reveal> handles entrance.
 */
export function AboutStat({ value, label }: AboutStatProps) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-10% 0px -10% 0px" });
  const reducedMotion = useReducedMotion();
  const numeric = isNumeric(value);
  const target = numeric ? parseInt(value, 10) : 0;
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    if (!inView || !numeric || reducedMotion) return;

    const duration = 1000;
    const start = performance.now();
    const tick = (now: number) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplay(Math.round(eased * target));
      if (progress < 1) requestAnimationFrame(tick);
    };
    const frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [inView, numeric, reducedMotion, target]);

  const shown = !numeric ? value : reducedMotion ? (inView ? target : 0) : display;

  return (
    <div ref={ref} className="border-t border-line pt-5">
      <p className="font-display text-4xl font-medium text-ink md:text-5xl">{shown}</p>
      <p className="mt-2 font-mono text-[11px] tracking-[0.2em] text-mist uppercase">{label}</p>
    </div>
  );
}
