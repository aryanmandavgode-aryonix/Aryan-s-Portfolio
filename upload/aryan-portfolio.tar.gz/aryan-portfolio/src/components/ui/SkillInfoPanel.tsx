"use client";

import { AnimatePresence, motion } from "framer-motion";
import type { SkillItem } from "@/types";
import { useReducedMotion } from "@/hooks/useReducedMotion";

interface SkillInfoPanelProps {
  skill: SkillItem | null;
}

const EASE = [0.16, 1, 0.3, 1] as const;

/**
 * Driven by hover, focus, or click from either the 3D orbit or the
 * accessible list below — nothing here is gated behind hover alone.
 * aria-live announces changes for screen reader users regardless of how
 * the active skill was set.
 */
export function SkillInfoPanel({ skill }: SkillInfoPanelProps) {
  const reducedMotion = useReducedMotion();

  return (
    <div className="min-h-[6.5rem] border-t border-line pt-6" aria-live="polite">
      <AnimatePresence mode="wait">
        {skill ? (
          <motion.div
            key={skill.name}
            initial={{ opacity: 0, y: reducedMotion ? 0 : 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: reducedMotion ? 0 : -6 }}
            transition={{ duration: reducedMotion ? 0.01 : 0.35, ease: EASE }}
          >
            <p className="font-mono text-xs tracking-[0.2em] text-signal uppercase">{skill.category}</p>
            <p className="mt-2 font-display text-2xl text-ink md:text-3xl">{skill.name}</p>
            <p className="mt-2 max-w-md text-sm text-mist">{skill.description}</p>
          </motion.div>
        ) : (
          <motion.p
            key="idle"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: reducedMotion ? 0.01 : 0.35 }}
            className="max-w-md font-mono text-xs tracking-[0.15em] text-mist uppercase"
          >
            Hover, focus, or tap a technology to read more.
          </motion.p>
        )}
      </AnimatePresence>
    </div>
  );
}
