"use client";

import { useRef, type MouseEvent, type ReactNode } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";
import { useReducedMotion } from "@/hooks/useReducedMotion";

interface MagneticCTAProps {
  href: string;
  children: ReactNode;
  className?: string;
}

/**
 * A restrained "magnetic button": on pointer move within its bounds it
 * drifts a few px toward the cursor, then springs back on leave. The
 * link itself always works normally — this only ever affects the visual
 * position, and is skipped entirely under reduced motion.
 */
export function MagneticCTA({ href, children, className }: MagneticCTAProps) {
  const ref = useRef<HTMLAnchorElement>(null);
  const reducedMotion = useReducedMotion();
  const rawX = useMotionValue(0);
  const rawY = useMotionValue(0);
  const x = useSpring(rawX, { stiffness: 200, damping: 18, mass: 0.4 });
  const y = useSpring(rawY, { stiffness: 200, damping: 18, mass: 0.4 });

  const handleMove = (event: MouseEvent<HTMLAnchorElement>) => {
    if (reducedMotion || !ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    rawX.set((event.clientX - rect.left - rect.width / 2) * 0.25);
    rawY.set((event.clientY - rect.top - rect.height / 2) * 0.4);
  };

  const handleLeave = () => {
    rawX.set(0);
    rawY.set(0);
  };

  return (
    <motion.a
      ref={ref}
      href={href}
      onMouseMove={handleMove}
      onMouseLeave={handleLeave}
      style={{ x, y }}
      className={`group inline-flex items-center gap-3 ${className ?? ""}`}
    >
      {children}
    </motion.a>
  );
}
