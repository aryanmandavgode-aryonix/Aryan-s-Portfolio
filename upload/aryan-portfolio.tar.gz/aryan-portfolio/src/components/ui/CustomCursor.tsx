"use client";

import { useEffect, useState } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";
import { useHasFinePointer } from "@/hooks/useHasFinePointer";
import { useReducedMotion } from "@/hooks/useReducedMotion";

const INTERACTIVE_SELECTOR = "a, button, [role='button'], input, textarea, select";

/**
 * A small dot plus a looser trailing ring that follow the pointer, and
 * expand/recolor over interactive elements. Renders nothing at all on
 * touch devices (no fine pointer) or under prefers-reduced-motion — the
 * native cursor is used in both cases, never hidden without a
 * replacement.
 */
export function CustomCursor() {
  const hasFinePointer = useHasFinePointer();
  const reducedMotion = useReducedMotion();
  const active = hasFinePointer && !reducedMotion;

  const [hovering, setHovering] = useState(false);
  const [visible, setVisible] = useState(false);

  const rawX = useMotionValue(-100);
  const rawY = useMotionValue(-100);
  const dotX = useSpring(rawX, { stiffness: 900, damping: 40, mass: 0.2 });
  const dotY = useSpring(rawY, { stiffness: 900, damping: 40, mass: 0.2 });
  const ringX = useSpring(rawX, { stiffness: 260, damping: 28, mass: 0.4 });
  const ringY = useSpring(rawY, { stiffness: 260, damping: 28, mass: 0.4 });

  useEffect(() => {
    if (!active) return;

    document.documentElement.classList.add("custom-cursor-active");

    const handleMove = (event: PointerEvent) => {
      rawX.set(event.clientX);
      rawY.set(event.clientY);
      setVisible(true);
    };
    const handleOver = (event: PointerEvent) => {
      const target = event.target as HTMLElement;
      setHovering(Boolean(target.closest?.(INTERACTIVE_SELECTOR)));
    };
    const handleLeaveWindow = () => setVisible(false);

    window.addEventListener("pointermove", handleMove);
    window.addEventListener("pointerover", handleOver);
    document.documentElement.addEventListener("mouseleave", handleLeaveWindow);

    return () => {
      document.documentElement.classList.remove("custom-cursor-active");
      window.removeEventListener("pointermove", handleMove);
      window.removeEventListener("pointerover", handleOver);
      document.documentElement.removeEventListener("mouseleave", handleLeaveWindow);
    };
  }, [active, rawX, rawY]);

  if (!active) return null;

  return (
    <>
      <motion.div
        aria-hidden="true"
        className="pointer-events-none fixed left-0 top-0 z-[100] h-1.5 w-1.5 rounded-full bg-ink"
        style={{ x: dotX, y: dotY, translateX: "-50%", translateY: "-50%" }}
        animate={{ opacity: visible ? 1 : 0 }}
        transition={{ duration: 0.2 }}
      />
      <motion.div
        aria-hidden="true"
        className="pointer-events-none fixed left-0 top-0 z-[100] rounded-full border"
        style={{ x: ringX, y: ringY, translateX: "-50%", translateY: "-50%" }}
        animate={{
          width: hovering ? 44 : 28,
          height: hovering ? 44 : 28,
          opacity: visible ? (hovering ? 0.9 : 0.5) : 0,
          borderColor: hovering ? "#3d6bff" : "#8a8f98",
        }}
        transition={{ duration: 0.25, ease: "easeOut" }}
      />
    </>
  );
}
