import clsx from "clsx";

interface EyebrowProps {
  index?: string;
  children: React.ReactNode;
  className?: string;
}

/**
 * The site's recurring structural label: a two-digit section index paired
 * with a tracked-out mono caption. Doubles as the instrument-panel motif.
 */
export function Eyebrow({ index, children, className }: EyebrowProps) {
  return (
    <div className={clsx("flex items-center gap-3 font-mono text-xs tracking-[0.25em] text-mist uppercase", className)}>
      {index && <span className="text-signal">{index}</span>}
      <span>{children}</span>
    </div>
  );
}
