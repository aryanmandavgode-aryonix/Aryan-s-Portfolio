const NOISE_SVG =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    `<svg xmlns='http://www.w3.org/2000/svg' width='160' height='160'>
      <filter id='n'>
        <feTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='2' stitchTiles='stitch' />
      </filter>
      <rect width='100%' height='100%' filter='url(#n)' />
    </svg>`
  );

interface GrainOverlayProps {
  className?: string;
}

/**
 * A static (non-animated) noise texture layered at very low opacity to
 * take the flatness off the near-black background. No canvas cost.
 */
export function GrainOverlay({ className }: GrainOverlayProps) {
  return (
    <div
      aria-hidden="true"
      className={`pointer-events-none absolute inset-0 opacity-[0.05] mix-blend-overlay ${className ?? ""}`}
      style={{ backgroundImage: `url("${NOISE_SVG}")`, backgroundSize: "160px 160px" }}
    />
  );
}
