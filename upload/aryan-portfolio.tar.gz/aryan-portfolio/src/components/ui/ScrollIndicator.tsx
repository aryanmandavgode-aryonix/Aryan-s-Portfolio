"use client";

import { motion } from "framer-motion";

interface ScrollIndicatorProps {
  reducedMotion: boolean;
  delay?: number;
}

export function ScrollIndicator({ reducedMotion, delay = 0 }: ScrollIndicatorProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 1, delay }}
      className="absolute inset-x-0 bottom-8 flex flex-col items-center gap-3 md:bottom-10"
    >
      <span className="font-mono text-[10px] tracking-[0.3em] text-mist uppercase">Scroll to explore</span>
      <span className="relative h-10 w-px overflow-hidden bg-line" aria-hidden="true">
        {!reducedMotion && (
          <motion.span
            className="absolute inset-x-0 top-0 h-1/2 bg-signal"
            animate={{ y: ["-100%", "200%"] }}
            transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
          />
        )}
      </span>
    </motion.div>
  );
}
