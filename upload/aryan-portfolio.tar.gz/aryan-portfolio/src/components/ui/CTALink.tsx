interface CTALinkProps {
  label: string;
  href?: string;
}

/**
 * Renders a real link when a URL exists. When it doesn't, renders a
 * native disabled <button> instead of a fake or dead link — disabled
 * buttons are correctly announced and automatically removed from tab
 * order by assistive tech, no aria workaround needed.
 */
export function CTALink({ label, href }: CTALinkProps) {
  if (href) {
    return (
      <a
        href={href}
        target="_blank"
        rel="noreferrer"
        className="group flex items-center gap-2 font-mono text-xs tracking-[0.2em] text-ink uppercase"
      >
        <span className="relative">
          {label}
          <span
            className="absolute -bottom-1 left-0 h-px w-full origin-left scale-x-0 bg-signal transition-transform duration-500 ease-out group-hover:scale-x-100"
            aria-hidden="true"
          />
        </span>
        <span aria-hidden="true" className="transition-transform duration-300 group-hover:translate-x-1">
          →
        </span>
      </a>
    );
  }

  return (
    <button
      type="button"
      disabled
      className="flex cursor-not-allowed items-center gap-2 font-mono text-xs tracking-[0.2em] text-mist/50 uppercase"
    >
      <span>{label}</span>
      <span aria-hidden="true">→</span>
      <span className="text-[10px] tracking-[0.15em] text-mist/40">(Coming soon)</span>
    </button>
  );
}
