interface CornerFrameProps {
  className?: string;
}

/**
 * Four corner brackets, absolutely positioned within a relative parent.
 * The recurring "instrument panel" motif used to frame the hero and
 * other full-bleed moments.
 */
export function CornerFrame({ className }: CornerFrameProps) {
  const corner = "absolute h-5 w-5 border-line md:h-6 md:w-6";
  return (
    <div className={`pointer-events-none absolute inset-4 md:inset-8 ${className ?? ""}`} aria-hidden="true">
      <span className={`${corner} left-0 top-0 border-l border-t`} />
      <span className={`${corner} right-0 top-0 border-r border-t`} />
      <span className={`${corner} bottom-0 left-0 border-b border-l`} />
      <span className={`${corner} bottom-0 right-0 border-b border-r`} />
    </div>
  );
}
