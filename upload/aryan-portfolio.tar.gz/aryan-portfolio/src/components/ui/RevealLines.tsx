"use client";

import { motion } from "framer-motion";

interface RevealLinesProps {
  lines: string[];
  reducedMotion: boolean;
  delay?: number;
  stagger?: number;
  className?: string;
  /** Heading level to render. Defaults to h2 (one per section). Pass h3
   * for a secondary heading within a section that already has its own h2. */
  as?: "h2" | "h3";
}

const EASE = [0.16, 1, 0.3, 1] as const;

/**
 * Masks each line inside an overflow-hidden band and slides it up into
 * place — a true per-line reveal, not just a single fade/slide on the
 * whole block.
 */
export function RevealLines({
  lines,
  reducedMotion,
  delay = 0,
  stagger = 0.12,
  className,
  as = "h2",
}: RevealLinesProps) {
  const Tag = as;
  return (
    <Tag className={className}>
      {lines.map((line, i) => (
        <span key={line} className="block overflow-hidden">
          <motion.span
            className="block"
            initial={{ y: reducedMotion ? 0 : "100%", opacity: reducedMotion ? 1 : 0 }}
            whileInView={{ y: "0%", opacity: 1 }}
            viewport={{ once: true, margin: "-10% 0px -10% 0px" }}
            transition={{
              duration: reducedMotion ? 0.01 : 0.9,
              delay: delay + i * stagger,
              ease: EASE,
            }}
          >
            {line}
          </motion.span>
        </span>
      ))}
    </Tag>
  );
}
