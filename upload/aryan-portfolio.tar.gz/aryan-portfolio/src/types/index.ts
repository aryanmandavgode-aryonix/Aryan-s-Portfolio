export type SkillCategory = "Frontend" | "Backend" | "Database" | "Tools" | "Creative";

export interface SkillItem {
  name: string;
  category: SkillCategory;
  description: string;
  /** Appears as an orbiting label in the Skills 3D scene. */
  floating?: boolean;
}

export type ProjectVisualKey = "aryonix" | "aqi-dashboard" | "client-projects";

export interface ProjectItem {
  id: string;
  index: string; // e.g. "01"
  title: string;
  category: string;
  description: string;
  technologies: string[];
  /** Which procedural mockup to render in place of a real screenshot. */
  visual: ProjectVisualKey;
  /** Reserved for a real screenshot later — unset today. */
  image?: string;
  /** Reserved for the live URL later — unset today. */
  liveUrl?: string;
  /** Reserved for the GitHub repo later — unset today. */
  githubUrl?: string;
}

export interface JourneyEntry {
  id: string;
  index: string; // e.g. "01"
  title: string;
  description: string;
  focus: string[];
}

export interface AboutStatItem {
  value: string;
  label: string;
}

export interface SocialLink {
  label: string;
  href: string;
  handle: string;
}
