import type { SkillCategory, SkillItem } from "@/types";

export const skillCategories: SkillCategory[] = ["Frontend", "Backend", "Database", "Tools", "Creative"];

export const skills: SkillItem[] = [
  // Frontend
  { name: "HTML", category: "Frontend", description: "Semantic markup — the foundation under every interface I build." },
  { name: "CSS", category: "Frontend", description: "Layout, motion, and detail work — the line between functional and refined." },
  { name: "JavaScript", category: "Frontend", description: "The language everything else in the browser is built on." },
  { name: "TypeScript", category: "Frontend", description: "Used to create safer and more maintainable application architecture.", floating: true },
  { name: "React", category: "Frontend", description: "Used to build interactive and component-driven interfaces.", floating: true },
  { name: "Next.js", category: "Frontend", description: "Framework I use for production-ready React applications and full-stack web experiences.", floating: true },
  { name: "Tailwind CSS", category: "Frontend", description: "Utility-first styling that keeps a design system consistent without the overhead." },

  // Backend
  { name: "Node.js", category: "Backend", description: "Server-side JavaScript for APIs, tooling, and backend logic.", floating: true },
  { name: "REST APIs", category: "Backend", description: "The contract layer between frontend and backend, designed to be predictable." },

  // Database
  { name: "MongoDB", category: "Database", description: "Flexible, document-based storage for fast-moving product data.", floating: true },
  { name: "Prisma", category: "Database", description: "Type-safe database access that keeps schema and code in sync." },
  { name: "SQL", category: "Database", description: "Relational modeling for data that needs structure and integrity." },

  // Tools
  { name: "Git", category: "Tools", description: "Version control — the record of every decision in a codebase." },
  { name: "GitHub", category: "Tools", description: "Where code, issues, and collaboration live.", floating: true },
  { name: "VS Code", category: "Tools", description: "The editor I spend most of the day in." },

  // Creative
  { name: "Three.js", category: "Creative", description: "Low-level 3D on the web — the engine behind every scene on this site.", floating: true },
  { name: "React Three Fiber", category: "Creative", description: "Three.js written the way I write everything else — as React." },
  { name: "GSAP", category: "Creative", description: "Fine-grained animation control for sequences three.js and CSS can't easily express.", floating: true },
  { name: "Framer Motion", category: "Creative", description: "Declarative motion for interface-level animation and transitions." },
];

// The subset that orbits in the 3D scene. Kept short deliberately —
// see Skills.tsx for the mobile-reduced slice of this list.
export const floatingSkills: SkillItem[] = skills.filter((skill) => skill.floating);
