export const aryonix = {
  name: "ARYONIX",
  tagline: "DESIGN. DEVELOP. DEPLOY.",
  positioning: "Digital Development & Design",
  heroLines: ["BUILDING DIGITAL", "EXPERIENCES THAT", "MATTER."],
  intro:
    "ARYONIX is my venture focused on designing and developing modern digital experiences, websites and technology-driven products.",
  services: ["Web Development", "UI/UX Design", "Digital Experiences", "Creative Development"],
  url: "https://www.aryonix.in/",
} as const;
