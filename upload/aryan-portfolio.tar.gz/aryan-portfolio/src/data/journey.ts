import type { JourneyEntry } from "@/types";

export const journey: JourneyEntry[] = [
  {
    id: "learning",
    index: "01",
    title: "Learning",
    description: "Started exploring programming, web development and technology.",
    focus: ["HTML", "CSS", "JavaScript", "Programming fundamentals"],
  },
  {
    id: "building",
    index: "02",
    title: "Building",
    description:
      "Started building real websites, applications and interactive digital experiences.",
    focus: ["React", "Node.js", "APIs", "Databases", "Git"],
  },
  {
    id: "engineering",
    index: "03",
    title: "Engineering",
    description: "Expanded into modern full-stack development and more advanced technologies.",
    focus: ["Next.js", "TypeScript", "MongoDB", "Prisma", "REST APIs"],
  },
  {
    id: "aryonix",
    index: "04",
    title: "Aryonix",
    description: "Started building ARYONIX and working on digital products, websites and experiences.",
    focus: ["Product development", "Web development", "UI/UX", "Client projects", "Business"],
  },
  {
    id: "now",
    index: "05",
    title: "Now",
    description:
      "Currently studying Computer Engineering while continuing to build products, improve my skills and explore new technologies.",
    focus: ["3D Web", "Three.js", "Creative Development", "AI", "Entrepreneurship"],
  },
];
