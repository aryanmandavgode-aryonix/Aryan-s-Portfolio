import type { ProjectItem } from "@/types";

// `image`, `liveUrl`, and `githubUrl` are intentionally left unset — no
// screenshots or repos exist for these yet. ProjectCTA renders a
// disabled "coming soon" state whenever a URL is missing rather than
// inventing a destination.
export const projects: ProjectItem[] = [
  {
    id: "aryonix",
    index: "01",
    title: "ARYONIX",
    category: "Digital Agency / Web Platform",
    description:
      "A modern digital platform and brand experience built for ARYONIX, combining premium visual design with a scalable full-stack architecture.",
    technologies: ["Next.js", "TypeScript", "Tailwind CSS", "Prisma", "MongoDB"],
    visual: "aryonix",
  },
  {
    id: "aqi-dashboard",
    index: "02",
    title: "AQI Dashboard",
    category: "Data Visualization",
    description:
      "An interactive dashboard designed to present air-quality information through a clean and intuitive visual interface.",
    technologies: ["React", "JavaScript", "APIs", "Data Visualization"],
    visual: "aqi-dashboard",
  },
  {
    id: "client-projects",
    index: "03",
    title: "Client Projects",
    category: "Web Development",
    description: "Websites and digital experiences created for businesses and personal brands.",
    technologies: ["Next.js", "React", "TypeScript", "Tailwind CSS"],
    visual: "client-projects",
  },
];
