import type { AboutStatItem, SocialLink } from "@/types";

export const profile = {
  name: "Aryan Mandavgode",
  role: "Computer Engineering Student · Developer · Creative Technologist",
  location: "Pune, India",
  coordinates: "18.5204° N / 73.8567° E",
  email: "aryonixpvtltd@gmail.com",
  headline: ["I BUILD DIGITAL EXPERIENCES", "WHERE TECHNOLOGY MEETS DESIGN."],
  intro:
    "I'm Aryan Mandavgode, a Computer Engineering student and developer who enjoys building modern digital products, interactive experiences and ambitious ideas. I'm also building ARYONIX, a digital development and design venture.",
} as const;

export const socials: SocialLink[] = [
  {
    label: "GitHub",
    href: "https://github.com/aryanmandavgode-aryonix",
    handle: "@aryanmandavgode-aryonix",
  },
  {
    label: "LinkedIn",
    href: "https://www.linkedin.com/in/aryan-mandavgode",
    handle: "aryan-mandavgode",
  },
];

export const aboutStats: AboutStatItem[] = [
  { value: "19", label: "Years" },
  { value: "SE", label: "Computer Engineering" },
  { value: "ARYONIX", label: "Founder" },
  { value: "∞", label: "Building" },
];
