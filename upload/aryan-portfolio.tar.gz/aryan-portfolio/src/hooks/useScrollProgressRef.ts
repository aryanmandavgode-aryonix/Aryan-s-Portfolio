"use client";

import { useEffect, useRef, type RefObject } from "react";
import { useScroll } from "framer-motion";

/**
 * Wraps framer-motion's useScroll and subscribes to changes imperatively
 * instead of via React state — the returned ref updates every scroll
 * frame without triggering a re-render, which matters because it's read
 * inside a Canvas's useFrame loop, not rendered directly.
 */
export function useScrollProgressRef(target: RefObject<HTMLElement | null>) {
  const { scrollYProgress } = useScroll({ target, offset: ["start end", "end start"] });
  const progress = useRef(0);

  useEffect(() => {
    return scrollYProgress.on("change", (value) => {
      progress.current = value;
    });
  }, [scrollYProgress]);

  return progress;
}
