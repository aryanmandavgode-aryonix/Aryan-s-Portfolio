import Image from "next/image";
import { MapPin, ArrowRight } from "lucide-react";

export default function Hero() {
  return (
    <section
      id="home"
      className="relative overflow-hidden bg-ink pt-32 pb-20 md:pt-40 md:pb-28"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -top-40 -right-40 h-[520px] w-[520px] rounded-full bg-gold/20 blur-[120px]"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute bottom-0 left-0 h-72 w-72 rounded-full bg-navy/40 blur-[100px]"
      />

      <div className="container-xl relative grid gap-16 md:grid-cols-[1.1fr_0.9fr] md:items-center">
        <div className="animate-rise">
          <span className="inline-flex items-center gap-2 rounded-full border border-gold/30 bg-gold/10 px-4 py-1.5 text-sm text-gold-pale">
            <MapPin size={15} />
            Opposite VNIT Main Gate, Nagpur
          </span>

          <h1 className="mt-7 font-display text-5xl leading-[1.05] text-cream text-balance sm:text-6xl lg:text-7xl">
            Waffles, made
            <br />
            to make you smile.
          </h1>

          <p className="mt-6 max-w-md text-lg leading-relaxed text-cream/70">
            Freshly made waffles, indulgent shakes and sweet cravings — right
            opposite VNIT Main Gate, Nagpur.
          </p>

          <div className="mt-9 flex flex-wrap items-center gap-4">
            <a
              href="#menu"
              className="inline-flex items-center gap-2 rounded-full bg-gold px-7 py-3.5 font-semibold text-ink transition-transform hover:scale-[1.03] hover:bg-gold-pale focus-ring"
            >
              Explore Menu
              <ArrowRight size={18} />
            </a>
            <a
              href="#location"
              className="inline-flex items-center gap-2 rounded-full border border-cream/25 px-7 py-3.5 font-semibold text-cream transition-colors hover:border-gold hover:text-gold focus-ring"
            >
              Order Now
            </a>
          </div>
        </div>

        <div className="relative mx-auto w-full max-w-md animate-plate" style={{ ["--tilt" as string]: "-3deg" }}>
          <div
            aria-hidden
            className="absolute inset-6 rounded-[40%_60%_55%_45%/50%_45%_55%_50%] bg-gradient-to-br from-gold/25 via-gold/5 to-transparent"
          />
          <div className="relative aspect-[4/5] rotate-[-3deg] overflow-hidden rounded-[2.5rem] border-4 border-cream/10 shadow-[0_40px_80px_-30px_rgba(0,0,0,0.7)]">
            <Image
              src="/images/dish-kitkat-crunch.jpg"
              alt="Loaded KitKat crunch waffle, fresh off the iron"
              fill
              sizes="(max-width: 768px) 90vw, 480px"
              className="object-cover"
              priority
            />
          </div>
          <div className="absolute -bottom-4 left-2 sm:-bottom-6 sm:-left-6 animate-drift rounded-2xl bg-cream px-5 py-3 shadow-xl">
            <p className="font-display text-lg italic text-ink">
              Taste the royal waffle
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
