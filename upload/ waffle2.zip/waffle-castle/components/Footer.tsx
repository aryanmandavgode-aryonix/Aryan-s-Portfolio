import Image from "next/image";
import { navLinks, address } from "@/lib/data";

export default function Footer() {
  return (
    <footer className="bg-ink-soft pt-16 pb-8">
      <div className="container-xl grid gap-12 sm:grid-cols-2 md:grid-cols-4">
        <div className="sm:col-span-2 md:col-span-1">
          <div className="flex items-center gap-3">
            <span className="relative block h-12 w-12 overflow-hidden rounded-full ring-2 ring-gold/50">
              <Image
                src="/images/logo-mark.png"
                alt="Waffle Castle crown logo"
                fill
                sizes="48px"
                className="object-cover"
              />
            </span>
            <span className="font-display text-lg text-cream">
              Waffle Castle
            </span>
          </div>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-cream/55">
            Taste the royal waffle — fresh off the iron, opposite VNIT Main
            Gate, Nagpur.
          </p>
        </div>

        <div>
          <p className="font-display text-sm italic text-gold">Explore</p>
          <ul className="mt-4 space-y-2.5">
            {navLinks.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="text-sm text-cream/65 hover:text-cream focus-ring rounded-sm"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div className="sm:col-span-2 md:col-span-2">
          <p className="font-display text-sm italic text-gold">Visit</p>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-cream/65">
            {address.line1}, {address.line2}, {address.line3}
          </p>
        </div>
      </div>

      <div className="container-xl mt-14 flex flex-col gap-3 border-t border-cream/10 pt-6 text-xs text-cream/40 sm:flex-row sm:items-center sm:justify-between">
        <p>© {new Date().getFullYear()} Waffle Castle. All rights reserved.</p>
        <p>Concept design by ARYONIX — Design. Develop. Deploy.</p>
      </div>
    </footer>
  );
}
