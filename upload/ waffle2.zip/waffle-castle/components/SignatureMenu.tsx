import Image from "next/image";
import { ArrowRight } from "lucide-react";
import { menuItems } from "@/lib/data";
import Reveal from "@/components/Reveal";

export default function SignatureMenu() {
  const [large, ...rest] = menuItems;

  return (
    <section id="menu" className="bg-cream py-24 md:py-32">
      <div className="container-xl">
        <Reveal className="max-w-lg">
          <p className="font-display text-lg italic text-gold-deep">
            Our favourites
          </p>
          <h2 className="mt-2 font-display text-4xl leading-tight text-ink text-balance sm:text-5xl">
            A few reasons people cross campus for this.
          </h2>
        </Reveal>

        <div className="mt-14 grid gap-6 md:grid-cols-2">
          <Reveal className="group relative overflow-hidden rounded-3xl bg-ink md:row-span-2">
            <div className="relative aspect-[4/3] md:aspect-auto md:h-full">
              <Image
                src={large.image}
                alt={large.name}
                fill
                sizes="(max-width: 768px) 100vw, 50vw"
                className="object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/10 to-transparent" />
            </div>
            <div className="absolute inset-x-0 bottom-0 p-7">
              <span className="inline-block rounded-full bg-gold/90 px-3 py-1 text-xs font-semibold text-ink">
                {large.tag}
              </span>
              <h3 className="mt-3 font-display text-2xl text-cream">
                {large.name}
              </h3>
              <p className="mt-2 max-w-sm text-sm leading-relaxed text-cream/75">
                {large.description}
              </p>
            </div>
          </Reveal>

          <div className="grid gap-6 sm:grid-cols-2 md:contents">
            {rest.map((item) => (
              <Reveal
                key={item.id}
                className="group relative overflow-hidden rounded-3xl bg-ink"
              >
                <div className="relative aspect-[4/3]">
                  <Image
                    src={item.image}
                    alt={item.name}
                    fill
                    sizes="(max-width: 768px) 100vw, 25vw"
                    className="object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/5 to-transparent" />
                </div>
                <div className="absolute inset-x-0 bottom-0 p-5">
                  <span className="inline-block rounded-full bg-gold/90 px-2.5 py-1 text-[11px] font-semibold text-ink">
                    {item.tag}
                  </span>
                  <h3 className="mt-2 font-display text-lg text-cream">
                    {item.name}
                  </h3>
                </div>
              </Reveal>
            ))}
          </div>
        </div>

        <Reveal className="mt-12 flex justify-center">
          <a
            href="#full-menu"
            className="inline-flex items-center gap-2 rounded-full border border-ink/15 bg-paper px-6 py-3 font-semibold text-ink transition-colors hover:border-gold-deep hover:text-gold-deep focus-ring"
          >
            View Full Menu
            <ArrowRight size={18} />
          </a>
        </Reveal>
      </div>
    </section>
  );
}
