import Image from "next/image";
import { ZoomIn } from "lucide-react";
import { galleryImages } from "@/lib/data";
import Reveal from "@/components/Reveal";

const spanClass: Record<string, string> = {
  tall: "row-span-2 aspect-[3/4]",
  wide: "sm:col-span-2 aspect-[16/10]",
  square: "aspect-square",
};

export default function Gallery() {
  return (
    <section id="gallery" className="bg-paper py-24 md:py-32">
      <div className="container-xl">
        <Reveal className="max-w-lg">
          <p className="font-display text-lg italic text-gold-deep">Gallery</p>
          <h2 className="mt-2 font-display text-4xl leading-tight text-ink text-balance sm:text-5xl">
            Straight off the pass, straight to your feed.
          </h2>
        </Reveal>

        <div className="mt-14 grid auto-rows-[minmax(0,1fr)] gap-4 sm:grid-cols-3">
          {galleryImages.map((item) => (
            <Reveal
              key={item.id}
              className={`group relative overflow-hidden rounded-2xl bg-ink/5 ${spanClass[item.span]}`}
            >
              <Image
                src={item.image}
                alt={item.alt}
                fill
                sizes="(max-width: 768px) 50vw, 33vw"
                className={`transition-transform duration-700 group-hover:scale-110 ${
                  item.image.endsWith(".png") ? "object-contain p-6" : "object-cover"
                }`}
              />
              <div className="absolute inset-0 flex items-end justify-end bg-ink/0 p-4 opacity-0 transition-opacity duration-300 group-hover:bg-ink/25 group-hover:opacity-100">
                <span className="rounded-full bg-cream/90 p-2 text-ink">
                  <ZoomIn size={16} />
                </span>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
