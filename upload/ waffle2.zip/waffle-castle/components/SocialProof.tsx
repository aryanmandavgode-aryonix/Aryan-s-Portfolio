import { Star } from "lucide-react";
import Reveal from "@/components/Reveal";

const placeholders = [1, 2, 3];

export default function SocialProof() {
  return (
    <section className="bg-navy py-24 md:py-28">
      <div className="container-xl">
        <Reveal className="max-w-lg">
          <p className="font-display text-lg italic text-gold-pale">
            Loved by dessert lovers
          </p>
          <h2 className="mt-2 font-display text-3xl leading-tight text-cream text-balance sm:text-4xl">
            Space reserved for your real reviews.
          </h2>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-cream/65">
            This layout is ready to go live — we&apos;ll drop in genuine
            Google and Instagram reviews here once you&apos;re ready to
            launch.
          </p>
        </Reveal>

        <div className="mt-12 grid gap-5 sm:grid-cols-3">
          {placeholders.map((n) => (
            <Reveal
              key={n}
              className="rounded-2xl border border-dashed border-cream/25 bg-cream/5 p-6"
            >
              <div className="flex gap-1 text-gold">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} size={16} fill="currentColor" strokeWidth={0} />
                ))}
              </div>
              <p className="mt-4 text-sm italic leading-relaxed text-cream/50">
                &ldquo;Customer review placeholder — real quote goes here.&rdquo;
              </p>
              <p className="mt-4 text-xs font-medium text-cream/35">
                Review to be added
              </p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
