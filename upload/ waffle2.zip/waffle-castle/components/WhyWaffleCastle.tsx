import { Flame, Sparkles, Users, Heart, type LucideIcon } from "lucide-react";
import { features, type Feature } from "@/lib/data";
import Reveal from "@/components/Reveal";

const icons: Record<Feature["icon"], LucideIcon> = {
  flame: Flame,
  sparkles: Sparkles,
  users: Users,
  heart: Heart,
};

export default function WhyWaffleCastle() {
  return (
    <section id="about" className="bg-ink py-24 md:py-32">
      <div className="container-xl">
        <Reveal className="max-w-lg">
          <p className="font-display text-lg italic text-gold">Why Waffle Castle</p>
          <h2 className="mt-2 font-display text-4xl leading-tight text-cream text-balance sm:text-5xl">
            The experience behind every plate.
          </h2>
        </Reveal>

        <div className="mt-16 grid gap-x-8 gap-y-12 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((feature) => {
            const Icon = icons[feature.icon];
            return (
              <Reveal key={feature.id} className="border-t border-cream/15 pt-6">
                <Icon size={28} className="text-gold" strokeWidth={1.6} />
                <h3 className="mt-4 font-display text-xl text-cream">
                  {feature.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-cream/65">
                  {feature.description}
                </p>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
