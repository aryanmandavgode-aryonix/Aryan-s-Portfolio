import Image from "next/image";
import { ArrowRight } from "lucide-react";
import Reveal from "@/components/Reveal";

export default function FinalCTA() {
  return (
    <section className="relative overflow-hidden bg-ink py-24 md:py-32">
      <div className="container-xl grid gap-12 md:grid-cols-2 md:items-center">
        <Reveal>
          <h2 className="font-display text-4xl leading-[1.08] text-cream text-balance sm:text-5xl">
            Your next sweet craving starts here.
          </h2>
          <p className="mt-5 max-w-sm text-lg leading-relaxed text-cream/70">
            Drop by Waffle Castle or order your favourites today.
          </p>
          <div className="mt-9 flex flex-wrap gap-4">
            <a
              href="#location"
              className="inline-flex items-center gap-2 rounded-full bg-gold px-7 py-3.5 font-semibold text-ink transition-transform hover:scale-[1.03] hover:bg-gold-pale focus-ring"
            >
              Order Now
              <ArrowRight size={18} />
            </a>
            <a
              href="#location"
              className="inline-flex items-center gap-2 rounded-full border border-cream/25 px-7 py-3.5 font-semibold text-cream transition-colors hover:border-gold hover:text-gold focus-ring"
            >
              Visit Us
            </a>
          </div>
        </Reveal>

        <Reveal className="relative aspect-[5/4] overflow-hidden rounded-[2.5rem] rotate-2 shadow-[0_40px_80px_-30px_rgba(0,0,0,0.7)]">
          <Image
            src="/images/dish-strawberry.jpg"
            alt="Strawberry royal waffle, fresh and ready to serve"
            fill
            sizes="(max-width: 768px) 100vw, 45vw"
            className="object-cover"
          />
        </Reveal>
      </div>
    </section>
  );
}
