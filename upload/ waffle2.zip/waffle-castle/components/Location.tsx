import { MapPin, Navigation } from "lucide-react";
import { address } from "@/lib/data";
import Reveal from "@/components/Reveal";

export default function Location() {
  const mapsHref = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    address.mapsQuery
  )}`;

  return (
    <section id="location" className="bg-cream py-24 md:py-32">
      <div className="container-xl">
        <Reveal className="max-w-lg">
          <p className="font-display text-lg italic text-gold-deep">
            Find us near VNIT
          </p>
          <h2 className="mt-2 font-display text-4xl leading-tight text-ink text-balance sm:text-5xl">
            Right across the road from campus.
          </h2>
        </Reveal>

        <Reveal className="mt-12 overflow-hidden rounded-3xl bg-ink text-cream">
          <div className="grid gap-8 p-8 md:grid-cols-[auto_1fr_auto] md:items-center md:p-12">
            <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gold/15 text-gold">
              <MapPin size={28} />
            </span>

            <div>
              <p className="text-lg leading-relaxed text-cream/90">
                {address.line1}
              </p>
              <p className="text-lg leading-relaxed text-cream/90">
                {address.line2}
              </p>
              <p className="text-lg leading-relaxed text-cream/90">
                {address.line3}
              </p>
            </div>

            <a
              href={mapsHref}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center justify-center gap-2 rounded-full bg-gold px-6 py-3.5 font-semibold text-ink transition-transform hover:scale-[1.03] hover:bg-gold-pale focus-ring"
            >
              <Navigation size={17} />
              Get Directions
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
