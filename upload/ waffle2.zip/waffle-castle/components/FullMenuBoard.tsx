import Image from "next/image";
import Reveal from "@/components/Reveal";

export default function FullMenuBoard() {
  return (
    <section id="full-menu" className="bg-navy py-24 md:py-28">
      <div className="container-xl grid gap-10 md:grid-cols-[0.8fr_1.2fr] md:items-center">
        <Reveal>
          <p className="font-display text-lg italic text-gold-pale">
            Every flavour, one board
          </p>
          <h2 className="mt-2 font-display text-3xl leading-tight text-cream text-balance sm:text-4xl">
            The complete Waffle Castle menu.
          </h2>
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-cream/70">
            Royal Classics, Double Chocolate, Royal Jewel Treats and more —
            all on one board, exactly as it hangs in-store.
          </p>
        </Reveal>

        <Reveal className="overflow-hidden rounded-3xl border border-cream/10 bg-cream shadow-[0_30px_60px_-25px_rgba(0,0,0,0.6)]">
          <div className="relative aspect-[4/3] w-full">
            <Image
              src="/images/menu-board.jpg"
              alt="Full Waffle Castle menu board with all flavours and prices"
              fill
              sizes="(max-width: 768px) 100vw, 60vw"
              className="object-contain p-3"
            />
          </div>
        </Reveal>
      </div>
    </section>
  );
}
