# Waffle Castle Nagpur — Homepage Concept

A premium sales-demo homepage built by ARYONIX for Waffle Castle Nagpur.

## Run it

```bash
npm install
npm run dev
```

Then open http://localhost:3000.

## What's real vs. placeholder

- Logo, all four dish photos, and the full menu board are the actual Waffle Castle assets.
- Address and directions link use the real store location.
- The reviews section is intentionally left as a labeled placeholder — no fabricated names, quotes, or ratings.
- No phone number, email, prices outside the real menu board, or opening hours were invented; "Order Now" links to the location section rather than a fake ordering flow.

## Stack

Next.js (App Router) · TypeScript · Tailwind CSS v4 · Lucide React · self-hosted Fraunces & Manrope variable fonts (Fontsource)
