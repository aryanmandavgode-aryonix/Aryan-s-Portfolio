import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import SignatureMenu from "@/components/SignatureMenu";
import WhyWaffleCastle from "@/components/WhyWaffleCastle";
import Gallery from "@/components/Gallery";
import FullMenuBoard from "@/components/FullMenuBoard";
import Location from "@/components/Location";
import SocialProof from "@/components/SocialProof";
import FinalCTA from "@/components/FinalCTA";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <SignatureMenu />
        <WhyWaffleCastle />
        <Gallery />
        <FullMenuBoard />
        <Location />
        <SocialProof />
        <FinalCTA />
      </main>
      <Footer />
    </>
  );
}
