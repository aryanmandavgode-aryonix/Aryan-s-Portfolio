export type NavLink = {
  label: string;
  href: string;
};

export const navLinks: NavLink[] = [
  { label: "Home", href: "#home" },
  { label: "Menu", href: "#menu" },
  { label: "About", href: "#about" },
  { label: "Gallery", href: "#gallery" },
  { label: "Contact", href: "#location" },
];

export type MenuItem = {
  id: string;
  name: string;
  description: string;
  tag: string;
  image: string;
  size: "large" | "regular";
};

export const menuItems: MenuItem[] = [
  {
    id: "kitkat-crunch",
    name: "Loaded KitKat Crunch",
    description:
      "A warm waffle stacked high with milk chocolate, crushed KitKat and a snowfall of marshmallow — the one everyone photographs first.",
    tag: "Double Chocolate",
    image: "/images/dish-kitkat-crunch.jpg",
    size: "large",
  },
  {
    id: "cookies-cream",
    name: "Cookies & Cream Waffle",
    description:
      "Crisp golden waffle dipped in cool cream and rolled through crushed cookies, edge to edge.",
    tag: "Crunchy Chocolate",
    image: "/images/dish-cookies-cream.jpg",
    size: "regular",
  },
  {
    id: "strawberry-royal",
    name: "Strawberry Royal",
    description:
      "A honey-butter waffle finished with warm strawberry compote and a dusting of icing sugar.",
    tag: "Royal Classics",
    image: "/images/dish-strawberry.jpg",
    size: "regular",
  },
  {
    id: "royal-bites",
    name: "Royal Bites Mini Pancakes",
    description:
      "Bite-sized pancakes glazed in chocolate — boxed up for sharing, gifting, or keeping to yourself.",
    tag: "Royal Bites",
    image: "/images/product-mini-pancakes.jpg",
    size: "regular",
  },
];

export type Feature = {
  id: string;
  title: string;
  description: string;
  icon: "flame" | "sparkles" | "users" | "heart";
};

export const features: Feature[] = [
  {
    id: "fresh",
    title: "Freshly Made",
    description: "Every waffle hits the iron after you order, never before.",
    icon: "flame",
  },
  {
    id: "ingredients",
    title: "Premium Ingredients",
    description: "Real chocolate, real fruit, real cream — no shortcuts.",
    icon: "sparkles",
  },
  {
    id: "sharing",
    title: "Perfect for Sharing",
    description: "Built for two forks and a table full of friends.",
    icon: "users",
  },
  {
    id: "cravings",
    title: "Made for Sweet Cravings",
    description: "The 6pm study break this campus keeps coming back for.",
    icon: "heart",
  },
];

export type GalleryImage = {
  id: string;
  image: string;
  alt: string;
  span: "tall" | "wide" | "square";
};

export const galleryImages: GalleryImage[] = [
  { id: "g1", image: "/images/dish-kitkat-crunch.jpg", alt: "Loaded KitKat crunch waffle", span: "wide" },
  { id: "g2", image: "/images/dish-cookies-cream.jpg", alt: "Cookies and cream waffle slice", span: "tall" },
  { id: "g3", image: "/images/dish-strawberry.jpg", alt: "Strawberry royal waffle on a plate", span: "square" },
  { id: "g4", image: "/images/product-mini-pancakes.jpg", alt: "Boxed Royal Bites mini pancakes", span: "square" },
];

export const address = {
  line1: "Shop no. 37, Upper Ground Floor, Shewalkar Building",
  line2: "S Ambazari Rd, Opp. VNIT Main Gate, Gayatri Nagar, Pratap Nagar",
  line3: "Nagpur, Maharashtra 440022",
  mapsQuery:
    "Waffle Castle, Shop no 37 Shewalkar Building S Ambazari Rd Opposite VNIT Main Gate Gayatri Nagar Pratap Nagar Nagpur Maharashtra 440022",
};
